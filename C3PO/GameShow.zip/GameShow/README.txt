====================
GAMESHOW
by Greg Smith
in B2C
====================

Gameshow allows you to create a ring-in gameshow with 3 or more cybikos.  One cybiko is the Master of Ceremonies (MC) and the others are players.  The MC reads the questions and the players race to ring in.  Gameshow records who was first to ring in and the MC asks the player for the answer.  If the answer is correct then the player gets points.  Otherwise the other players have a chance to ring in.  When the time runs out the game is over and everyone can see the winner in their display.

For details check out the review in CyblaReview

I have used this system repeatedly to play Jeopardy-style games with up to 5 players and one  MC (master of ceremonies).  I have included the source code so that others may learn how to use the B2C Messaging.  Sorry for the lack of comments.  As the old programmer's addage goes - if it was hard to write it should be hard to understand ;)

finally, the programs were written in b2c v3d so you may have to massage the source a bit to compile in more recent versions.

-greg