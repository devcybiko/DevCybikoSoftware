==================================
b2c4palm installation instructions
==================================

12/31/2002

Extract these three directories to the C: directory of your computer.  Then go to c:\b2c4palm and run SETPATH.  This will set your path and other variables.  To compile type "Build hello".

Greg Smith