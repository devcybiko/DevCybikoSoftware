----------------------------------------------------------------------------
 PilRC demo version 0.2 beta                                  June 28, 2000
----------------------------------------------------------------------------

  BUILDING
  ========

  PilRC demo outlines the basic usage of PilRC with the prc-tools 2.0 and 
  later compiling environment, which is available here:

    http://www.palmos.com/dev/tech/tools/gcc/index.html

  The source code and binaries are available free of charge and should be
  used  only in  understanding the PilRC  application.  Redistribution or 
  modification of these sources without the prior consent of the original
  author is prohibited.

  Thankyou for downloading and using PilRC! 

  CHANGES:
  ========

  07-Jun-00 Aaron Ardiri         Creation
  28-Jun-00 Aaron Ardiri         tSTL demonstration added

  // az
  aaron@ardiri.com

----------------------------------------------------------------------------
