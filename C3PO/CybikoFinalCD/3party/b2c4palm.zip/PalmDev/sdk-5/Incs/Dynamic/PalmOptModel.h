/******************************************************************************
 *
 * Copyright (c) 1999-2002 Palm, Inc. or its subsidiaries.
 * All rights reserved.
 *
 * File: PalmOptModel.h
 *
 * Release: Palm OS SDK 5.0 (111823)
 *
 *****************************************************************************/

#include <BuildDefines.h>
#ifdef MODEL
#undef MODEL
#endif
#define MODEL MODEL_GENERIC
