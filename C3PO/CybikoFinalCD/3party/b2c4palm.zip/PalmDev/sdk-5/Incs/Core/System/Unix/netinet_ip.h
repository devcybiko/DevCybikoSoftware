/******************************************************************************
 *
 * Copyright (c) 1996-2002 Palm, Inc. or its subsidiaries.
 * All rights reserved.
 *
 * File: netinet_ip.h
 *
 * Release: Palm OS SDK 5.0 (111823)
 *
 * Description:
 *	  This module contains the interface definitions that are 
 *	typically found in the unix header <netinet/ip.h> for use by 
 * Pilot applications that wish to use the sockets API calls.
 *
 *****************************************************************************/

/*      @(#)ip.h 1.13 88/08/19 SMI; from UCB 7.6.1.1 3/15/88    */

/*
 * Copyright (c) 1982, 1986 Regents of the University of California.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms are permitted
 * provided that this notice is preserved and that due credit is given
 * to the University of California at Berkeley. The name of the University
 * may not be used to endorse or promote products derived from this
 * software without specific prior written permission. This software
 * is provided ``as is'' without express or implied warranty.
 */

/*
 * Definitions for internet protocol version 4.
 * Per RFC 791, September 1981.
 */

#ifndef __UNIX_NETINET_IP_H__
#define __UNIX_NETINET_IP_H__

#include <netinet_in.h>
#include <netinet_in_systm.h>

#define IPVERSION       4

/*
 * Structure of an internet header, naked of options.
 *
 * We declare ip_len and ip_off to be Int16, rather than u_short
 * pragmatically since otherwise unsigned comparisons can result
 * against negative integers quite easily, and fail in subtle ways.
 */
struct ip {
        u_char  ip_v:4,                 /* version */
                ip_hl:4;                /* header length */
        u_char  ip_tos;                 /* type of service */
        Int16   ip_len;                 /* total length */
        u_short ip_id;                  /* identification */
        Int16   ip_off;                 /* fragment offset field */
#define IP_DF 0x4000                    /* dont fragment flag */
#define IP_MF 0x2000                    /* more fragments flag */
        u_char  ip_ttl;                 /* time to live */
        u_char  ip_p;                   /* protocol */
        u_short ip_sum;                 /* checksum */
        struct  in_addr ip_src,ip_dst;  /* source and dest address */
};

#define IP_MAXPACKET    65535           /* maximum packet size */

/*
 * Definitions for options.
 */
#define IPOPT_COPIED(o)         ((o)&0x80)
#define IPOPT_CLASS(o)          ((o)&0x60)
#define IPOPT_NUMBER(o)         ((o)&0x1f)

#define IPOPT_CONTROL           0x00
#define IPOPT_RESERVED1         0x20
#define IPOPT_DEBMEAS           0x40
#define IPOPT_RESERVED2         0x60

#define IPOPT_EOL               0               /* end of option list */
#define IPOPT_NOP               1               /* no operation */

#define IPOPT_RR                7               /* record packet route */
#define IPOPT_TS                68              /* timestamp */
#define IPOPT_SECURITY          130             /* provide s,c,h,tcc */
#define IPOPT_LSRR              131             /* loose source route */
#define IPOPT_SATID             136             /* satnet id */
#define IPOPT_SSRR              137             /* strict source route */

/*
 * Offsets to fields in options other than EOL and NOP.
 */
#define IPOPT_OPTVAL            0               /* option ID */
#define IPOPT_OLEN              1               /* option length */
#define IPOPT_OFFSET            2               /* offset within option */
#define IPOPT_MINOFF            4               /* min value of above */

/*
 * Time stamp option structure.
 */
struct  ip_timestamp {
        u_char  ipt_code;               /* IPOPT_TS */
        u_char  ipt_len;                /* size of structure (variable) */
        u_char  ipt_ptr;                /* index of current entry */
        u_char  ipt_oflw:4,             /* overflow counter */
                ipt_flg:4;              /* flags, see below */
        union ipt_timestamp {
                n_long  ipt_time[1];
                struct  ipt_ta {
                        struct in_addr ipt_addr;
                        n_long ipt_time;
                } ipt_ta[1];
        } ipt_timestamp;
};

/* flag bits for ipt_flg */
#define IPOPT_TS_TSONLY         0               /* timestamps only */
#define IPOPT_TS_TSANDADDR      1               /* timestamps and addresses */
#define IPOPT_TS_PRESPEC        2               /* specified modules only */

/* bits for security (not byte swapped) */
#define IPOPT_SECUR_UNCLASS     0x0000
#define IPOPT_SECUR_CONFID      0xf135
#define IPOPT_SECUR_EFTO        0x789a
#define IPOPT_SECUR_MMMM        0xbc4d
#define IPOPT_SECUR_RESTR       0xaf13
#define IPOPT_SECUR_SECRET      0xd788
#define IPOPT_SECUR_TOPSECRET   0x6bc5

/*
 * Internet implementation parameters.
 */
#define MAXTTL          255             /* maximum time to live (seconds) */
#define IPFRAGTTL       60              /* time to live for frags, slowhz */
#define IPTTLDEC        1               /* subtracted when forwarding */

#define IP_MSS          576             /* default maximum segment size */

#endif /* __UNIX_NETINET_IP_H__ */
