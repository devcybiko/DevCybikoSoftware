#include <Cybiko.h>
#include "tcplib.h"
#include "tcperror.h"

struct module_t main_module;
char msgbuf[TCPMSG_MESSAGE_MAX];
char display[10][32];
char lineno=0;
char tmp[32];
long tcpqueue;

int dialog_show(char *title, char *text, char *rtn_s, int len);

void redraw()
{
	int i;

    DisplayGraphics_fill_screen( main_module.m_gfx, CLR_WHITE );
    DisplayGraphics_set_color( main_module.m_gfx, CLR_BLACK );
    DisplayGraphics_set_font( main_module.m_gfx, mini_normal_font );
    for(i=0; i<10; i++)
	{
		DisplayGraphics_draw_text( main_module.m_gfx, display[i], 0, i*10 );
	}
    DisplayGraphics_show( main_module.m_gfx );
}

void printf(char *s)
{
	strcpy(display[lineno++], s);
	redraw();
	if (lineno == 10) lineno=0;
}

void message_loop( struct module_t* ptr_main_module )
{
	bool exit_application = FALSE;
	struct Message *ptr_message;

	while( !exit_application )
	{
		struct Message* ptr_message = 
			cWinApp_get_message( ptr_main_module->m_process, 1, 1, MSG_USER );

		if (ptr_message == 0) continue;
	    if( Message_has_buffer( ptr_message ) )
		{
			Buffer_load( Message_get_buffer( ptr_message ), msgbuf,0,sizeof(msgbuf));
		}
		switch( ptr_message->msgid )
		{
			case MSG_SHUTUP: // Processes the system exit signal
			case MSG_QUIT:
				exit_application = TRUE;
				break;
			case MSG_GOTFOCUS: // Redraws the screen
				redraw();
				break;
			case MSG_KEYDOWN: // Processes keyboard messages
				if( Message_get_key_param( ptr_message )->scancode == KEY_ESC )
				{
					struct Message *ptr_msg;
					tcp_close(tcp_tcpqueue(msgbuf));
					ptr_msg = Message_new(sizeof(struct Message));
					ptr_msg->msgid = MSG_QUIT;
					Message_post(ptr_msg, cWinApp_get_name(main_module.m_process), get_own_id());
				}
				break;
			case MSG_USER: //process rf messages
			{
				printf("MSG_USER");
			}
			case MSG_TCP: // tcpkit status queue
			{
				printf("MSG_TCP");
				tcp_dispatch(msgbuf);
				if (tcp_errno)
				{
					printf("There was an error");
				}
				else
				{
					if (tcp_msgid(msgbuf) == TCPMSG_CONNECT_RESPONSE)
					{
						tcp_write(tcp_tcpqueue(msgbuf), "GET /index.html HTTP/1.0\n\n", 26);
						printf("Wrote message!");
					}
				}
				break;
			}
			case MSG_TCP+1: // tcpkit read data queue
			{
				char *s;
				static int in=0;
				static int x=0;
				static long llen;
				static short len;
				static int quotemode=0;

//				printf("Port 1");
				s = tcp_readdata(msgbuf, &llen);
				tcp_ack(tcp_tcpqueue(msgbuf));
//				sprintf(tmp, "tcpqueue=%d", tcp_tcpqueue(msgbuf));
//				printf(tmp);
				len = (short) llen;
				while(len>0)
				{
					//if (*s == '"') quotemode = !quotemode;
					//if (!quotemode && (*s == '<')) in++;
					//if (!in)
					{
						if (*s >= 32) tmp[x++]=*s;
						if (x==31)
						{
							tmp[x]=0;
							printf(tmp);
							x=0;
						}
					}
					//if (!quotemode && (*s == '>')) in--;
					s++;
					len--;
				}
				if (x)
				{
					tmp[x]=0;
					printf(tmp);
					x=0;
				}
				break;
			}
			default: // Processes all unprocessed messages
				cWinApp_defproc( ptr_main_module->m_process, ptr_message );
		}
		Message_delete( ptr_message );
    }
}

int dialog_show(char *title, char *text, char *rtn_s, int len)
{
    struct cDialog *dialog;
    int rc;

    dialog = (struct cDialog *) malloc(sizeof(struct cDialog));
    cDialog_ctor(dialog, title, text, mbOk | mbCancel | mbEdit, len, main_module.m_process);
    rc = cDialog_ShowModal(dialog);
    if (rc == mrOk)
    {
        cDialog_GetEditText(dialog, rtn_s);
        rtn_s[len]=0;
        rc = 1;
    }
    else
    {
        rc = 0;
    }

    cDialog_dtor(dialog, FREE_MEMORY);
    return rc;
}

long main(int argc, char* argv[], bool start)
{
    int i;
	long cyid;
	char tmp[32];

    init_module(&main_module);

	cyid = tcp_init(&main_module);
	sprintf(tmp, "cyid=%ld", cyid);
	printf(tmp);
	if (!cyid) goto EARLY_EXIT;
	
	tcpqueue = tcp_connect("alcorgrp.com", 80);
	sprintf(tmp, "sockid=%d", tcpqueue);
	printf(tmp);
	sprintf(tmp, "errno=%d", tcp_errno);
	printf(tmp);

	message_loop(&main_module);

EARLY_EXIT:
	return 0L;
}

