#ifndef _TCPLIB_H_
#define _TCPLIB_H_

long tcp_init(struct module_t *main_module);
long tcp_connect(char *addr, long port);
long tcp_write(long tcpqueue, char *data, int len);
long tcp_close(long tcpqueue);

long tcp_connect_accept(void *cr);
long tcp_write_accept(void *wr);
long tcp_close_accept(void *cr);
char *tcp_read_accept(void *rr);
long tcp_dispatch(void *xx);
long tcp_ack(long tcpqueue);

long tcp_swaplong(long x);
short tcp_swapshort(short x);

long tcp_msgid(void *xx);
long tcp_tcpqueue(void *xx);
char *tcp_readdata(void *xx, long *len);

extern long tcp_errno;
extern long tcp_timeout;
extern long tcp_serialno;

#define MSG_TCP (MSG_USER+256)
#define TCP_STATUS (MSG_TCP)
#define TCP_MAX_TCPQUEUES 64

#endif