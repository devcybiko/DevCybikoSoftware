Connect Four
12/8/01

Written by Tim Parkin
100% C code ;)

Another fun little game for all you cybiko gamers.  
Fully equipped with Artificial Intelligence.  Have fun!
