Readme for Crossbow

This is a simple game that i decide to make because i wanted to
learn b2c. In the game you shoot the crossbow at a moving target
by pressing the enter button. You may exit the game early by pushing
the space button. I made this for the classic so it may or may not
work right on the xtreme. If you have any comments, suggestions, or
bug reports email them to me at rocketo2000@yahoo.com. If there is
enough interest and suggestions then i will go and add to it or fix
it up.