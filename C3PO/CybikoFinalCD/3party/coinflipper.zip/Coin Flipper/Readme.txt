Coin Flipper Readme Documentation

Name: Coin Flipper
Version: 1.0
Author: CybiWare Software Group
Release date: 5-19-02
Url: www.csg.uni.cc

If you find any bugs or errors please report them too "bugs@csg.uni.cc". 
Also if you have any comments or suggestions please send them to 
"comments@csg.uni.cc". We will try to release a new version of Coin Flipper 
as soon as we fix any bugs found. As of now, there are no know bugs that we
know of so it should run pretty good. Have fun with Coin Flipper!

CybiWare Software Group
CybiWare@csg.uni.cc
www.csg.uni.cc