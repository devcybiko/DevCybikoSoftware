========================
= TweakGUI Version 1.0 =
========================

To install, unzip this file to C:\
Due to the nature of some of the OLE operations, any other directory will not work.