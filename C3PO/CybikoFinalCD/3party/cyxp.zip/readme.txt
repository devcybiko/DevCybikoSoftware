CyOS XP v1.8.4 Readme

This is the final version of CyOS XP with any major changes. Version 1.8.0 has been written from scratch (even the sprites). I'll slowly work up to version 2, the final version. From here on, only "small" features and bug fixes will be added. NEW IN 1.8.2: customize the wallpaper. Press <W> and type the filename. A nicer GUI for customizing the wallpaper will be added in the next release. (There are some minor problems with this. Make sure the file exists.)

IMPORTANT CHANGES IN VERSION 1.8.2
Press <X> to quit.

Version 1.8.4
Some minor performance improvements. Now shows up in root instead of applications. Uses filelist so you can choose the wallpaper more easily (will be improved more later).
Version 1.8.3
Fixed a problem that caused an application that is run to lose focus.
Version 1.8.2
Made Classic cursor smoother. Fixed a problem that caused the wrong application to be launched. Improved error reporting. Continuously redraws entire screen. Fixed a scrolling problem that occurred when you had less than seven applications. Improved application run procedure.
Version 1.8.1
Clears more memory before running app. Made Xtreme cursor smoother. Long filename problems fixed.
Version 1.8.0
All the basics are there again, and it's compatible with B2Cv5. It's also very small and fast.

Future Versions
Well, I'll only be improving until Professr's desktop is as good as XP and supports skins. Skin support: a control panel in which you can customize the pics for all sprites. Your choices will also be saved so you won't have to choose them again every time. I also plan support for the start menu, customizable cursor speed, optional password protection (would require XP to be desktop.app), amongst other things. Also the window will be minimizable and movable.

Cancelled: icons

Developer
Elliot Lee
AIM: gengar56
Email: gengar56@hotmail.com
Web: http://4cybiko.com

	Daily Cybiko News http://cn.4cybiko.com