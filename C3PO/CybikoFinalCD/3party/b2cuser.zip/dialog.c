// display a dialog if the file / pw doesnt exist
int _dialog(
        char *info,
        char *text,
		char *data,
		int len)
{
    struct cDialog *dialog;
    int rc;
	char *disp;

    dialog = (struct cDialog *) malloc(sizeof(struct cDialog));

    // alert dialog
    if (data) 
	{
		cDialog_ctor( dialog, info, text, mbOk | mbCancel | mbEdit, len, 
			b2c->main_module.m_process );
		cDialog_SetEditText(dialog, data);
	}
	else
	{
		cDialog_ctor( dialog, info, text, mbOk | mbCancel , 0, 
			b2c->main_module.m_process );
	}

    play_tone(-1);
	disp = (char* ) malloc( TGraph_get_bytes_total( b2c->main_module.m_gfx ) );
	memcpy(disp,
		DisplayGraphics_get_page_ptr(b2c->main_module.m_gfx, 0),
    TGraph_get_bytes_total(b2c->main_module.m_gfx));

	rc = cDialog_ShowModal(dialog);
    if ((rc == mrOk) && data)
     {
        cDialog_GetEditText(dialog, data);
     }
//	cText_dtor(line0, FREE_MEMORY);
	cDialog_dtor(dialog, FREE_MEMORY);
	TGraph_put_background(b2c->main_module.m_gfx, disp );
	free(disp);
	return rc==mrOk;
}
