void _mid(char *a, char *b, int start, int len)
{
    if (len >= 0)
    {
        strncpy(a, &b[start], len);
        a[len] = 0;
    }
    else
    {
        strcpy(a, &b[start]);
    }
}

void _right(char *a, char *b, int len)
{
    if (len > 0)
    {
        int x = strlen(b) - len;
        strcpy(a, &b[x]);
    }
}

void _sprint(char *var, char *fmt, ...)
{
    va_list parameters;

    va_start( parameters, fmt );
    vsprintf( var, fmt, parameters );
    va_end( parameters );

    DBG("<_sprint");
}

void _tokenize(char *s, char *seps, ...)
{
	va_list parameters;
	char *var;

	va_start( parameters, seps);
	while(var = va_arg(parameters, char *))
	{
		while(*s && (strchr(seps, *s)==0))
		{
			*var = *s;
			var++;
			s++;
		}
		*var = 0;
		if (*s) s++;
	}
	va_end(parameters);
}
