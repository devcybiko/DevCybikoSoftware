Read me

Boom! Classic

Catch the bombs with your paddle. If you miss 3 times you lose.
There are three powerups in the game. The 1up will give you 
an extra life. The magnet will draw bombs toward you. 
The <-> will make your paddle wider.

Move with left and right. Hold Tab to go faster. Use Del with
or without the left and right arrows to warp.

Try to get the high score to unlock cheats!


Boom! Explosive

Same basic rules as Boom! Classic. 

New to the game are the super explosives that can and will take a
chunk out of your paddle, and make you lose a life too. Avoid them.

There are 6 powerups this time around. The 3 basic Classic powerups 
a few others. Get the shield to block one super explosive. Get
the clock to randomly adjust the speed of the bombs (could go slower, 
could go faster!). Finally get the down arrow to go down since 
you gradually keep going up.

Also new to the game is the ability to store a powerup for
later. If you hold select and then collect a powerup, it 
will go into your storage box in the bottom right corner.
You can use it later by pressing Enter.

This adds a whole new strategy to the game. You could save the 
wide arrow for your last life when your paddle is little, or
you could save the down arrow for when you're just too close
to the action.


Boom flipped:

Same rules as Boom! just Flipped!




