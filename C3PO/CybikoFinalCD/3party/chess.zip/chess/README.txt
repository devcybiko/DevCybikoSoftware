chess for cybiko
by greg smith

----------------------
version 0.1 12/14/2002
----------------------

this is an initial release with lots of missing features. what is important
is that it does play the user against the computer.  some important
missing features is detecting check and whether the king has been taken
i am releasing the source code to the community as freeware so that
everyone can benefit from it.  i plan to improve the program incrementally.

ai_random.b2c is the algorithm for making any valid random move. it is
very easy to capture the king in this mode since i dont detect check
conditions. but its amazingly fast and is surprising that it actually
makes moves that are legal

more to come...
