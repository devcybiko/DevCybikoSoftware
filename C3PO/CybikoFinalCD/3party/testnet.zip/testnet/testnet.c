/*
NET TEST
by eAlex2k@hotmail.com


USE THIS HOWEVER YOU WANT, BUT DON'T 
TAKE CREDIT IF YOU POST THE SOURCE!!!

Launch one testnet on a cybiko that's connected to the
Console and press ESC at the "Select Partener" dialog.
On a second cybiko, launch testnet and select the other
from the partener list.

The cybiko that was waiting is suppose to trace to the
console "nettest: [MESSAGE] "

*/

#include <cybiko.h>
#define MSG_CHAT_STRING     MSG_USER + 1

struct module_t main_module;

bool net_send_string(char string_to_send[],cyid_t destination,
            char* process_name[], int message_id, int timeout)
{
 bool delivered = FALSE;
 struct Flag delivery_flag;
 struct Buffer message_buffer;
 struct Message* ptr_message = Message_new( sizeof( struct Message ) );
 ptr_message->msgid = message_id;
 Buffer_ctor( &message_buffer, 40, 1 );
 Buffer_store_string( &message_buffer, string_to_send, 0 );
 Message_attach_buffer( ptr_message, &message_buffer );
 Message_deliver( ptr_message, "testnet", destination, timeout );
 Flag_ctor(&delivery_flag, "MessageMutex", TRUE);
 if( Message_wait_delivery(ptr_message, &delivery_flag) == DL_SUCCESS )
  {delivered = TRUE;} else {delivered = FALSE; TRACE("FAILED!");}
 Flag_dtor(&delivery_flag, LEAVE_MEMORY);
 Message_delete(ptr_message);
 free(ptr_message);
 return delivered;
}



int main(int argc, char* argv[], bool start)
{
 char string_text[40];
 struct Message* ptr_message;
 cyid_t partner_id;
 bool app_exit = FALSE;

 init_module( &main_module );

 partner_id = select_partner( main_module.m_process,
                             SGP_NONE,0 );

 if( partner_id ) // DELIVER THE MESSAGE TO THE SELECTED PARTENER
 {
  if( net_send_string("Testin! 1, 2, 3... Testin!", partner_id,
  "nettest", MSG_CHAT_STRING, 60*1000) ) {TRACE("Delivered!");}
 }

 if( !partner_id )
 {


 while(!app_exit && cWinApp_has_focus(main_module.m_process) )
 {
  ptr_message = cWinApp_get_message(main_module.m_process,
  											   1, 1, MSG_CHAT_STRING);
  if(ptr_message)
  {
   switch(ptr_message->msgid)
   {
      //case MSG_SHUTUP:
      case MSG_QUIT: app_exit = TRUE; break;
      case MSG_GOTFOCUS: break;
      case MSG_KEYDOWN:
       if(Message_get_key_param(ptr_message)->scancode == KEY_ESC)
       {app_exit = TRUE; break;}

       if(Message_get_key_param(ptr_message)->scancode == KEY_ENTER)
       {TRACE( "Alex is da bomb!" ); break;}
      case MSG_CHAT_STRING:
       TRACE("MSG_CHAT_STRING");
       Buffer_load( Message_get_buffer( ptr_message ), string_text, 0, 0 );
       if( strlen(string_text) )
       {
        TRACE("MSG: %s", string_text);
        app_exit=TRUE;
       }
       break;

      default: cWinApp_defproc(main_module.m_process, ptr_message);
   }//switch()
  }//if()
	Message_delete(ptr_message);
 } //while(!exit_application)


 }//if( !partner_id )

 return 0;
}