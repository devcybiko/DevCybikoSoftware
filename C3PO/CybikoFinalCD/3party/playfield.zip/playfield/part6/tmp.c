#include "cybiko.h"
struct obj {
    int mysprite;
    int x;
    int y;
};

struct obj *objs;
struct obj xxx;

main()
{
    TRACE("%d", objs->x);
}
