This login mod will display a 4-digit graphic number
as a requirement for registering.

INSTALLATION:
Copy Register.php to $boarddir/Sources
Copy the entire directory 'digits' to $boarddir/YaBBImages/
(that means create a directory $boarddir/YaBBImages/digits
and copy all the files to that directory)

-Greg Smith
gsmith@alcorgrp.com
