//
// JED - Alternative GUI For the Cybiko
//
(C) 2002 Greg Smith
This software released under the GNU Public License as described at http://www.gnu.org/copyleft/gpl.html.

www.devcybiko.com
cybiko@alcorgrp.com