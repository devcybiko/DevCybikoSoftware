#ifndef ALCOR_H
#define ALCOR_H

#define MALLOC(n, obj) (obj *) (malloc(n*sizeof(obj)))
#define CALLOC(n, obj) (obj *) (calloc(n, sizeof(obj)))
#define FREE(m) free(m)
#define SAME(a,b) (0==strcmp(a,b))

#endif
