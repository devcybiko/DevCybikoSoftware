Thanx for trying my cybiko SDK Interface
i spent 7 hours nonstop programing this Yesterday (7/20/02)
it is pretty simple, it only operates in project mode, so you cant just open a C File by it's self.
it has editing for all of your files like Filer.list, makefile, and root.inf so you do less work.
It has a special feature to the left of your screen, pre coding to insert into your program.
I currently only have the include Files added to it so far. but it has many groups for you to add coding.
I designed this to help people design their own "Components" like in borland c++ builder.
Share your Pre coding designs, i Just Installed a Pckage maker/Installer

This is my Second Publishing

Although this isnt very Advanced, it is Very Useful.

Have Fun.