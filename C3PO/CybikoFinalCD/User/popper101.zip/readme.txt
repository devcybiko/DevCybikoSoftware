I would like to invite you to try an apllication I have created.

It is a primitive POP3 client that works with tcpKit.

It is still in the early stages and needs to be beat around quite a bit.

As it stands in this release it will pop mail from your server and save it into indivdual text files on your cybiko.

It will also decode any mime attachments which are base64 encoded. So you should be able to receive an .app or .pic file for use on the cybiko.

To set it up you need to have tcpGate.exe running on a pc serially connected to a cybiko classic running tcpjuncion.app. I am using tcpKit 1.1 for this.

It can be found at:
http://thinkable.us/DevCybiko/modules.php?name=Downloads&d_op=getit&lid=1694
or
http://forums.planetcybiko.net/index.php?showtopic=274

You can then run popper.app on any other cybiko to get your mail.
I have tried it on the classic original (v. 1.2.57) the classic (v. 1.3.57) and the Xtreme (v. 1.5.07).

You must also have enough free space on your device to hold the messages and attachments that you pop.

After launching the application the screen which lets you select the junction cybiko will appear. I find it works best with other cybikos in the area are turned off.

After selecting your juction you can click on "prefs" and fill in your user name, password, server and port where your messages can be found.

Your preferences will be saved on your cybiko in a file named "popper.dat".

After filling in your preferences you'll be ready to give it a try by clicking "pop".

If all goes well your messages will be saved individualy in files with names like "051205084605.txt" "yymmddhhmmss.txt" and so on. There is a little progress bar to keep you posted on how its going. If it stalls out for too long perhaps you should quit and try again. Or reset the junction which will occasionaly go crazy.

I find it works a more than half the time. After most Errors you can simply press "Pop" again to have it retry...

If you set delete = "No" in the prefs screen the messages will be left on the server and NOT deleted so you can try it as often as you like, popping the same messages. (This wastes lots of space on your cybiko.)

It still needs a lot of error checking and cleanup but I think its a good start.

You can find the whole thing here (source included).

Most likley you will just want to intall popper.app with ezloader but the whole project is there if you wish to have a peek at the source.

If you have time to try it I would appreciate any comments on how to make it better.

This version should be a good starting point for an email client and I hope to add more to it in the future. I would like to see it grow to have SMTP allowing you to send messages with attachments as well alowing one to email pics, apps and scripts to each other via the cybiko.

enjoy
-Six

cybiko@instantemail.net

