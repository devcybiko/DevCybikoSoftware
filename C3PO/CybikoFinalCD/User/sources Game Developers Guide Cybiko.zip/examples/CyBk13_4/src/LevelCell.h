#ifndef __LEVELCELL_H__
#define __LEVELCELL_H__

#include "cywin.h"
#include "enums.h"

//defines for walls
#define WALL_EAST	0
#define WALL_SOUTH	1
#define WALL_COUNT	2

#define DOT_COUNT	4

//levelcell struct
struct LevelCell
{
	bool Wall[WALL_COUNT];
	struct LevelCell* ptr_north;
	struct LevelCell* ptr_west;
	bool DotRow[DOT_COUNT];
	bool DotCol[DOT_COUNT];
};

//bitmaps for walls
struct Bitmap* ptr_bmpLevelCellWall[DIR_COUNT];
//width and height of level cells
int LevelCellWidth;
int LevelCellHeight;
//dot spacing
int LevelCellDotSpacingX;
int LevelCellDotSpacingY;
//dot wrapping
int LevelCellDotWrapX;
int LevelCellDotWrapY;

//constructor
struct LevelCell* LevelCell_ctor(struct LevelCell* ptr_lvlcell);

//destructor
void LevelCell_dtor(struct LevelCell* ptr_lvlcell,int mem_flag);

//setters
void LevelCell_set_wall(struct LevelCell* ptr_lvlcell,int wall,bool wallstatus);
void LevelCell_set_bitmap(int direction,struct Bitmap* ptr_bmp);
//void LevelCell_set_width(int width);
#define LevelCell_set_width(n) LevelCellWidth=(n)
//void LevelCell_set_height(int height);
#define LevelCell_set_height(n) LevelCellHeight=(n)
//void LevelCell_set_north(struct LevelCell* ptr_lvlcell,struct LevelCell* ptr_lvlcellnorth);
#define LevelCell_set_north(ptr1,ptr2) (ptr1)->ptr_north=(ptr2)
//void LevelCell_set_west(struct LevelCell* ptr_lvlcell,struct LevelCell* ptr_lvlcellwest);
#define LevelCell_set_west(ptr1,ptr2) (ptr1)->ptr_west=(ptr2)
//dot spacing
//void LevelCell_set_dot_spacing_x(int spacing);
#define LevelCell_set_dot_spacing_x(spacing) (LevelCellDotSpacingX=(spacing))
//void LevelCell_set_dot_spacing_y(int spacing);
#define LevelCell_set_dot_spacing_y(spacing) (LevelCellDotSpacingY=(spacing))
//dot wrapping
//void Levelcell_set_dot_wrap_x(int wrap);
#define LevelCell_set_dot_wrap_x(wrap) (LevelCellDotWrapX=(wrap));
//void Levelcell_set_dot_wrap_y(int wrap);
#define LevelCell_set_dot_wrap_y(wrap) (LevelCellDotWrapY=(wrap));
void LevelCell_set_dot_h(struct LevelCell* ptr_lvlcell,int pos,bool dot);
void LevelCell_set_dot_v(struct LevelCell* ptr_lvlcell,int pos,bool dot);

//getters
bool LevelCell_get_wall(struct LevelCell* ptr_lvlcell,int wall);
struct Bitmap* LevelCell_get_bitmap(int direction);
int LevelCell_get_width();
int LevelCell_get_height();
//void LevelCell_get_north(struct LevelCell* ptr_lvlcell);
#define LevelCell_get_north(ptr) (ptr)->ptr_north
//void LevelCell_get_west(struct LevelCell* ptr_lvlcell);
#define LevelCell_get_west(ptr) (ptr)->ptr_west
int LevelCell_get_dot_spacing_x();
int LevelCell_get_dot_spacing_y();
int LevelCell_get_dot_wrap_x();
int LevelCell_get_dot_wrap_y();
bool LevelCell_get_dot_h(struct LevelCell* ptr_lvlcell,int pos);
bool LevelCell_get_dot_v(struct LevelCell* ptr_lvlcell,int pos);

//calculate the dots for a cell
void LevelCell_calc_dots(struct LevelCell* ptr_lvlcell);

//draw a cell
void Graphics_draw_levelcell(struct Graphics* ptr_gfx,struct LevelCell* ptr_lvlcell,int cellx,int celly);
#define DisplayGraphics_draw_levelcell Graphics_draw_levelcell

#endif