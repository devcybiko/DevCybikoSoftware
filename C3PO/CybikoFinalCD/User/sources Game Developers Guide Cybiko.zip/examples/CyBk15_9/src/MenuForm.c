#ifndef __MENUFORM_C__
#define __MENUFORM_C__

#include "MenuForm.h"

//constructor
struct cMenuForm* cMenuForm_ctor(struct cMenuForm* ptr_menuform,
	struct rect_t* ptr_rect,
	char * name, 
	bool round, 
	struct cWinApp* ptr_winapp)
{
	//inherited constructor
	cCustomForm_ctor(ptr_menuform,ptr_rect,name,round,ptr_winapp);

	//store the list width(-4 or -6, depending on fullscreen or not)
	ptr_menuform->list_width=ptr_rect->w+((ptr_rect->w==164)?(-4):(-6));

	//allocate and construct cList
	ptr_menuform->ptr_list=(struct cList*)malloc(sizeof(struct cList));
	cList_ctor(ptr_menuform->ptr_list,ptr_menuform->list_width);

	//add cList to form
	cCustomForm_AddObj(ptr_menuform,ptr_menuform->ptr_list,0,0);

	//return newly created object
	return(ptr_menuform);
}

//destructor
void cMenuForm_dtor(struct cMenuForm* ptr_menuform,int mem_flag)
{
	//clean up the cList
	cList_dtor(ptr_menuform->ptr_list,FREE_MEMORY);
	//inherited destructor
	cCustomForm_dtor(ptr_menuform,mem_flag);
}

//show modally
int cMenuForm_ShowModal(struct cMenuForm* ptr_menuform)
{
	//variables
	struct Message* ptr_msg;
	bool done;

	//set the modal result
	ptr_menuform->ModalResult=mrNone;

	//set done flag to FALSE
	done=FALSE;

	//loop while not done
	while(!done)
	{
		//show the form
		cCustomForm_Show(ptr_menuform);
		//get a message
		ptr_msg=cWinApp_get_message(ptr_menuform->CurrApplication,0,1,MSG_USER);
		//process the message
		switch(ptr_msg->msgid)
		{
		case MSG_QUIT:
		case MSG_SHUTUP:
			{
				//we are done
				done=TRUE;
			}break;
		default:
			{
				//default message handling
				cMenuForm_proc(ptr_menuform,ptr_msg);
			}break;
		}
		//delete the message
		Message_delete(ptr_msg);
		//if the modal result has changed, we are done
		if(ptr_menuform->ModalResult!=mrNone) done=TRUE;
	}
	return(ptr_menuform->ModalResult);
}

//message handling procedure
bool cMenuForm_proc(struct cMenuForm* ptr_menuform, struct Message* ptr_msg)
{
	switch(ptr_msg->msgid)
	{
	case MSG_KEYDOWN:
		{
			//check for enter key
			if(Message_get_key_param(ptr_msg)->scancode==KEY_ENTER)
			{
				ptr_menuform->ModalResult=mrOk;
				return(TRUE);
			}
			//check for esc key
			if(Message_get_key_param(ptr_msg)->scancode==KEY_ESC)
			{
				ptr_menuform->ModalResult=mrCancel;
				return(TRUE);
			}
			//default message handling
			return(cCustomForm_proc(ptr_menuform,ptr_msg));
		}break;
	default:
		{
			//default message handling
			return(cCustomForm_proc(ptr_menuform,ptr_msg));
		}break;
	}
}

//adding a menu item
void cMenuForm_AddMenuItem(struct cMenuForm* ptr_menuform,char* item_name)
{
	struct cItem* ptr_item;

	//allocate item
	ptr_item=(struct cItem*)malloc(sizeof(struct cItem));

	//construct item
	cItem_ctor(ptr_item,ptr_menuform->list_width,item_name,FALSE,NULL,NULL);

	//add item to list
	cList_AddItem(ptr_menuform->ptr_list,ptr_item);
}

//retrieving index of selected menu item
int cMenuForm_GetSelectedMenuItem(struct cMenuForm* ptr_menuform)
{
	struct cObject* ptr_obj;

	//retrieve the selected object
	cList_GetSelectedObject(ptr_menuform->ptr_list);

	//find the index of the object
	return(cList_FindObj(ptr_menuform->ptr_list,ptr_obj));
}

#endif