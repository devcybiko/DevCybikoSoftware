#ifndef __MENUFORM_H__
#define __MENUFORM_H__

#include "cywin.h"

//menu form struct
struct cMenuForm: public cCustomForm
{
	struct cList* ptr_list;//pointer to a cList object
	int list_width;//width of the list
};

//constructor
struct cMenuForm* cMenuForm_ctor(struct cMenuForm* ptr_menuform,
	struct rect_t* ptr_rect,
	char * name, 
	bool round, 
	struct cWinApp* ptr_winapp);

//destructor
void cMenuForm_dtor(struct cMenuForm* ptr_menuform,int mem_flag);

//show modally
int cMenuForm_ShowModal(struct cMenuForm* ptr_menuform);

//message handling procedure
bool cMenuForm_proc(struct cMenuForm* ptr_menuform, struct Message* ptr_msg);

//adding a menu item
void cMenuForm_AddMenuItem(struct cMenuForm* ptr_menuform,char* item_name);

//retrieving index of selected menu item
int cMenuForm_GetSelectedMenuItem(struct cMenuForm* ptr_menuform);

//defines for other cCustomForm functions
#define cMenuForm_Disconnect cCustomForm_Disconnect
#define cMenuForm_Select cCustomForm_Select
#define cMenuForm_update cCustomForm_update
#define cMenuForm_GetParent cCustomForm_GetParent
#define cMenuForm_Hide cCustomForm_Hide
#define cMenuForm_Show cCustomForm_Show
#define cMenuForm_Disable cCustomForm_Disable
#define cMenuForm_Enable cCustomForm_Enable
#define cMenuForm_AddObj cCustomForm_AddObj
#define cMenuForm_InsObj cCustomForm_InsObj
#define cMenuForm_RemObj cCustomForm_RemObj
#define cMenuForm_SelectFirst cCustomForm_SelectFirst
#define cMenuForm_SelectPrev cCustomForm_SelectPrev
#define cMenuForm_SelectNext cCustomForm_SelectNext
#define cMenuForm_Scroll cCustomForm_Scroll
#define cMenuForm_Scroll_Ex cCustomForm_Scroll_Ex
#define cMenuForm_SendScroll cCustomForm_SendScroll
#define cMenuForm_GetShifty cCustomForm_GetShifty
#define cMenuForm_GetShiftx cCustomForm_GetShiftx
#define cMenuForm_GetCount cCustomForm_GetCount
#define cMenuForm_get_by_index cCustomForm_get_by_index
#define cMenuForm_FindObj cCustomForm_FindObj
#define cMenuForm_GetSelectedObject cCustomForm_GetSelectedObject

#endif