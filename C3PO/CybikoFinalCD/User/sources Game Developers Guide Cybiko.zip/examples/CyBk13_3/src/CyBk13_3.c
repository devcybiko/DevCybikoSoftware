/*
	*******************************************
	*CyBk12_3.C
	*
	*09MAY2001
	*
	*Level
	*******************************************
*/
//master include file for cybiko sdk
#include "cywin.h"
#include "MainCharacter.c"
#include "Monster.c"
#include "LevelCell.c"
#include "Level.c"

//image array indexes
#define BMP_DUDESHUT		 0
#define BMP_DUDEOPENN		 1
#define BMP_DUDEOPENE		 2
#define BMP_DUDEOPENS		 3
#define BMP_DUDEOPENW		 4
#define BMP_MONSTERBOD1		 5
#define BMP_MONSTERBOD2		 6
#define BMP_MONSTEREYESN	 7
#define BMP_MONSTEREYESE	 8
#define BMP_MONSTEREYESS	 9
#define BMP_MONSTEREYESW	10
#define BMP_WALLN			11
#define BMP_WALLE			12
#define BMP_WALLS			13
#define BMP_WALLW			14
#define BMP_COUNT			15

#define FRAME_PERIOD		50

//global variables
struct module_t main_module;	//main module

//image array
struct Bitmap* bmpArray[BMP_COUNT];

//level
struct Level lvl;

//frame counter
clock_t LastFrame;

//forward declarations for functions
bool Prog_Init();				//initialize the program
void Prog_Done();				//clean up for the program
void Prog_Loop();				//idle loop for the program

//message routing functions
bool Message_pump(struct cWinApp* ptr_win_app);
bool Message_handle(struct Message* ptr_message);

//message handling functions
//key handlers
bool OnKeyDown(int scancode,int mask,char ch);
bool OnKeyUp(int scancode,int mask,char ch);
bool OnCharTyped(int scancode,int mask,char ch);
//timer
bool OnTimer();
//power down
bool OnPowerDown();
//quit
bool OnQuit();
//paint
bool OnPaint();
//files
bool OnFiles();
//focus 
bool OnLostFocus();
bool OnGotFocus();
//launch
bool OnLaunch();
//device
bool OnDevice();
//ping
bool OnPing();
//shut up
bool OnShutUp();
//user
bool OnUser();

//main functions
long main(int argc, char* argv[], bool start)
{
	//declare local variable for message retrieval
	struct Message* ptr_message;

	//initialize the main module
	init_module(&main_module);

	//initialize the program
	if(Prog_Init())
	{
		//pump messages
		Message_pump(main_module.m_process);
	}

	//clean up after the program
	Prog_Done();

	//return 0, we're done
	return 0; 
}

bool Prog_Init()
{
	//initialization
	int index;
	int x,y;

	//allocate the bitmap array
	for(index=0;index<BMP_COUNT;index++)
	{
		bmpArray[index]=(struct Bitmap*)malloc(sizeof(struct Bitmap));
	}

	//load in the bitmaps
	Bitmap_ctor_Ex1(bmpArray[BMP_DUDESHUT],"dudeshut.pic");
	Bitmap_ctor_Ex1(bmpArray[BMP_DUDEOPENN],"dudeopenn.pic");
	Bitmap_ctor_Ex1(bmpArray[BMP_DUDEOPENE],"dudeopene.pic");
	Bitmap_ctor_Ex1(bmpArray[BMP_DUDEOPENS],"dudeopens.pic");
	Bitmap_ctor_Ex1(bmpArray[BMP_DUDEOPENW],"dudeopenw.pic");
	Bitmap_ctor_Ex1(bmpArray[BMP_MONSTERBOD1],"monsterbod1.pic");
	Bitmap_ctor_Ex1(bmpArray[BMP_MONSTERBOD2],"monsterbod2.pic");
	Bitmap_ctor_Ex1(bmpArray[BMP_MONSTEREYESN],"monstereyesn.pic");
	Bitmap_ctor_Ex1(bmpArray[BMP_MONSTEREYESE],"monstereyese.pic");
	Bitmap_ctor_Ex1(bmpArray[BMP_MONSTEREYESS],"monstereyess.pic");
	Bitmap_ctor_Ex1(bmpArray[BMP_MONSTEREYESW],"monstereyesw.pic");
	Bitmap_ctor_Ex1(bmpArray[BMP_WALLN],"walln.pic");
	Bitmap_ctor_Ex1(bmpArray[BMP_WALLE],"walle.pic");
	Bitmap_ctor_Ex1(bmpArray[BMP_WALLS],"walls.pic");
	Bitmap_ctor_Ex1(bmpArray[BMP_WALLW],"wallw.pic");

	//set up the levelcell images
	LevelCell_set_bitmap(DIR_NORTH,bmpArray[BMP_WALLN]);
	LevelCell_set_bitmap(DIR_EAST,bmpArray[BMP_WALLE]);
	LevelCell_set_bitmap(DIR_SOUTH,bmpArray[BMP_WALLS]);
	LevelCell_set_bitmap(DIR_WEST,bmpArray[BMP_WALLW]);

	//set level cell size
	LevelCell_set_width(8);
	LevelCell_set_height(8);

	//construct the level
	Level_ctor(&lvl);

	//make a random level
	for(x=0;x<LEVEL_WIDTH;x++)
	{
		for(y=0;y<LEVEL_HEIGHT;y++)
		{
			if(random(2)==0)
			{
				LevelCell_set_wall(Level_get_cell(&lvl,x,y),WALL_EAST,TRUE);
			}
			if(random(2)==0)
			{
				LevelCell_set_wall(Level_get_cell(&lvl,x,y),WALL_SOUTH,TRUE);
			}
		}
	}

	//set up the last frame time
	LastFrame=clock()-FRAME_PERIOD;

	//return TRUE if program initialized, and FALSE if it did not
	return(TRUE);
}

void Prog_Done()
{
	//cleanup
	int index;

	//destroy the bitmaps
	for(index=0;index<BMP_COUNT;index++)
	{
		Bitmap_dtor(bmpArray[index],FREE_MEMORY);
	}

	//destroy the level
	Level_dtor(&lvl,LEAVE_MEMORY);
}

void Prog_Loop()
{
	//idle loop

	//clear the screen white
	DisplayGraphics_fill_screen(main_module.m_gfx,CLR_WHITE);

	//draw the level
	DisplayGraphics_draw_level(main_module.m_gfx,&lvl);

	//show the screen
	DisplayGraphics_show(main_module.m_gfx);

}

bool Message_pump(struct cWinApp* ptr_win_app)
{
	bool quit=FALSE;
	struct Message* ptr_msg;
	//while there are still messages coming, handle them
	while(!quit)
	{	
		//grab a message
		ptr_msg=cWinApp_peek_message(ptr_win_app,TRUE,1,MSG_USER);
		if(ptr_msg)
		{
			//handle the message
			quit=!Message_handle(ptr_msg);
			//delete the message
			Message_delete(ptr_msg);
		}
		else
		{
			if(clock()-LastFrame>=FRAME_PERIOD)
			{
				//set last frame time
				LastFrame=clock();
				//perform idle loop
				Prog_Loop();
			}
		}
	}
}

bool Message_handle(struct Message* ptr_message)
{
	//if there is a message...
	if(ptr_message)
	{
		//...check what kind of message it is, and process it
		switch(ptr_message->msgid)
		{
		case MSG_KEYDOWN://key has been pressed
			{
				if(!OnKeyDown(Message_get_key_param(ptr_message)->scancode,Message_get_key_param(ptr_message)->mask,Message_get_key_param(ptr_message)->ch))
				{
					cWinApp_defproc(main_module.m_process, ptr_message);
				}
			}break;
		case MSG_KEYUP://key has been released
			{
				if(OnKeyUp(Message_get_key_param(ptr_message)->scancode,Message_get_key_param(ptr_message)->mask,Message_get_key_param(ptr_message)->ch))
				{
					cWinApp_defproc(main_module.m_process, ptr_message);
				}
			}break;
		case MSG_CHARTYPED://character has been generated
			{
				if(OnCharTyped(Message_get_key_param(ptr_message)->scancode,Message_get_key_param(ptr_message)->mask,Message_get_key_param(ptr_message)->ch))
				{
					cWinApp_defproc(main_module.m_process, ptr_message);
				}
			}break;
		case MSG_TIMER://timer event has fired
			{
				if(OnTimer())
				{
					cWinApp_defproc(main_module.m_process, ptr_message);
				}
			}break;
		case MSG_POWERDOWN://a powerdown message has been received
			{
				if(OnPowerDown())
				{
					cWinApp_defproc(main_module.m_process, ptr_message);
				}
			}break;
		case MSG_QUIT://a quit message has been received
			{
				if(OnQuit())
				{
					cWinApp_defproc(main_module.m_process, ptr_message);
				}
				return(FALSE);
			}break;
		case MSG_PAINT://a paint message has been received
			{
				if(OnPaint())
				{
					cWinApp_defproc(main_module.m_process, ptr_message);
				}
			}break;
		case MSG_FILES://a filed message has been received
			{
				if(OnFiles())
				{
					cWinApp_defproc(main_module.m_process, ptr_message);
				}
			}break;
		case MSG_LOSTFOCUS://the application has lost focus
			{
				if(OnLostFocus())
				{
					cWinApp_defproc(main_module.m_process, ptr_message);
				}
			}break;
		case MSG_GOTFOCUS://the application has received focus
			{
				if(OnGotFocus())
				{
					cWinApp_defproc(main_module.m_process, ptr_message);
				}
			}break;
		case MSG_LAUNCH://the application has received a launch message
			{
				if(OnLaunch())
				{
					cWinApp_defproc(main_module.m_process, ptr_message);
				}
			}break;
		case MSG_DEVICE://the application has received a device message
			{
				if(OnDevice())
				{
					cWinApp_defproc(main_module.m_process, ptr_message);
				}
			}break;
		case MSG_PING://a ping has been received
			{
				if(OnPing())
				{
					cWinApp_defproc(main_module.m_process, ptr_message);
				}
			}break;
		case MSG_SHUTUP://application has received a shutup message
			{
				if(OnShutUp())
				{
					cWinApp_defproc(main_module.m_process, ptr_message);
				}
				return(FALSE);
			}break;
		case MSG_USER://application has received a user message
			{
				if(OnUser())
				{
					cWinApp_defproc(main_module.m_process, ptr_message);
				}
			}break;
		default://unknown message
			{
				cWinApp_defproc(main_module.m_process, ptr_message);
			}break;
		}
	}
	return(TRUE);
}

bool OnKeyDown(int scancode,int mask,char ch)
{
	struct Message* ptr_msg;

	//if the escape key has been pressed, quit
	switch(scancode)
	{
	case KEY_ESC:
		{
			//create a new message
			ptr_msg=Message_new(sizeof(struct Message));
			//make it a quit message
			ptr_msg->msgid=MSG_QUIT;
			//send this message to the message queue
			Message_post(ptr_msg,cWinApp_get_name(main_module.m_process),get_own_id());
			//the message has been handled, so return true
			return(TRUE);
		}break;
	}
	//if message hasnt been handled, return FALSE
	return(FALSE);	
}

bool OnKeyUp(int scancode,int mask,char ch)
{
	//if message hasnt been handled, return FALSE
	return(FALSE);	
}

bool OnCharTyped(int scancode,int mask,char ch)
{
	//if message hasnt been handled, return FALSE
	return(FALSE);	
}

bool OnTimer()
{
	//if message hasnt been handled, return FALSE
	return(FALSE);	
}

bool OnPowerDown()
{
	//if message hasnt been handled, return FALSE
	return(FALSE);	
}

bool OnQuit()
{
	//if message hasnt been handled, return FALSE
	return(FALSE);	
}

bool OnPaint()
{
	//fill the screen with white
	DisplayGraphics_fill_screen(main_module.m_gfx,CLR_WHITE);

	//show the screen
	DisplayGraphics_show(main_module.m_gfx);

	//message has been handled
	return(TRUE);	
}

bool OnFiles()
{
	//if message hasnt been handled, return FALSE
	return(FALSE);	
}

bool OnLostFocus()
{
	//if message hasnt been handled, return FALSE
	return(FALSE);	
}

bool OnGotFocus()
{
	//do the same thing as OnPaint
	return(OnPaint());
}

bool OnLaunch()
{
	//if message hasnt been handled, return FALSE
	return(FALSE);	
}

bool OnDevice()
{
	//if message hasnt been handled, return FALSE
	return(FALSE);	
}

bool OnPing()
{
	//if message hasnt been handled, return FALSE
	return(FALSE);	
}

bool OnShutUp()
{
	//if message hasnt been handled, return FALSE
	return(FALSE);	
}

bool OnUser()
{
	//if message hasnt been handled, return FALSE
	return(FALSE);	
}

