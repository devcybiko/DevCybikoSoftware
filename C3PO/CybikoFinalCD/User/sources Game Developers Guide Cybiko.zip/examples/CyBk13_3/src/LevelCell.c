#ifndef __LEVELCELL_C__
#define __LEVELCELL_C__

#include "LevelCell.h"

//constructor
struct LevelCell* LevelCell_ctor(struct LevelCell* ptr_lvlcell)
{
	//set the walls to false
	int wall;
	for(wall=0;wall<WALL_COUNT;wall++)
	{
		LevelCell_set_wall(ptr_lvlcell,wall,FALSE);
	}
	//set north and west to null
	LevelCell_set_north(ptr_lvlcell,NULL);
	LevelCell_set_west(ptr_lvlcell,NULL);

	//return new levelcell
	return(ptr_lvlcell);
}

//destructor
void LevelCell_dtor(struct LevelCell* ptr_lvlcell,int mem_flag)
{
	//free memory if needed
	if(mem_flag==FREE_MEMORY)
	{
		free(ptr_lvlcell);
	}
}

//setters
void LevelCell_set_wall(struct LevelCell* ptr_lvlcell,int wall,bool wallstatus)
{
	//validate wall
	if(wall<0) return;
	if(wall>=WALL_COUNT) return;

	//set the wall status
	ptr_lvlcell->Wall[wall]=wallstatus;
}

void LevelCell_set_bitmap(int direction,struct Bitmap* ptr_bmp)
{
	//validate direction
	if(direction<0) return;
	if(direction>=DIR_COUNT) return;

	//set the bitmap
	ptr_bmpLevelCellWall[direction]=ptr_bmp;
}

//getters
bool LevelCell_get_wall(struct LevelCell* ptr_lvlcell,int wall)
{
	//validate wall
	if(wall<0) return(FALSE);
	if(wall>=WALL_COUNT) return(FALSE);

	//return the state of the wall
	return(ptr_lvlcell->Wall[wall]);
}

struct Bitmap* LevelCell_get_bitmap(int direction)
{
	//validate direction
	if(direction<0) return(NULL);
	if(direction>=DIR_COUNT) return(NULL);

	//return the bitmap
	return(ptr_bmpLevelCellWall[direction]);
}

int LevelCell_get_width()
{
	//return the width
	return(LevelCellWidth);
}

int LevelCell_get_height()
{
	//return the height
	return(LevelCellHeight);
}

//draw a cell
void Graphics_draw_levelcell(struct Graphics* ptr_gfx,struct LevelCell* ptr_lvlcell,int cellx,int celly)
{
	int x,y;
	//set transparent color to white
	Graphics_set_bkcolor(ptr_gfx,CLR_WHITE);
	//set draw mode
	Graphics_set_draw_mode(ptr_gfx,DM_OR);
	//determine x and y
	x=cellx*LevelCell_get_width();
	y=celly*LevelCell_get_height();
	//draw walls
	//north
	if(LevelCell_get_north(ptr_lvlcell)!=(struct LevelCell*)NULL)
	{
		if(LevelCell_get_wall(LevelCell_get_north(ptr_lvlcell),WALL_SOUTH))
		{
			Graphics_draw_bitmap(ptr_gfx,LevelCell_get_bitmap(DIR_NORTH),x,y,BM_NORMAL);
		}
	}
	//south
	if(LevelCell_get_wall(ptr_lvlcell,WALL_SOUTH))
	{
		Graphics_draw_bitmap(ptr_gfx,LevelCell_get_bitmap(DIR_SOUTH),x,y,BM_NORMAL);
	}
	//east
	if(LevelCell_get_wall(ptr_lvlcell,WALL_EAST))
	{
		Graphics_draw_bitmap(ptr_gfx,LevelCell_get_bitmap(DIR_EAST),x,y,BM_NORMAL);
	}
	//west
	if(LevelCell_get_west(ptr_lvlcell)!=(struct LevelCell*)NULL)
	{
		if(LevelCell_get_wall(LevelCell_get_west(ptr_lvlcell),WALL_EAST))
		{
			Graphics_draw_bitmap(ptr_gfx,LevelCell_get_bitmap(DIR_WEST),x,y,BM_NORMAL);
		}
	}
}


#endif