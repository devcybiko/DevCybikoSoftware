#ifndef __LEVEL_H__
#define __LEVEL_H__

#include "cywin.h"
#include "LevelCell.h"

//level defines
#define LEVEL_WIDTH		20
#define LEVEL_HEIGHT	12

//level struct
struct Level
{
	struct LevelCell Cell[LEVEL_WIDTH][LEVEL_HEIGHT];
};

//constructor
struct Level* Level_ctor(struct Level* ptr_lvl);

//destructor
void Level_dtor(struct Level* ptr_lvl,int mem_flag);

//getters
struct LevelCell* Level_get_cell(struct Level* ptr_lvl,int cellx, int celly);

//drawing functions
void Graphics_draw_level_section(struct Graphics* ptr_gfx,struct Level* ptr_lvl,int x,int y,int w,int h);
void Graphics_draw_level(struct Graphics* ptr_gfx,struct Level* ptr_lvl);
#define DisplayGraphics_draw_level_section Graphics_draw_level_section
#define DisplayGraphics_draw_level Graphics_draw_level

#endif