#ifndef __LEVEL_C__
#define __LEVEL_C__

#include "Level.h"
#include "LevelCell.c"

//constructor
struct Level* Level_ctor(struct Level* ptr_lvl)
{
	int x,y;
	int nx,ny;

	//construct the cells
	for(x=0;x<LEVEL_WIDTH;x++)
	{
		for(y=0;y<LEVEL_HEIGHT;y++)
		{
			//construct cell
			LevelCell_ctor(Level_get_cell(ptr_lvl,x,y));

			//determine locations of north and west
			nx=(x+LEVEL_WIDTH-1)%LEVEL_WIDTH;
			ny=(y+LEVEL_HEIGHT-1)%LEVEL_HEIGHT;

			//set north and west
			LevelCell_set_north(Level_get_cell(ptr_lvl,x,y),Level_get_cell(ptr_lvl,x,ny));
			LevelCell_set_west(Level_get_cell(ptr_lvl,x,y),Level_get_cell(ptr_lvl,nx,y));
		}
	}

	//return the new level
	return(ptr_lvl);
}

//destructor
void Level_dtor(struct Level* ptr_lvl,int mem_flag)
{
	int x,y;
	//destroy the level cells
	for(x=0;x<LEVEL_WIDTH;x++)
	{
		for(y=0;y<LEVEL_HEIGHT;y++)
		{
			//construct cell
			LevelCell_dtor(Level_get_cell(ptr_lvl,x,y),LEAVE_MEMORY);
		}
	}
	//free memory as appropriate
	if(mem_flag==FREE_MEMORY)
	{
		free(ptr_lvl);
	}
}


//getters
struct LevelCell* Level_get_cell(struct Level* ptr_lvl,int cellx, int celly)
{
	//validate cellx and celly
	if(cellx<0) return(NULL);
	if(celly<0) return(NULL);
	if(cellx>=LEVEL_WIDTH) return(NULL);
	if(celly>=LEVEL_HEIGHT) return(NULL);

	//return the cell
	return(&ptr_lvl->Cell[cellx][celly]);
}


//drawing functions
void Graphics_draw_level_section(struct Graphics* ptr_gfx,struct Level* ptr_lvl,int x,int y,int w,int h)
{
	int cellx,celly;
	//loop through cells
	for(cellx=x;cellx<(x+w);cellx++)
	{
		for(celly=y;celly<(y+h);celly++)
		{
			//draw the cell
			Graphics_draw_levelcell(ptr_gfx,Level_get_cell(ptr_lvl,cellx,celly),cellx,celly);
		}
	}
}

void Graphics_draw_level(struct Graphics* ptr_gfx,struct Level* ptr_lvl)
{
	Graphics_draw_level_section(ptr_gfx,ptr_lvl,0,0,LEVEL_WIDTH,LEVEL_HEIGHT);
}



#endif