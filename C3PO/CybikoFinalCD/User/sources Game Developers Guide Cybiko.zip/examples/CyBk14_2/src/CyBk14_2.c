/*
	*******************************************
	*CyBk13_2.C
	*
	*26APR2001
	*
	*Fixed/Proportional Font Demo
	*******************************************
*/
//master include file for cybiko sdk
#include "cywin.h"

//global variables
struct module_t main_module;	//main module
struct Font* fonts[11];			//font array
int currentfont;				//current font index
char buffer[80];				//character buffer

//forward declarations for functions
bool Prog_Init();				//initialize the program
void Prog_Done();				//clean up for the program

//message routing functions
bool Message_pump(struct cWinApp* ptr_win_app);
bool Message_handle(struct Message* ptr_message);

//message handling functions
//key handlers
bool OnKeyDown(int scancode,int mask,char ch);
bool OnKeyUp(int scancode,int mask,char ch);
bool OnCharTyped(int scancode,int mask,char ch);
//timer
bool OnTimer();
//power down
bool OnPowerDown();
//quit
bool OnQuit();
//paint
bool OnPaint();
//files
bool OnFiles();
//focus 
bool OnLostFocus();
bool OnGotFocus();
//launch
bool OnLaunch();
//device
bool OnDevice();
//ping
bool OnPing();
//shut up
bool OnShutUp();
//user
bool OnUser();

//main functions
long main(int argc, char* argv[], bool start)
{
	//declare local variable for message retrieval
	struct Message* ptr_message;

	//initialize the main module
	init_module(&main_module);

	//initialize the program
	if(Prog_Init())
	{
		//pump messages
		Message_pump(main_module.m_process);
	}

	//clean up after the program
	Prog_Done();

	//return 0, we're done
	return 0; 
}

bool Prog_Init()
{
	//initialization

	//allocate the fonts
	int count;
	for(count=0;count<11;count++)
	{
		fonts[count]=(struct Font*)malloc(sizeof(struct Font));
	}

	//construct the fonts
	Font_ctor_Ex(fonts[1],"coolnormal.fnt",FALSE,0);
	Font_ctor_Ex(fonts[2],"coolbold.fnt",FALSE,0);
	Font_ctor_Ex(fonts[3],"mininormal.fnt",FALSE,0);
	Font_ctor_Ex(fonts[4],"minibold.fnt",FALSE,0);
	Font_ctor_Ex(fonts[5],"fixedsys.fnt",TRUE,8);
	Font_ctor_Ex(fonts[6],"terminal5.fnt",TRUE,4);
	Font_ctor_Ex(fonts[7],"terminal6.fnt",TRUE,6);
	Font_ctor_Ex(fonts[8],"terminal9.fnt",TRUE,8);
	Font_ctor_Ex(fonts[9],"terminal12.fnt",TRUE,12);
	Font_ctor_Ex(fonts[0],"terminal14.fnt",TRUE,10);
	Font_ctor_Ex(fonts[10],"DosRomFont8x8.fnt",TRUE,0);

	//set the font names
	Font_set_name(fonts[1],"Cool Normal");
	Font_set_name(fonts[2],"Cool Bold");
	Font_set_name(fonts[3],"Mini Normal");
	Font_set_name(fonts[4],"Mini Bold");
	Font_set_name(fonts[5],"FixedSys");
	Font_set_name(fonts[6],"Terminal 5");
	Font_set_name(fonts[7],"Terminal 6");
	Font_set_name(fonts[8],"Terminal 9");
	Font_set_name(fonts[9],"Terminal 12");
	Font_set_name(fonts[0],"Terminal 14");

	//set the current font
	currentfont=1;

	//return TRUE if program initialized, and FALSE if it did not
	return(TRUE);
}

void Prog_Done()
{
	//cleanup

	//destroy the fonts
	int count;
	for(count=0;count<11;count++)
	{
		Font_dtor(fonts[count],FREE_MEMORY);
	}
}

bool Message_pump(struct cWinApp* ptr_win_app)
{
	bool quit=FALSE;
	struct Message* ptr_msg;
	//while there are still messages coming, handle them
	while(!quit)
	{	
		ptr_msg=cWinApp_get_message(ptr_win_app,0,1,MSG_USER);
		quit=!Message_handle(ptr_msg);
		Message_delete(ptr_msg);
	}
}

bool Message_handle(struct Message* ptr_message)
{
	//if there is a message...
	if(ptr_message)
	{
		//...check what kind of message it is, and process it
		switch(ptr_message->msgid)
		{
		case MSG_KEYDOWN://key has been pressed
			{
				if(!OnKeyDown(Message_get_key_param(ptr_message)->scancode,Message_get_key_param(ptr_message)->mask,Message_get_key_param(ptr_message)->ch))
				{
					cWinApp_defproc(main_module.m_process, ptr_message);
				}
			}break;
		case MSG_KEYUP://key has been released
			{
				if(OnKeyUp(Message_get_key_param(ptr_message)->scancode,Message_get_key_param(ptr_message)->mask,Message_get_key_param(ptr_message)->ch))
				{
					cWinApp_defproc(main_module.m_process, ptr_message);
				}
			}break;
		case MSG_CHARTYPED://character has been generated
			{
				if(OnCharTyped(Message_get_key_param(ptr_message)->scancode,Message_get_key_param(ptr_message)->mask,Message_get_key_param(ptr_message)->ch))
				{
					cWinApp_defproc(main_module.m_process, ptr_message);
				}
			}break;
		case MSG_TIMER://timer event has fired
			{
				if(OnTimer())
				{
					cWinApp_defproc(main_module.m_process, ptr_message);
				}
			}break;
		case MSG_POWERDOWN://a powerdown message has been received
			{
				if(OnPowerDown())
				{
					cWinApp_defproc(main_module.m_process, ptr_message);
				}
			}break;
		case MSG_QUIT://a quit message has been received
			{
				if(OnQuit())
				{
					cWinApp_defproc(main_module.m_process, ptr_message);
				}
				return(FALSE);
			}break;
		case MSG_PAINT://a paint message has been received
			{
				if(OnPaint())
				{
					cWinApp_defproc(main_module.m_process, ptr_message);
				}
			}break;
		case MSG_FILES://a filed message has been received
			{
				if(OnFiles())
				{
					cWinApp_defproc(main_module.m_process, ptr_message);
				}
			}break;
		case MSG_LOSTFOCUS://the application has lost focus
			{
				if(OnLostFocus())
				{
					cWinApp_defproc(main_module.m_process, ptr_message);
				}
			}break;
		case MSG_GOTFOCUS://the application has received focus
			{
				if(OnGotFocus())
				{
					cWinApp_defproc(main_module.m_process, ptr_message);
				}
			}break;
		case MSG_LAUNCH://the application has received a launch message
			{
				if(OnLaunch())
				{
					cWinApp_defproc(main_module.m_process, ptr_message);
				}
			}break;
		case MSG_DEVICE://the application has received a device message
			{
				if(OnDevice())
				{
					cWinApp_defproc(main_module.m_process, ptr_message);
				}
			}break;
		case MSG_PING://a ping has been received
			{
				if(OnPing())
				{
					cWinApp_defproc(main_module.m_process, ptr_message);
				}
			}break;
		case MSG_SHUTUP://application has received a shutup message
			{
				if(OnShutUp())
				{
					cWinApp_defproc(main_module.m_process, ptr_message);
				}
				return(FALSE);
			}break;
		case MSG_USER://application has received a user message
			{
				if(OnUser())
				{
					cWinApp_defproc(main_module.m_process, ptr_message);
				}
			}break;
		default://unknown message
			{
				cWinApp_defproc(main_module.m_process, ptr_message);
			}break;
		}
	}
	return(TRUE);
}

bool OnKeyDown(int scancode,int mask,char ch)
{
	struct Message* ptr_msg;

	//if the escape key has been pressed, quit
	if(scancode==KEY_ESC)
	{
		//create a new message
		ptr_msg=Message_new(sizeof(struct Message));
		//make it a quit message
		ptr_msg->msgid=MSG_QUIT;
		//send this message to the message queue
		Message_post(ptr_msg,cWinApp_get_name(main_module.m_process),get_own_id());
		//the message has been handled, so return true
		return(TRUE);
	}
	//change the font
	if(ch>='0' && ch<='9')
	{
		//set the current font
		currentfont=ch-'0';
		//repaint
		OnPaint();
	}
	//if message hasnt been handled, return FALSE
	return(FALSE);	
}

bool OnKeyUp(int scancode,int mask,char ch)
{
	//if message hasnt been handled, return FALSE
	return(FALSE);	
}

bool OnCharTyped(int scancode,int mask,char ch)
{
	//if message hasnt been handled, return FALSE
	return(FALSE);	
}

bool OnTimer()
{
	//if message hasnt been handled, return FALSE
	return(FALSE);	
}

bool OnPowerDown()
{
	//if message hasnt been handled, return FALSE
	return(FALSE);	
}

bool OnQuit()
{
	//if message hasnt been handled, return FALSE
	return(FALSE);	
}

bool OnPaint()
{
	//fill the screen with white
	DisplayGraphics_fill_screen(main_module.m_gfx,CLR_WHITE);
	DisplayGraphics_set_color(main_module.m_gfx,CLR_BLACK);

	//select the current font
	DisplayGraphics_set_font(main_module.m_gfx,fonts[currentfont]);

	//write text
	DisplayGraphics_draw_text(main_module.m_gfx,"The quick brown fox...",0,0);

	//draw the name of the font on the bottom of the screen
	DisplayGraphics_set_font(main_module.m_gfx,fonts[10]);
	DisplayGraphics_draw_text(main_module.m_gfx,Font_get_name(fonts[currentfont]),0,100-24);

	//display information about spacing
	sprintf(buffer,"Spacing: %d",Font_get_spacing(fonts[currentfont]));
	DisplayGraphics_draw_text(main_module.m_gfx,buffer,0,100-16);

	//display informatio about fixed vs proportional
	if(Font_is_fixed(fonts[currentfont]))
	{
		sprintf(buffer,"Fixed Width");
	}
	else
	{
		sprintf(buffer,"Proportional Width");
	}
	DisplayGraphics_draw_text(main_module.m_gfx,buffer,0,100-8);
	
	//show the screen
	DisplayGraphics_show(main_module.m_gfx);

	//message has been handled
	return(TRUE);	
}

bool OnFiles()
{
	//if message hasnt been handled, return FALSE
	return(FALSE);	
}

bool OnLostFocus()
{
	//if message hasnt been handled, return FALSE
	return(FALSE);	
}

bool OnGotFocus()
{
	//do the same thing as OnPaint
	return(OnPaint());
}

bool OnLaunch()
{
	//if message hasnt been handled, return FALSE
	return(FALSE);	
}

bool OnDevice()
{
	//if message hasnt been handled, return FALSE
	return(FALSE);	
}

bool OnPing()
{
	//if message hasnt been handled, return FALSE
	return(FALSE);	
}

bool OnShutUp()
{
	//if message hasnt been handled, return FALSE
	return(FALSE);	
}

bool OnUser()
{
	//if message hasnt been handled, return FALSE
	return(FALSE);	
}

