#ifndef __MAINCHARACTER_C__
#define __MAINCHARACTER_C__

#include "MainCharacter.h"
#include "Character.c"

//constructors
struct MainCharacter* MainCharacter_ctor(struct MainCharacter* ptr_maincharacter)
{
	//call extended constructor with default values
	MainCharacter_ctor_Ex(ptr_maincharacter,DIR_NORTH,0,0,MOUTHSTATE_SHUT);

	//return newly created object
	return(ptr_maincharacter);
}

struct MainCharacter* MainCharacter_ctor_Ex(struct MainCharacter* ptr_maincharacter,int dir,int x,int y,int mouthstate)
{
	//set the values for the attributes
	MainCharacter_set_direction(ptr_maincharacter,dir);
	MainCharacter_set_x(ptr_maincharacter,x);
	MainCharacter_set_y(ptr_maincharacter,y);
	MainCharacter_set_mouthstate(ptr_maincharacter,mouthstate);

	//return newly created object
	return(ptr_maincharacter);
}

//destructor
void MainCharacter_dtor(struct MainCharacter* ptr_maincharacter,int mem_flag)
{
	//nothing really to do here, so just send it to the base class's destructor
	Character_dtor(ptr_maincharacter,mem_flag);
}

//'getters'
struct Bitmap* MainCharacter_get_bitmap(struct MainCharacter* ptr_maincharacter,int dir,int mouthstate)
{
	//validate direction
	if(dir<0) return(NULL);
	if(dir>=DIR_COUNT) return(NULL);
	//validate mouthstate
	if(mouthstate<0) return(NULL);
	if(mouthstate>=MOUTHSTATE_COUNT) return(NULL);
	//return the proper bitmap
	return(ptr_maincharacter->bmpArray[dir][mouthstate]);
}

//'setters'
void MainCharacter_set_direction(struct MainCharacter* ptr_maincharacter,int dir)
{
	//validate direction
	dir=dir % DIR_COUNT;
	if(dir<0) dir+=DIR_COUNT;
	Character_set_direction(ptr_maincharacter,dir);
}

void MainCharacter_set_x(struct MainCharacter* ptr_maincharacter,int x)
{
	//validation later, just send to base class's function
	Character_set_x(ptr_maincharacter,x);
}

void MainCharacter_set_y(struct MainCharacter* ptr_maincharacter,int y)
{
	Character_set_y(ptr_maincharacter,y);
}

void MainCharacter_set_mouthstate(struct MainCharacter* ptr_maincharacter,int mouthstate)
{
	//validate mouthstate
	mouthstate=mouthstate % MOUTHSTATE_COUNT;
	if(mouthstate<0) mouthstate+=MOUTHSTATE_COUNT;
	//set the mouthstate
	ptr_maincharacter->MouthState=mouthstate;
}

void MainCharacter_set_bitmap(struct MainCharacter* ptr_maincharacter,int dir,int mouthstate,struct Bitmap* ptr_bitmap)
{
	//validate direction
	if(dir<0) return;
	if(dir>=DIR_COUNT) return;
	//validate mouthstate
	if(mouthstate<0) return;
	if(mouthstate>=MOUTHSTATE_COUNT) return;
	//set teh bitmap
	ptr_maincharacter->bmpArray[dir][mouthstate]=ptr_bitmap;
}

//retrieves the next x and y coordinates of the main character
int MainCharacter_get_next_x(struct MainCharacter* ptr_maincharacter)
{
	//give the next x position
	//what direction are we facing?
	switch(ptr_maincharacter->Direction)
	{
	case DIR_EAST:
		{
			//plus one
			return(ptr_maincharacter->X+1);
		}break;
	case DIR_WEST:
		{
			//minus one
			return(ptr_maincharacter->X-1);
		}break;
	}
	//all other cases, return the current x position
	return(ptr_maincharacter->X);
}

int MainCharacter_get_next_y(struct MainCharacter* ptr_maincharacter)
{
	//give the next y position
	//what direction are we facing?
	switch(ptr_maincharacter->Direction)
	{
	case DIR_SOUTH:
		{
			//plus one
			return(ptr_maincharacter->Y+1);
		}break;
	case DIR_NORTH:
		{
			//minus one
			return(ptr_maincharacter->Y-1);
		}break;
	}
	//all other cases, return the current y position
	return(ptr_maincharacter->Y);
}

//moves the main character
void MainCharacter_move(struct MainCharacter* ptr_maincharacter,bool togglemouth,bool updateposition)
{
	//toggle mouth, if needed
	if(togglemouth) MainCharacter_toggle_mouth(ptr_maincharacter);
	//update position, if needed
	if(updateposition)
	{
		MainCharacter_set_x(ptr_maincharacter,MainCharacter_get_next_x(ptr_maincharacter));
		MainCharacter_set_y(ptr_maincharacter,MainCharacter_get_next_y(ptr_maincharacter));
	}
}

//toggles the mouth state
void MainCharacter_toggle_mouth(struct MainCharacter* ptr_maincharacter)
{
	//change the mouth state
	ptr_maincharacter->MouthState++;
	ptr_maincharacter->MouthState%=MOUTHSTATE_COUNT;
}

//draws the main character
void Graphics_draw_maincharacter(struct Graphics* ptr_gfx,struct MainCharacter* ptr_maincharacter)
{
	//set the drawing mode
	Graphics_set_draw_mode(ptr_gfx,DM_OR);
	//set background color
	Graphics_set_bkcolor(ptr_gfx,CLR_WHITE);
	//draw the appropriate bitmap at the appropriate position
	Graphics_draw_bitmap(ptr_gfx,MainCharacter_get_bitmap(ptr_maincharacter,MainCharacter_get_direction(ptr_maincharacter),MainCharacter_get_mouthstate(ptr_maincharacter)),MainCharacter_get_x(ptr_maincharacter),MainCharacter_get_y(ptr_maincharacter),BM_NORMAL);
}

#endif