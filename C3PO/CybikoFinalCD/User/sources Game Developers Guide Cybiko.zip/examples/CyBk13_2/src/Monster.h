#ifndef __MONSTER_H__
#define __MONSTER_H__

#include "Character.h"
#include "cywin.h"
#include "enums.h"

//frames of animation
#define MONSTERFRAME_ONE	0
#define MONSTERFRAME_TWO	1
#define	MONSTERFRAME_COUNT	2

//monster class
struct Monster:public Character
{
	bool Eaten;//the monster has been eaten
	int Frame;//the current animation frame
	struct Bitmap* bmpEyes[DIR_COUNT];//eye bitmaps
	struct Bitmap* bmpFrames[MONSTERFRAME_COUNT];//frame bitmaps
};

//power pellet counter
int PowerPelletCounter=0;

//power pellet counter functions
//void Monster_set_ppcounter(int ppc);
#define Monster_set_ppcounter(ppc) (PowerPelletCounter=(ppc))
int Monster_get_ppcounter();
bool Monster_is_ppcounter_on();
void Monster_dec_ppcounter();

//constructors
struct Monster* Monster_ctor(struct Monster* ptr_monster);
struct Monster* Monster_ctor_Ex(struct Monster* ptr_monster,int dir,int x,int y,bool eaten,int frame);

//destructor
void Monster_dtor(struct Monster* ptr_monster,int mem_flag);

//setters for monster
void Monster_set_direction(struct Monster* ptr_monster,int dir);
void Monster_set_x(struct Monster* ptr_monster,int x);
void Monster_set_y(struct Monster* ptr_monster,int y);
//void Monster_set_eaten(struct Monster* ptr_monster,bool eaten);
#define Monster_set_eaten(ptr,eaten) ((ptr)->Eaten=eaten)
void Monster_set_frame(struct Monster* ptr_monster,int frame);
void Monster_set_eye_bitmap(struct Monster* ptr_monster,int dir,struct Bitmap* ptr_bmp);
void Monster_set_frame_bitmap(struct Monster* ptr_monster,int frame,struct Bitmap* ptr_bmp);

//getters for monster
//int Monster_get_direction(struct Monster* ptr_monster);
#define Monster_get_direction Character_get_direction
//int Monster_get_x(struct Monster* ptr_monster);
#define Monster_get_x Character_get_x
//int Monster_get_y(struct Monster* ptr_monster);
#define Monster_get_y Character_get_y
//bool Monster_get_eaten(struct Monster* ptr_monster);
#define Monster_get_eaten(ptr) ((ptr)->Eaten)
//int Monster_get_frame(struct Monster* ptr_monster);
#define Monster_get_frame(ptr) ((ptr)->Frame)
struct Bitmap* Monster_get_eye_bitmap(struct Monster* ptr_monster,int dir);
struct Bitmap* Monster_get_frame_bitmap(struct Monster* ptr_monster,int frame);

//retrieves the next x and y coordinates of the monster
int Monster_get_next_x(struct Monster* ptr_monster);
int Monster_get_next_y(struct Monster* ptr_monster);

//moves the monster
void Monster_move(struct Monster* ptr_monster,bool toggleframe,bool updateposition);

//toggles the frame
void Monster_toggle_frame(struct Monster* ptr_monster);

//draws the monster
void Graphics_draw_monster(struct Graphics* ptr_gfx,struct Monster* ptr_monster);
#define DisplayGraphics_draw_monster Graphics_draw_monster

#endif