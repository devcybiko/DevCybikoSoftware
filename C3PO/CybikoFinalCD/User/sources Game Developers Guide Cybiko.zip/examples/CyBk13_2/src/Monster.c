#ifndef __MONSTER_C__
#define __MONSTER_C__

#include "Monster.h"
#include "Character.c"

//power pellet counter functions
int Monster_get_ppcounter()
{
	//return the power pellet counter
	return(PowerPelletCounter);
}

bool Monster_is_ppcounter_on()
{
	//return the state of the power pellet counter
	return(PowerPelletCounter>0);
}

void Monster_dec_ppcounter()
{
	//decreate counter if counter is on
	if(Monster_is_ppcounter_on()) PowerPelletCounter--;
}

//constructors
struct Monster* Monster_ctor(struct Monster* ptr_monster)
{
	//call the Ex constructor with default values
	return(Monster_ctor_Ex(ptr_monster,0,0,0,FALSE,MONSTERFRAME_ONE));
}

struct Monster* Monster_ctor_Ex(struct Monster* ptr_monster,int dir,int x,int y,bool eaten,int frame)
{
	//set values for attributes
	Monster_set_direction(ptr_monster,dir);
	Monster_set_x(ptr_monster,x);
	Monster_set_y(ptr_monster,y);
	Monster_set_eaten(ptr_monster,FALSE);
	Monster_set_frame(ptr_monster,MONSTERFRAME_ONE);

	//return newly constructed monster
	return(ptr_monster);
}


//destructor
void Monster_dtor(struct Monster* ptr_monster,int mem_flag)
{
	//nothing to do here, so just call the inherited destructor
	Character_dtor(ptr_monster,mem_flag);
}


//setters for monster
void Monster_set_direction(struct Monster* ptr_monster,int dir)
{
	//validate direction
	dir=dir % DIR_COUNT;
	if(dir<0) dir+=DIR_COUNT;
	Character_set_direction(ptr_monster,dir);
}

void Monster_set_x(struct Monster* ptr_monster,int x)
{
	//validation later, just send to base class's function
	Character_set_x(ptr_monster,x);
}

void Monster_set_y(struct Monster* ptr_monster,int y)
{
	//validation later, just send to base class's function
	Character_set_y(ptr_monster,y);
}

void Monster_set_frame(struct Monster* ptr_monster,int frame)
{
	//validate frame
	frame%=MONSTERFRAME_COUNT;
	if(frame<0) frame+=MONSTERFRAME_COUNT;
	ptr_monster->Frame=frame;
}

void Monster_set_eye_bitmap(struct Monster* ptr_monster,int dir,struct Bitmap* ptr_bmp)
{
	//validate direction
	if(dir<0) return;
	if(dir>=DIR_COUNT) return;
	//assign bitmap
	ptr_monster->bmpEyes[dir]=ptr_bmp;
}

void Monster_set_frame_bitmap(struct Monster* ptr_monster,int frame,struct Bitmap* ptr_bmp)
{
	//validate frame
	if(frame<0) return;
	if(frame>=MONSTERFRAME_COUNT) return;
	//assign bitmap
	ptr_monster->bmpFrames[frame]=ptr_bmp;
}


//getters for monster
struct Bitmap* Monster_get_eye_bitmap(struct Monster* ptr_monster,int dir)
{
	//validate direction
	if(dir<0) return(NULL);
	if(dir>=DIR_COUNT) return(NULL);
	//return bitmap
	return(ptr_monster->bmpEyes[dir]);
}

struct Bitmap* Monster_get_frame_bitmap(struct Monster* ptr_monster,int frame)
{
	//validate frame
	if(frame<0) return(NULL);
	if(frame>=MONSTERFRAME_COUNT) return(NULL);
	//return bitmap
	return(ptr_monster->bmpFrames[frame]);
}

//retrieves the next x and y coordinates of the monster
int Monster_get_next_x(struct Monster* ptr_monster)
{
	//check direction
	switch(ptr_monster->Direction)
	{
	case DIR_EAST:
		{
			//add one
			return(ptr_monster->X+1);
		}break;
	case DIR_WEST:
		{
			//subtract one
			return(ptr_monster->X-1);
		}break;
	}
	//return default
	return(ptr_monster->X);
}

int Monster_get_next_y(struct Monster* ptr_monster)
{
	//check direction
	switch(ptr_monster->Direction)
	{
	case DIR_SOUTH:
		{
			//add one
			return(ptr_monster->Y+1);
		}break;
	case DIR_NORTH:
		{
			//subtract one
			return(ptr_monster->Y-1);
		}break;
	}
	//return default
	return(ptr_monster->Y);
}

//moves the monster
void Monster_move(struct Monster* ptr_monster,bool toggleframe,bool updateposition)
{
	//update frame as required
	if(toggleframe) Monster_toggle_frame(ptr_monster);
	//update position as required
	if(updateposition)
	{
		ptr_monster->X=Monster_get_next_x(ptr_monster);
		ptr_monster->Y=Monster_get_next_y(ptr_monster);
	}
}

//toggles the frame
void Monster_toggle_frame(struct Monster* ptr_monster)
{
	//add one to the frame
	ptr_monster->Frame++;
	//wrap around
	ptr_monster->Frame%=MONSTERFRAME_COUNT;
}

//draws the monster
void Graphics_draw_monster(struct Graphics* ptr_gfx,struct Monster* ptr_monster)
{
	//do we draw the body?
	bool drawbody;
	drawbody=TRUE;//initially, assume we are drawing the body
	//if monster is eaten, do not draw the body
	if(Monster_get_eaten(ptr_monster)) drawbody=FALSE;
	//if power pellet counter is on, and frame is MONSTERFRAME_TWO, don't draw the body
	if(Monster_is_ppcounter_on() && Monster_get_frame(ptr_monster)==MONSTERFRAME_TWO) drawbody=FALSE;
	//set the drawing mode
	Graphics_set_draw_mode(ptr_gfx,DM_OR);
	//set background color
	Graphics_set_bkcolor(ptr_gfx,CLR_WHITE);
	//if we are drawing the body, do so
	if(drawbody)
	{
		Graphics_draw_bitmap(ptr_gfx,Monster_get_frame_bitmap(ptr_monster,Monster_get_frame(ptr_monster)),Monster_get_x(ptr_monster),Monster_get_y(ptr_monster),BM_NORMAL);
	}
	//draw the eyes
	Graphics_draw_bitmap(ptr_gfx,Monster_get_eye_bitmap(ptr_monster,Monster_get_direction(ptr_monster)),Monster_get_x(ptr_monster),Monster_get_y(ptr_monster),BM_NORMAL);
}

#endif