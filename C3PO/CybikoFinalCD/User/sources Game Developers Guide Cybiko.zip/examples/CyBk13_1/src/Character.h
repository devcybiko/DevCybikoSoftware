#ifndef __CHARACTER_H__
#define __CHARACTER_H__

//character struct
struct Character
{
	int Direction;//direction character is facing
	int X,Y;//position of the character
};

//constructors
struct Character* Character_ctor(struct Character* ptr_chr);
struct Character* Character_ctor_Ex(struct Character* ptr_chr,int dir,int x,int y);

//destructor
void Character_dtor(struct Character* ptr_chr,int mem_flag);

//setters
//void Character_set_direction(struct Character* ptr_chr,int dir);
#define Character_set_direction(ptr,dir) ((ptr)->Direction=(dir))
//void Character_set_x(struct Character* ptr_chr,int x);
#define Character_set_x(ptr,x) ((ptr)->X=(x))
//void Character_set_y(struct Character* ptr_chr,int y);
#define Character_set_y(ptr,y) ((ptr)->Y=(y))

//getters
//int Character_get_direction(struct Character* ptr_chr);
#define Character_get_direction(ptr) ((ptr)->Direction)
//int Character_get_x(struct Character* ptr_chr);
#define Character_get_x(ptr) ((ptr)->X)
//int Character_get_y(struct Character* ptr_chr);
#define Character_get_y(ptr) ((ptr)->Y)

#endif