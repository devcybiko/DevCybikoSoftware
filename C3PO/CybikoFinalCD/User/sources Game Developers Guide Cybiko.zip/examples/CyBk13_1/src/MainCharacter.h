#ifndef __MAINCHARACTER_H__
#define __MAINCHARACTER_H__

#include "Character.h"
#include "cywin.h"
#include "enums.h"

//mouth states
#define MOUTHSTATE_OPEN		0
#define MOUTHSTATE_SHUT		1
#define MOUTHSTATE_COUNT	2

//main character struct
struct MainCharacter: public Character
{
	//mouth state
	int MouthState;
	//bitmaps
	struct Bitmap* bmpArray[DIR_COUNT][MOUTHSTATE_COUNT];
};

//constructors
struct MainCharacter* MainCharacter_ctor(struct MainCharacter* ptr_maincharacter);
struct MainCharacter* MainCharacter_ctor_Ex(struct MainCharacter* ptr_maincharacter,int dir,int x,int y,int mouthstate);

//destructor
void MainCharacter_dtor(struct MainCharacter* ptr_maincharacter,int mem_flag);

//'getters'
#define MainCharacter_get_direction Character_get_direction
#define MainCharacter_get_x Character_get_x
#define MainCharacter_get_y Character_get_y
//int MainCharacter_get_mouthstate(struct Maincharacter* ptr_maincharacter);
#define MainCharacter_get_mouthstate(ptr) (ptr->MouthState)
struct Bitmap* MainCharacter_get_bitmap(struct MainCharacter* ptr_maincharacter,int dir,int mouthstate);

//'setters'
void MainCharacter_set_direction(struct MainCharacter* ptr_maincharacter,int dir);
void MainCharacter_set_x(struct MainCharacter* ptr_maincharacter,int x);
void MainCharacter_set_y(struct MainCharacter* ptr_maincharacter,int y);
void MainCharacter_set_mouthstate(struct MainCharacter* ptr_maincharacter,int mouthstate);
void MainCharacter_set_bitmap(struct MainCharacter* ptr_maincharacter,int dir,int mouthstate,struct Bitmap* ptr_bitmap);

//retrieves the next x and y coordinates of the main character
int MainCharacter_get_next_x(struct MainCharacter* ptr_maincharacter);
int MainCharacter_get_next_y(struct MainCharacter* ptr_maincharacter);

//moves the main character
void MainCharacter_move(struct MainCharacter* ptr_maincharacter,bool togglemouth,bool updateposition);

//toggles the mouth state
int MainCharacter_toggle_mouth(struct MainCharacter* ptr_maincharacter);

//draws the main character
void Graphics_draw_maincharacter(struct Graphics* ptr_gfx,struct MainCharacter* ptr_maincharacter);
#define DisplayGraphics_draw_maincharacter Graphics_draw_maincharacter

#endif