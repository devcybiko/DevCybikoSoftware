#ifndef __ENUMS_H__
#define __ENUMS_H__

//directions
#define DIR_NORTH	0
#define DIR_EAST	1
#define DIR_SOUTH	2
#define DIR_WEST	3
#define DIR_COUNT	4



#endif