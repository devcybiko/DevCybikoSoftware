#ifndef __CHARACTER_C__
#define __CHARACTER_C__

#include "Character.h"

//constructors
//default constructor
struct Character* Character_ctor(struct Character* ptr_chr)
{
	//call extended constructor with default values
	Character_ctor_Ex(ptr_chr,0,0,0);

	//return the newly created Character object
	return(ptr_chr);
}

//extended constructor
struct Character* Character_ctor_Ex(struct Character* ptr_chr,int dir,int x,int y)
{
	//set the attributes
	Character_set_direction(ptr_chr,dir);
	Character_set_x(ptr_chr,x);
	Character_set_y(ptr_chr,y);

	//return the newly created Character object
	return(ptr_chr);
}

//destructor
void Character_dtor(struct Character* ptr_chr,int mem_flag)
{
	//if mem_flag == FREE_MEMORY, then deallocate object
	if(mem_flag==FREE_MEMORY)
	{
		free(ptr_chr);
	}
}

#endif