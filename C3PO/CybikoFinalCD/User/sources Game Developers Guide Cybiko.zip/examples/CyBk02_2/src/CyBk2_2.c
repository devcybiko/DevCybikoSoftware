/*
	*******************************************
	*CyBk2_2.C
	*
	*16FEB2001
	*
	*Cybiko style Hello World application
	*******************************************
*/
//master include file for cybiko sdk
#include "cywin.h"

//global variables
struct module_t main_module;	//main module
bool exit_application;			//exit application flag

//forward declarations for functions
bool Prog_Init();				//initialize the program
void Prog_Loop();				//idle loop for the program
void Prog_Done();				//clean up for the program

//main functions
long main(int argc, char* argv[], bool start)
{
	//declare local variable for message retrieval
	struct Message* ptr_message;

	//initialize the main module
	init_module(&main_module);

	//initialize the program
	exit_application=!Prog_Init();

	//while program is still running
	while(!exit_application)
	{
		//check for a message
		ptr_message = cWinApp_get_message(main_module.m_process,1,1,MSG_USER);

		//if there is a message...
		if(ptr_message)
		{
			//...check what kind of message it is, and process it
			switch(ptr_message->msgid)
			{
			case MSG_SHUTUP:     //  Processes system exit signal.
			case MSG_QUIT:
				exit_application = TRUE;
				break;
			case MSG_GOTFOCUS:   //  Redraws screen.
				break;
			case MSG_KEYDOWN:    //  Processes keyboard messages.
				if(Message_get_key_param(ptr_message)->scancode == KEY_ESC)//escape key has been pressed
				{
					exit_application = TRUE;	//set the exit flag
					break;
				}
			default:             //  Processes all unprocessed messages.
				cWinApp_defproc(main_module.m_process, ptr_message);
			}
			
			//delete the message
			Message_delete(ptr_message);
		}
		else
		{
			//no message, so execute an idle loop
			Prog_Loop();
		}
	}  //  while(!exit_application)  

	//clean up after the program
	Prog_Done();

	//return 0, we're done
	return 0; 
}

bool Prog_Init()
{
	//initialization

	//return TRUE if program initialized, and FALSE if it did not
	return(TRUE);
}

void Prog_Loop()
{
	//idle loop

	//fill the screen with white
	DisplayGraphics_fill_screen(main_module.m_gfx,CLR_WHITE);

	//select font
	DisplayGraphics_set_font(main_module.m_gfx,cool_normal_font);

	//select color
	DisplayGraphics_set_color(main_module.m_gfx,CLR_BLACK);

	//write text
	DisplayGraphics_draw_text(main_module.m_gfx,"Hello, world!",0,0);

	//show the screen
	DisplayGraphics_show(main_module.m_gfx);

}

void Prog_Done()
{
	//cleanup
}

