/*
	*******************************************
	*CyBk6_1.C
	*
	*27FEB2001
	*
	*"Quick Running" Framework
	*******************************************
*/
//master include file for cybiko sdk
#include "cywin.h"

//main functions
long main(int argc, char* argv[], bool start)
{
	//code for application goes here

	//return 0, we're done
	return 0; 
}

