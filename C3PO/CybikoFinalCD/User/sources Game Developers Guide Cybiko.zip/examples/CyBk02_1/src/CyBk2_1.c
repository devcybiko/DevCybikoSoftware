/*
	*************************************
	*CyBk2_1.C
	*
	*16FEB2001
	*
	*Simple "Hello, world!" application
	*************************************
*/

//Master Include file for entire Cybiko SDK
#include "cywin.h"

//main function
long main(int argc, char* argv[], bool start)
{
	//print to the console
	cprintf("Hello, world!");

	//exit the program, and return zero
	return(0); 
}

