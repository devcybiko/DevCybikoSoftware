/*
	*******************************************
	*CyBk16_2.C
	*
	*14JUL2001
	*
	*cy3d texture demo
	*******************************************
*/
//master include file for cybiko sdk
#include "cywin.h"
//include the cy3d stuff.
#include "cy3d.h"
#define MESSAGE_TIMEOUT	100

//global variables
struct module_t main_module;	//main module

//directkeyboard structure
struct DirectKeyboard* pdkbd;
//frame buffer
char* framebuffer;
//z buffer
fixed_t* zbuffer;
//the four corners.
point_t corner[4];
//wall texture
raster_t* wall;
//camera
point_t camera;
//direction
int direction;

//forward declarations for functions
bool Prog_Init();				//initialize the program
void Prog_Done();				//clean up for the program
void Prog_Loop();				//idle loop for the program

//wall drawing function
void DrawWall(int corner1, int corner2);

//message routing functions
bool Message_pump(struct cWinApp* ptr_win_app);
bool Message_handle(struct Message* ptr_message);

//message handling functions
//key handlers
bool OnKeyDown(int scancode,int mask,char ch);
bool OnKeyUp(int scancode,int mask,char ch);
bool OnCharTyped(int scancode,int mask,char ch);
//timer
bool OnTimer();
//power down
bool OnPowerDown();
//quit
bool OnQuit();
//paint
bool OnPaint();
//files
bool OnFiles();
//focus 
bool OnLostFocus();
bool OnGotFocus();
//launch
bool OnLaunch();
//device
bool OnDevice();
//ping
bool OnPing();
//shut up
bool OnShutUp();
//user
bool OnUser();

//main functions
long main(int argc, char* argv[], bool start)
{
	//declare local variable for message retrieval
	struct Message* ptr_message;

	//initialize the main module
	init_module(&main_module);

	//initialize the program
	if(Prog_Init())
	{
		//pump messages
		Message_pump(main_module.m_process);
	}

	//clean up after the program
	Prog_Done();

	//return 0, we're done
	return 0; 
}

bool Prog_Init()
{
	//initialization

	//initialize frame buffer
	framebuffer=DisplayGraphics_get_buf_addr(main_module.m_gfx);

	//initialize z buffer
	zbuffer=(fixed_t*)malloc(sizeof(fixed_t)*160);

	//initialize corners
	corner[0].p_x=-512;
	corner[0].p_y=-1024;
	corner[1].p_x=-512;
	corner[1].p_y=1024;
	corner[2].p_x=512;
	corner[2].p_y=1024;
	corner[3].p_x=512;
	corner[3].p_y=-1024;

	//load the wall
	wall=cy3d_load("wall.tex");

	//initialize camera
	camera.p_x=0;
	camera.p_y=0;

	//initialize direction
	direction=0;

	//initialize directkeyboard
	pdkbd=DirectKeyboard_get_instance();

	//return TRUE if program initialized, and FALSE if it did not
	return(TRUE);
}

void Prog_Done()
{
	//cleanup

	//clean up textures
	free(wall);

	//clean up z buffer
	free(zbuffer);

	//clean up direct keyboard
	DirectKeyboard_dtor(pdkbd,FREE_MEMORY);

}

void Prog_Loop()
{
	//idle loop

	//scan keyboard
	DirectKeyboard_scan(pdkbd);

	//check for KEY_LEFT
	if(DirectKeyboard_is_key_pressed(pdkbd,KEY_LEFT))
	{
		direction+=5;
	}
	//check for KEY_RIGHT
	if(DirectKeyboard_is_key_pressed(pdkbd,KEY_RIGHT))
	{
		direction+=355;
	}
	//make direction fit into 0-359 range
	direction%=360;
	//movement
	//KEY_UP
	if(DirectKeyboard_is_key_pressed(pdkbd,KEY_UP))
	{
		//move forwards
		camera=cy3d_move(camera,64,direction);
	}
	//KEY_DOWN
	if(DirectKeyboard_is_key_pressed(pdkbd,KEY_DOWN))
	{
		//move backwards
		camera=cy3d_move(camera,-64,direction);
	}

	//clear out the z buffer
	memset(zbuffer,0x7f,sizeof(fixed_t)*160);

	//draw the "sky"
	cy3d_draw_sky(framebuffer,CLR_WHITE);

	//draw the walls
	DrawWall(0,1);//corner 0 to corner 1
	DrawWall(1,2);//corner 1 to corner 2
	DrawWall(2,3);//corner 2 to corner 3
	DrawWall(3,0);//corner 3 to corner 0

	//mirror the frame buffer
	cy3d_mirror_buffer(framebuffer);

	//show the frame buffer
	DisplayGraphics_show(main_module.m_gfx);
}

bool Message_pump(struct cWinApp* ptr_win_app)
{
	bool quit=FALSE;
	struct Message* ptr_msg;
	//while there are still messages coming, handle them
	while(!quit)
	{	
		//grab a message
		ptr_msg=cWinApp_get_message(ptr_win_app,MESSAGE_TIMEOUT,1,MSG_USER);
		if(ptr_msg)
		{
			//handle the message
			quit=!Message_handle(ptr_msg);
			//delete the message
			Message_delete(ptr_msg);
		}
		//perform idle loop
		Prog_Loop();
	}
}

bool Message_handle(struct Message* ptr_message)
{
	//if there is a message...
	if(ptr_message)
	{
		//...check what kind of message it is, and process it
		switch(ptr_message->msgid)
		{
		case MSG_KEYDOWN://key has been pressed
			{
				if(!OnKeyDown(Message_get_key_param(ptr_message)->scancode,Message_get_key_param(ptr_message)->mask,Message_get_key_param(ptr_message)->ch))
				{
					cWinApp_defproc(main_module.m_process, ptr_message);
				}
			}break;
		case MSG_KEYUP://key has been released
			{
				if(!OnKeyUp(Message_get_key_param(ptr_message)->scancode,Message_get_key_param(ptr_message)->mask,Message_get_key_param(ptr_message)->ch))
				{
					cWinApp_defproc(main_module.m_process, ptr_message);
				}
			}break;
		case MSG_CHARTYPED://character has been generated
			{
				if(!OnCharTyped(Message_get_key_param(ptr_message)->scancode,Message_get_key_param(ptr_message)->mask,Message_get_key_param(ptr_message)->ch))
				{
					cWinApp_defproc(main_module.m_process, ptr_message);
				}
			}break;
		case MSG_TIMER://timer event has fired
			{
				if(!OnTimer())
				{
					cWinApp_defproc(main_module.m_process, ptr_message);
				}
			}break;
		case MSG_POWERDOWN://a powerdown message has been received
			{
				if(!OnPowerDown())
				{
					cWinApp_defproc(main_module.m_process, ptr_message);
				}
			}break;
		case MSG_QUIT://a quit message has been received
			{
				if(!OnQuit())
				{
					cWinApp_defproc(main_module.m_process, ptr_message);
				}
				return(FALSE);
			}break;
		case MSG_PAINT://a paint message has been received
			{
				if(!OnPaint())
				{
					cWinApp_defproc(main_module.m_process, ptr_message);
				}
			}break;
		case MSG_FILES://a filed message has been received
			{
				if(!OnFiles())
				{
					cWinApp_defproc(main_module.m_process, ptr_message);
				}
			}break;
		case MSG_LOSTFOCUS://the application has lost focus
			{
				if(!OnLostFocus())
				{
					cWinApp_defproc(main_module.m_process, ptr_message);
				}
			}break;
		case MSG_GOTFOCUS://the application has received focus
			{
				if(!OnGotFocus())
				{
					cWinApp_defproc(main_module.m_process, ptr_message);
				}
			}break;
		case MSG_LAUNCH://the application has received a launch message
			{
				if(!OnLaunch())
				{
					cWinApp_defproc(main_module.m_process, ptr_message);
				}
			}break;
		case MSG_DEVICE://the application has received a device message
			{
				if(!OnDevice())
				{
					cWinApp_defproc(main_module.m_process, ptr_message);
				}
			}break;
		case MSG_PING://a ping has been received
			{
				if(!OnPing())
				{
					cWinApp_defproc(main_module.m_process, ptr_message);
				}
			}break;
		case MSG_SHUTUP://application has received a shutup message
			{
				if(!OnShutUp())
				{
					cWinApp_defproc(main_module.m_process, ptr_message);
				}
				return(FALSE);
			}break;
		case MSG_USER://application has received a user message
			{
				if(!OnUser())
				{
					cWinApp_defproc(main_module.m_process, ptr_message);
				}
			}break;
		default://unknown message
			{
				cWinApp_defproc(main_module.m_process, ptr_message);
			}break;
		}
	}
	return(TRUE);
}

bool OnKeyDown(int scancode,int mask,char ch)
{
	struct Message* ptr_msg;

	//if the escape key has been pressed, quit
	if(scancode==KEY_ESC)
	{
		//create a new message
		ptr_msg=Message_new(sizeof(struct Message));
		//make it a quit message
		ptr_msg->msgid=MSG_QUIT;
		//send this message to the message queue
		Message_post(ptr_msg,cWinApp_get_name(main_module.m_process),get_own_id());
		//the message has been handled, so return true
		return(TRUE);
	}
	//if message hasnt been handled, return FALSE
	return(FALSE);	
}

bool OnKeyUp(int scancode,int mask,char ch)
{
	//if message hasnt been handled, return FALSE
	return(FALSE);	
}

bool OnCharTyped(int scancode,int mask,char ch)
{
	//if message hasnt been handled, return FALSE
	return(FALSE);	
}

bool OnTimer()
{
	//if message hasnt been handled, return FALSE
	return(FALSE);	
}

bool OnPowerDown()
{
	//if message hasnt been handled, return FALSE
	return(FALSE);	
}

bool OnQuit()
{
	//if message hasnt been handled, return FALSE
	return(FALSE);	
}

bool OnPaint()
{
	//fill the screen with white
	DisplayGraphics_fill_screen(main_module.m_gfx,CLR_WHITE);

	//show the screen
	DisplayGraphics_show(main_module.m_gfx);

	//message has been handled
	return(TRUE);	
}

bool OnFiles()
{
	//if message hasnt been handled, return FALSE
	return(FALSE);	
}

bool OnLostFocus()
{
	//if message hasnt been handled, return FALSE
	return(FALSE);	
}

bool OnGotFocus()
{
	//do the same thing as OnPaint
	return(OnPaint());
}

bool OnLaunch()
{
	//if message hasnt been handled, return FALSE
	return(FALSE);	
}

bool OnDevice()
{
	//if message hasnt been handled, return FALSE
	return(FALSE);	
}

bool OnPing()
{
	//if message hasnt been handled, return FALSE
	return(FALSE);	
}

bool OnShutUp()
{
	//if message hasnt been handled, return FALSE
	return(FALSE);	
}

bool OnUser()
{
	//if message hasnt been handled, return FALSE
	return(FALSE);	
}

void DrawWall(int corner1, int corner2)
{
	//temporary points
	point_t c1;
	point_t c2;

	//warp corners
	c1=cy3d_warp(corner[corner1],camera,direction);
	c2=cy3d_warp(corner[corner2],camera,direction);

	//draw the wall from corner1 to corner2
	cy3d_draw_wall(framebuffer,c1,c2,wall,0,0,zbuffer);
}

 

