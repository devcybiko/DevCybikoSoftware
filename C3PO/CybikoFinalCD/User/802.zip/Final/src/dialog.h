//==========================================================================
// This package provides a collection of dialog boxes for interacting with
// users.  Messages that arrive while a dialog is displayed on the screen
// are passed to the user-specified handler -- an advantage over the basic
// Cybiko dialogs.
//
// Brad Richards, Nate Waisbrot, 11/2002
//==========================================================================
#ifndef _DIALOG_H_
#define _DIALOG_H_

#include "cywin.h"

//--------------------------------------------------------------------------
// Must be called before any dialogs are used.
//--------------------------------------------------------------------------
void Dialogs_Init(struct module_t *main, bool (*func));

//--------------------------------------------------------------------------
// Destructor for the dialog package.  Call before quitting application.
//--------------------------------------------------------------------------
void Dialogs_Dest();

//--------------------------------------------------------------------------
// The dialog routines.  The first three expect printf-style format strings
// as parameters.  Get_Str_Dialog is a little odd -- it allocates a string
// of length "size" and returns it.  The user must free the string.
//--------------------------------------------------------------------------
void Error_Dialog(char *format, ...);
void Alert_Dialog(char *format, ...);
long Get_Int_Dialog(char *format, ...);
char* Get_Str_Dialog(char *msg ,int size);

#endif