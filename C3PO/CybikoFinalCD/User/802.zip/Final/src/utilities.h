#ifndef _UTIL_H_
#define _UTIL_H_

bool HostName(MACaddr id, char *name);
void PrintFrame(MAC_data_t *frame);
void TraceFrame(MAC_data_t *frame, char *str);
void InitStructures();
int IdxOf(MACaddr id);
void InitStructures();
MAC_data_t *GetOutEntry();
MAC_data_t *GetInEntry();
int IdxOf(MACaddr id);
short GetSeqNum(CNTL_t control);
bool GetRetrans(CNTL_t control);
FrameType GetFrameType(CNTL_t control);
void SetSeqNum(CNTL_t *control, short seq);
void SetRetrans(CNTL_t *control, bool flag);
void SetFrameType(CNTL_t *control, FrameType ft);
void ShowBits(CNTL_t control);
int SendACK(MACaddr dest);
void ProcessACK(MAC_data_t *frame);
void ProcessDATA(MAC_data_t *frame);
void ProcessBEACON(MAC_data_t *frame);
void TransmitBeacon();
int Acknowledge(MAC_data_t *frame);
void InitClock();
void Immediate_Send(char *data, int bufSize);

#endif