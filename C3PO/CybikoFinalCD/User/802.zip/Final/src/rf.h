//=========================================================================
// Header file for broadcast package
//
// Brad Richards, 10/2002
//=========================================================================

#ifndef _RF_H_
#define _RF_H_

#include "cywin.h"
#define MSG_RF_PVT	(MSG_USER + 1)
#define MSG_RF_ARRIVAL	(MSG_RF_PVT + 1)
#define MSG_RF_MAX	MSG_RF_ARRIVAL

#define RF_MAX_DATA_SIZE	74
#define MAX_HOSTS	10


// Init must be called before any of the other routines are used.

void RF_Init(struct module_t *main, char *name);

// Service should be called periodically to ensure it catches
// timeouts in the RF layer.

void RF_Service();

// You must pass events to the Handler so that RF has a chance
// to catch and process its internal messages

bool RF_Handler(struct Message *ptr_message);

// RF broadcasts the specified data to all other Cybikos.  The function 
// returns the number of bytes sent.  Note that this does NOT guarantee 
// that they all arrived safely at any or all remote machines.  In the 
// case of a collision or noise, our data may not have been delivered 
// intact.

int  RF_Tx(char *data, int size);

// Returns the status of the shared channel.

bool RF_InUse();

// Returns the # of ms since channel was last used.

clock_t RF_IdleTime();

// Fills in the user's string with some RF-layer statistics.  Make
// sure you pass it at least an 80-character string.

void RF_GetStats(char *tmpStr);


#endif

//=========================================================================
// 
// Below is a sample program framework, using the broadcast package.  Note
// the calls to RF_Init, RF_Service, and RF_Handler.
//
//
// long main(int argc, char* argv[], bool start)
// {
//  struct Message* ptr_message;	// Pointer used to inspect messages
// 	
//  ...
// 	
// 	RF_Init(&main_module, myName);
// 	
// 	while(!exit_application)
// 	{
// 	    ptr_message = cWinApp_get_message(main_module.m_process,1,1,MSG_RF_MAX);
// 	    if(ptr_message)
// 	    {
// 		  Message_Handler(ptr_message);	// Pass msg off to our handler
// 		  Message_delete(ptr_message);	// Delete it when we're done
// 	    }		
// 
// 	    // Must call this periodically to service physical layer
// 	    
// 	    RF_Service();
// 	}
// }
// 	
// 	
// bool Message_Handler(struct Message *ptr_message)
// {
//  bool handled=TRUE;
// 
//  // See if the I/O package wants to deal with this msg
//         
//  if (Dialog_Scroll(ptr_message))
// 	    return TRUE;
// 
// 	// If not, see if the RF package is interested
// 	
// 	if (RF_Handler(ptr_message))
// 	    return TRUE;
//     
//  // Otherwise, see if we want to handle it ourselves
//     	
// 	switch(ptr_message->msgid)
// 	{
// 	  case MSG_SHUTUP:	// Time to quit
// 	  case MSG_QUIT:
// 	      exit_application = TRUE;
// 	      break;
//
//	  case MSG_RF_ARRIVAL:	// Bcast data has arrived
//	      /* deal with it */
//   
// 	  case MSG_KEYDOWN:	// A key was pressed
//	      /* deal with it */
// 	      break;
// 	    
// 	  default:			//  Processes all unprocessed messages.
// 	    handled = cWinApp_defproc(main_module.m_process, ptr_message);
// 	}
// 	return handled;		// Report whether message was handled
// }
