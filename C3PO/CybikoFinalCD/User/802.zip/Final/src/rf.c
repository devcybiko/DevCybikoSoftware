//=========================================================================
// RF-based "physical layer".
//
// Brad Richards, 11/20/2002
//=========================================================================

// Uncomment the following defines for TRACE output.  When RF_DEBUG is
// defined, the RF code becomes incredibly verbose -- probably more so
// than is typically useful.  When ANNOUNCE_COLLISIONS is defined, 
// news of collisions is TRACEd on the console output, which might be
// useful in debugging code built atop rf.c.

//#define RF_DEBUG
#define ANNOUNCE_COLLISIONS


#include "RF.h"
#include "console.h"
#include "dialog.h"

#define RF_BCAST_ID	0xFFFFFFFF
#define WEIGHT		10	/* Used in computing delay averages */
#define RF_OVHD		(sizeof(struct Message) + sizeof(struct Buffer))
#define RF_HDR_SIZE	(sizeof(int) + sizeof(short))

// The RF_SPLIT constant determines how many copies of each transmission
// are sent.  With multiple copies, "simultaneous" transmissions will
// interleave and we can detect not only use but collisions.  The 
// RF_EXPAND constant represents the time dialation factor.

#define RF_SPLIT	5
#define RF_EXPAND	9


// Global variables

struct module_t *main_mod;	// Need to know about app
char *RF_appName;		// Pointer to argv[0]

bool RF_inUse;			// Is someone else sending?
bool RF_collision;		// Have incoming blips interleaved?
clock_t RF_EOT;			// Predicted end of incoming transmission
clock_t RF_lastUse;		// Last time the channel was in use
clock_t RF_avgBT;		// Avg delay, per bit, btw blips (x 2^7)
char RF_data[RF_MAX_DATA_SIZE];	// Temp buffer used in blip processing
cyid_t colliding[MAX_HOSTS];	// IDs of machines involved in collision
int numSending;			// # of remote machines colliding


// If blips are sent too close together, I can't recycle a static
// buffer -- the AUTODELETE wipes out the buffer as I'm attaching
// it to the next message.  Thus, I use an array of static buffers,
// one for each blip in a sequence.

struct Buffer RF_buf, RF_outBufs[RF_SPLIT];


// Forward Declaration

void ProcessBlip(struct Message* ptr_message);


//--------------------------------------------------------------------------
// Fills in a string containing stats info on the RF layer.  Currently,
// the only value that's printed is the average number of milliseconds
// it has taken to send a byte of data.
//--------------------------------------------------------------------------
void RF_GetStats(char *tmpStr)
{
	sprintf(tmpStr, "RF: %d ms/byte\n", RF_avgBT >> 7);
}

//--------------------------------------------------------------------------
// Initialize our internal variables, and record the module and app name.
//--------------------------------------------------------------------------
void RF_Init(struct module_t *main, char *name)
{
    	RF_inUse = FALSE;
	Busy_Off();
    	RF_collision = FALSE;
    	RF_avgBT = 3200;	// 20 << 7 + some
	RF_lastUse = clock();
	main_mod = main;
	RF_appName = name;
	numSending = 0;
}


//--------------------------------------------------------------------------
// Use the clock to detect the end of a transmission.  This should only
// be necessary if the last blip in a sequence was lost, otherwise we'll
// detect EOT when we see the blip.
//--------------------------------------------------------------------------
void RF_Service()
{
	// Check clock for EOT here
	if (RF_inUse && ((clock()-RF_EOT) > 0))
	{
#ifdef RF_DEBUG
	    TRACE("Clock is at predicted EOT (%lu vs %lu)", clock(), RF_EOT);
#endif
	    RF_inUse = FALSE;
	    Busy_Off();
#ifdef ANNOUNCE_COLLISIONS
	    TRACE("COLLISION over, at EOT");
#endif
	    RF_collision = FALSE;
	    numSending = 0;
	    RF_lastUse = clock();
	}
}


//--------------------------------------------------------------------------
// Return channel status.  Ideally, we'd check the queue for incoming blips
// and freshen up the status of the channel.  Unfortunately, we can't just
// get RF-layer messages and there's no way to handle non-RF messages.
//--------------------------------------------------------------------------
bool RF_InUse()
{
	return RF_inUse;
}

//--------------------------------------------------------------------------
// Return time elapsed since channel last in use.	
//--------------------------------------------------------------------------
clock_t RF_IdleTime()
{
	if (RF_inUse)
	    return 0;
	else
	    return (clock() - RF_lastUse);
}


//--------------------------------------------------------------------------
// Unfortunately, we need to have the user pass events to our handler so
// we can watch for incoming blips.  cWinApp_get_message doesn't work as
// advertised, and won't restrict itself to msgids within the range
// specified by the last two parameters.  Thus, the user's code would
// inadvertently grab incoming blips and discard them.
//--------------------------------------------------------------------------
bool RF_Handler(struct Message *ptr_message)
{
	if (ptr_message->msgid == MSG_RF_PVT) 
	{
	    ProcessBlip(ptr_message);	
	    return TRUE;
	}
	else
	    return FALSE;
}


//--------------------------------------------------------------------------
// Used to provide an estimate of the end of the current transmission, 
// so we can catch it with the clock if the don't get the last blip in
// the sequence.
//--------------------------------------------------------------------------
clock_t EstimateEOT(int seq, clock_t now, int size)
{
    return  now + 650 + ((size*RF_avgBT*(RF_SPLIT-seq-1)) >> 7);
}


//--------------------------------------------------------------------------
// This routine takes data from the user and broadcasts it to all units
// within range.  It sends RF_SPLIT copies of the data, with a 
// delay between copies (blips).  This ensures that we can detect an
// in-use channel, and that actual collisions won't wipe out all traces of
// channel use.
// 
// Between sends, we clear out the message queue.  This keeps it from
// filling up, but it also helps us detect collisions.  If we didn't drain
// the queue, we might discover messages from another Cybiko after our
// RF was complete and not realize that our send overlapped and was
// therefore a collision.
//
// The original version took a msgId as input, and raised that same msgId
// at the far side.  I've simplified it here so that a fixed msgId is used,
// though the mechanism for passing it with the data is still in place to
// make it easier to revert to the old mechanism.
//--------------------------------------------------------------------------

int RF_Tx(char *data, int size)
{
    int seq = 0;
    int totalSize;		// Required buffer size
    int count, i, delay;	// # of RFs, loop var
    int interval;		// Interveral between blip starts
    clock_t nextTx;		// Local clock value of next send
    clock_t start;		// milliseconds
    struct Message *message;	// Used to pass data to application
    short msgId = MSG_RF_ARRIVAL;
    int phySize;		// Num bytes, including Cybiko overhead
    struct Buffer *buf;

	Busy_On();
#ifdef RF_DEBUG		
	TRACE("Sending packet");
#endif
	start = clock();
	if (size > RF_MAX_DATA_SIZE) 
		size = RF_MAX_DATA_SIZE;

	totalSize = RF_HDR_SIZE + size;
	phySize = totalSize + RF_OVHD;
	delay = RF_EXPAND * 10 * phySize / 24;
	nextTx = clock() + delay;

	for (i=0; i<RF_SPLIT; i++)
	{
	    nextTx = (delay * i) + start;
	    while(clock() < nextTx);	// Wait for next start time

	    message = (struct Message*)Message_new(sizeof(struct Message));
	    message->msgid = MSG_RF_PVT;	
			
	    if (i > 0)
	    {
		buf = &(RF_outBufs[i]);			// Fill in buffer
		Buffer_ctor(buf, totalSize, 4);
		Buffer_set_int(buf, 0, i);
		Buffer_set_int(buf, 2, msgId);
		Buffer_store(buf, data, 4, size);
							// Attach and "send"
		Message_attach_buffer(message, buf);
	    }
	    Message_post(message, RF_appName, RF_BCAST_ID | MSG_AUTODELETE);

	    // Consume messages to discard incoming blips
  
	    while (message = cWinApp_get_message(main_mod->m_process,
	    					 1,1,MSG_RF_MAX))
		Message_delete(message);

	}

	RF_lastUse = clock();
	start = RF_lastUse - start;
#ifdef RF_DEBUG	
	TRACE("Sends took %d ms", start);
#endif
	sleep(250);
	Busy_Off();
	seq++;
	return size;
}


//--------------------------------------------------------------------------
// A utility function used by ProcessBlip.  It records the addresses of the
// Cybikos involved in a collision to help determine when the last of their
// transmissions has ended.
//--------------------------------------------------------------------------
bool Contains(cyid_t *addrs, cyid_t host, int n)
{
    int i;

	for(i=0; i<n; i++)
	    if (addrs[i]==host) return TRUE;

	return FALSE;
}


//--------------------------------------------------------------------------
// This function is run each time a new blip arrives.  It sets RF_inUse
// once a sequence begins to arrive, and detects collisions by watching
// for the interleaving of blips from different sources (or infers them if
// any blips go missing).  If all blips arrive, this function can
// determine when the channel is no longer in use.  But it also sets EOT
// to the estimated time at which the last transmission will end, in case
// the final blip is lost.
//
// If there's been no collision and all blips arrive intact, we assemble
// a new message and inject it into the queue for the user.  We give it
// the msgid requested by the sender.
//--------------------------------------------------------------------------
	
void ProcessBlip(struct Message* ptr_message)
{
    static nextSeq = 0;
    static clock_t startTime, lastBlip, tempEOT;
    static cyid_t source;
    cyid_t senderID;
    clock_t now, delta;
    short msgId;
    int seq, size;
    struct Buffer *bufPtr;
    struct Message *newMsg;
 

	now = clock();

	// First blip doesn't have a buffer -- tries to get through as
	// quickly as possible.
	
	senderID = Message_get_sender_id(ptr_message);
	if (!Message_has_buffer(ptr_message))
	{
	    size = 32;// Invent a size so EOT gets predicted
	    bufPtr = NULL;
	    seq = 0;
//	    msgId = <foo>;
#ifdef RF_DEBUG
	    TRACE("Seeing first blip");
#endif
        }
        else
        {
	    bufPtr = Message_get_buffer(ptr_message);
	    size = Buffer_get_size(bufPtr) - RF_HDR_SIZE;
#ifdef RF_DEBUG
	    if (size < 0)
		TRACE("Buffer's too small! (%d)", size+RF_HDR_SIZE);
#endif
	    seq = Buffer_get_int(bufPtr, 0);
	    msgId = (short)Buffer_get_int(bufPtr,2);
        }

	// Now figure out what to do with it.  First, see if the
	// channel was in use.  If not, this is the first point at
	// which we know it's being used.

	tempEOT = EstimateEOT(seq, now, size);

	if (!RF_inUse)
	{
#ifdef RF_DEBUG 
	    TRACE("New transmission from %u at %lu (%d)", senderID, now, seq);
#endif
	    RF_inUse = TRUE;
	    Busy_On();
	    lastBlip = now;
	    source = senderID;
	    numSending = 1;
	    colliding[0] = senderID;
	    if (seq == 0)		// Set start time
	    {
		RF_collision = FALSE;	
		startTime = now;
	    } else {
		RF_collision = TRUE;
#if (defined(RF_DEBUG) || defined(ANNOUNCE_COLLISIONS))	
		TRACE("COLLISION: someone and %u (seq %d)", senderID, seq);
#endif
	    }
	    RF_EOT = tempEOT;		// Estimate end time
	    nextSeq = seq+1;
#ifdef RF_DEBUG 
	    TRACE("Predicting EOT at %lu, is now %lu", RF_EOT, now);
#endif
	    return;
	} 

	// If we're here, it's because the channel was already in
	// use.  Take a look at the sequence number and decide whether
	// this was the expected blip, one or more went missing, or
	// an entirely new sequence has begun arriving.

	if ((seq == nextSeq) && (senderID == source))
	{
	    delta = now - lastBlip;

	    RF_avgBT = ((WEIGHT-1)*RF_avgBT) + ((delta << 7)/size);
	    RF_avgBT = RF_avgBT / WEIGHT;
	    lastBlip = now;

	    // We're here because we got the expected blip from the
	    // expected source.  If it's the last blip in the
	    // sequence, package up a message and deliver it to the
	    // user on this Cybiko.  Otherwise, just update EOT.

	    if (seq == RF_SPLIT-1)		// Final blip
	    {
#ifdef RF_DEBUG	
		TRACE("Saw final blip at %lu vs %lu", now, RF_EOT);
#endif
		if (numSending != 1)
		{
//TRACE("Last blip from %u, %d colliders still going...",source,numSending-1);
		    numSending--;		// This one's done
		    return;
		}
		if (!RF_collision) {
		    newMsg = Message_new(sizeof(struct Message));   
		    if (!newMsg)
		    {
			TRACE("Out of memory -- Quitting");
			Error_Dialog("Out of memory.  Quitting.");
			exit(-1);
		    }

		    Buffer_ctor(&RF_buf, size, 32);
		    Buffer_load(bufPtr, RF_data, RF_HDR_SIZE, size);
		    Buffer_store(&RF_buf, RF_data, 0, size);

		    newMsg->cyid_from = senderID;
		    newMsg->msgid = msgId;

		    Message_attach_buffer(newMsg, &RF_buf);
		    Message_post(newMsg, RF_appName, get_own_id());

#ifdef RF_DEBUG	    
		    TRACE("Sequence took %d ms\n", now-startTime);
#endif
		}
		nextSeq = 0;		
		RF_inUse = FALSE;
		Busy_Off();
#ifdef RF_DEBUG
		if (RF_collision)
	    	  TRACE("COLLISION over, got final blip from last collider");
#endif
		RF_collision = FALSE;
		numSending = 0;
		RF_lastUse = now;
	    } 
	    else	// Got expected blip, but wasn't the final
	    {
		RF_EOT = tempEOT;
		nextSeq = seq+1;
#ifdef RF_DEBUG	
		TRACE("Blip %u/%d at %lu (EOT %lu)", 
		    senderID, seq, now, RF_EOT);
#endif
	    }
	}
	// Discovered a blip whose sequence will end LATER than the
	// sequence we'd been monitoring.  Note that this might 
	// happen if we get a blip from the sequence we'd been
	// following, but whose end time was longer than the last.
	// No matter where the blip came from, update the sequence
	// number and estimated EOT.  If it's from the same source
	// as we were watching, just return.  Otherwise deduce a
	// collision.
	else if ((tempEOT > RF_EOT)) 
	{			// Blip's sequence will end LATER
	    nextSeq = seq+1;
	    RF_EOT = EstimateEOT(seq, now, size);
	    if (source == senderID)
		return;
#if (defined(RF_DEBUG) || defined(ANNOUNCE_COLLISIONS))	
	    TRACE("COLLISION: %u and %u", source, senderID);	
#endif
	    RF_collision = TRUE;
	    source = senderID;
	    if (!Contains(colliding, senderID, numSending))
	    {
		colliding[numSending] = senderID;
		numSending++;		// Scared to do in one line...
//TRACE("Saw a new collider: %u (%d)", senderID, numSending);
	    }
	    if (nextSeq == RF_SPLIT)
		TRACE("First blip was last!");
//		Error_Dialog("First blip was last!");
	}
	else
	{   // Reasons we might get here:
	    // 1) There was a missing blip
	    // 2) The blip is from a now-ignored source/sequence

	    RF_collision = TRUE;
	    if (senderID == source)
	    {
#ifdef RF_DEBUG	
		TRACE("Missing blip -- still tuned to %u (got %d)",
			senderID, seq);
#endif
		nextSeq = seq+1;
		RF_EOT = tempEOT;
	    }
	    else	// Make sure this is from a known collider.
	    {		// If not, add host.  If it's a final blip,	
#ifdef RF_DEBUG		// then decrement the number of colliders
		TRACE("Ignoring colliding blip %u/%d", senderID, seq);
#endif
	    	if (!Contains(colliding, source, numSending))
	    	{
		    colliding[numSending] = source;
		    numSending++;	// Scared to do in one line...
//TRACE("Saw a new collider2: %u (%d)", source, numSending);
	    	}
		if (seq == RF_SPLIT-1)	// last blip from source
		{
		    numSending--;
//TRACE("Last from %u.  Now only %d colliders", source, numSending);
		}
	    }	
	}
}
