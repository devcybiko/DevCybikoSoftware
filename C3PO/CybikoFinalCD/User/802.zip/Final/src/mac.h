//=========================================================================
// Header file for MAC layer.
//
// Brad Richards, 10/2002
//=========================================================================
#ifndef _MAC_H_
#define _MAC_H_

#include "rf.h"
#define MSG_MAC_ARRIVAL	(MSG_RF_MAX + 1)
#define MSG_MAC_MAX	MSG_MAC_ARRIVAL

#define MAX_DATA_SIZE	64

typedef cyid_t MACaddr;		// Define a type for our MAC addresses
typedef short CNTL_t;		// Type for our control data
typedef long CRC_t;		// Type for the CRC field

// Init must be called before any of the other routines are used.

void MAC_Init(struct module_t *main, char *name);

// Service should be called periodically to ensure it catches
// timeouts in the RF layer.

void MAC_Service();

// You must pass events to the Handler so that RF has a chance
// to catch and process its internal messages

bool MAC_Handler(struct Message *ptr_message);

// Send takes a destination address, a pointer to the data to be
// sent, and the number of bytes to send.  It returns the number
// of bytes passed to the RF layer, which is *not* a guarantee
// that they arrived successfully at the destination.

int MAC_Send(MACaddr dest, char *data, int bufSize);

// Recv passes incoming data to the layer above.  It returns the 
// source and destination addresses through the first two parameters,
// and fills in the "data" buffer whose size is given via the final
// parameter.  The function returns the number of data bytes received.
// The layer above is notified about waiting data via a Cybiko message
// with msgid = MSG_MAC_ARRIVAL.

int MAC_Recv(MACaddr *source, MACaddr *dest, char *data, int bufSize);

#endif