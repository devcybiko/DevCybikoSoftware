//==========================================================================
// Implementation of the dialogs package.  See dialog.h for details.
//
// Brad Richards, Nate Waisbrot, 11/2002
//==========================================================================
#include "dialog.h"

#define	MESSAGE_CHECK_TIMEOUT	30
#define	MSG_MAX	200
static char _dlog_tmpStr[1024];
struct module_t *_dlog_main;
bool (*_dlog_Handler) (struct Message*);


//--------------------------------------------------------------------------
// This routine is called by each of the dialog boxes to retrieve messages
// that appear while the box is displayed.  If the dialog-processing code
// doesn't want the message, it's passed to the user dialog handler 
// specified in Init_Dialogs below.
//--------------------------------------------------------------------------
struct Message* Default_Message_Checker()
{
    struct Message* ret = NULL;
	ret = cWinApp_get_message(_dlog_main->m_process, 
		MESSAGE_CHECK_TIMEOUT, 1, MSG_MAX);
	return ret;
}


//--------------------------------------------------------------------------
// This routine is called by each of the dialog boxes to retrieve messages.
// If the dialog box doesn't intercept the message, it's passed to the
// user dialog handler specified in Init_Dialogs below.
//--------------------------------------------------------------------------
void Dialogs_Init(struct module_t *main, bool (*func))
{
	_dlog_main = main;
	_dlog_Handler = func;
	_dlog_Handler((struct Message *)NULL);
}


//--------------------------------------------------------------------------
// Destructor for dialog package.
//--------------------------------------------------------------------------
void Dialogs_Dest()
{
	// Currently, nothing to free
}


//--------------------------------------------------------------------------
// Used to present unexpected information to the user.  Produces an "error"
// beep and presents the message in a dialog box with a single button, "OK",
// which dismisses the box.
//--------------------------------------------------------------------------
void Error_Dialog(char *format, ...)
{
    struct cDialog dialog; 
    struct Message *cybikoMessage;
    va_list parameters;

    //  Formats string.
    va_start( parameters, format );
    if (vsprintf( _dlog_tmpStr, format, parameters) > 1022)
	TRACE(("Error_Dialog: Line too long."));
    va_end( parameters );

    cDialog_ctor( &dialog, "Error", _dlog_tmpStr,
		  mbOk, 0, _dlog_main->m_process);
    beep(BEEP_ERROR);

    cDialog_Show( &dialog );
    dialog.ModalResult = mrNone;
    while (dialog.ModalResult == mrNone)
    {
      cybikoMessage = Default_Message_Checker();
	if (!cybikoMessage)
	    continue;
	
	if (cybikoMessage->msgid == MSG_KEYDOWN)
	{
	    switch (Message_get_key_param(cybikoMessage)->scancode)
	    {
	    case KEY_ENTER:
		cDialog_proc(&dialog, cybikoMessage);
		break;
	    case KEY_ESC:
		dialog.ModalResult = mrQuit;
		break;
	    }
	}
	else if (!_dlog_Handler(cybikoMessage))
	{
	    cDialog_proc(&dialog, cybikoMessage);	    
	}
	Message_delete(cybikoMessage);
    }
    cDialog_Hide(&dialog);
    cDialog_dtor(&dialog, LEAVE_MEMORY );
}


//--------------------------------------------------------------------------
// Used to notify user of something important, but not unexpected.  Makes an
// "alert" beep, displays the text, waits for "OK" to be pressed.
//--------------------------------------------------------------------------
void Alert_Dialog(char *format, ...)
{
    struct cDialog dialog;
    struct Message *cybikoMessage;
    va_list parameters;

    //  Formats string.
    va_start( parameters, format );
    if (vsprintf( _dlog_tmpStr, format, parameters) > 1022)
	TRACE(("Alert_Dialog: Line too long."));
    va_end( parameters );

    cDialog_ctor( &dialog, "Attention!", _dlog_tmpStr ,
		  mbOk | mbs2, 0,_dlog_main->m_process);

    cDialog_Show( &dialog );
    dialog.ModalResult = mrNone;
    while (dialog.ModalResult == mrNone)
    {
      cybikoMessage = Default_Message_Checker();
      if (!cybikoMessage)
	    continue;
	
	if (cybikoMessage->msgid == MSG_KEYDOWN)
	{
	    switch (Message_get_key_param(cybikoMessage)->scancode)
	      {
	      case KEY_ENTER:
		cDialog_proc(&dialog, cybikoMessage);
		break;		
	      case KEY_ESC:
		dialog.ModalResult = mrQuit;
		break;
	      }
	}
	else if (!_dlog_Handler(cybikoMessage))
	  {
	    cDialog_proc(&dialog, cybikoMessage);
	  }
	Message_delete(cybikoMessage);
    }
    cDialog_Hide(&dialog);
    cDialog_dtor( &dialog,LEAVE_MEMORY );
}

//--------------------------------------------------------------------------
// These two are used to get input from the user.  The message is presented,
// and the user is expected to enter data into a field in the dialog box and
// then press "OK".  The integer or string is returned.
//--------------------------------------------------------------------------
long Get_Int_Dialog(char *format, ...)
{
    struct cDialog dialog;
    struct Message *cybikoMessage;
    char buffer[10];
    va_list parameters;

    //  Formats string.
    va_start( parameters, format );
    if (vsprintf( _dlog_tmpStr, format, parameters) > 1022)
	TRACE(("Int_Dialog: Line too long."));
    va_end( parameters );
    
    cDialog_ctor( &dialog, "Enter an integer", _dlog_tmpStr, mbEdit | mbOk, 
    	10, _dlog_main->m_process);

    cDialog_Show( &dialog );
    dialog.ModalResult = mrNone;
    while (dialog.ModalResult == mrNone)
    {
      cybikoMessage = Default_Message_Checker();
	if (!cybikoMessage)
	    continue;
	
	if (cybikoMessage->msgid == MSG_KEYDOWN)
	{
	    switch (Message_get_key_param(cybikoMessage)->scancode)
	    {
	    case KEY_ENTER:
		cDialog_proc(&dialog, cybikoMessage);
		dialog.ModalResult = KEY_ENTER;
		break;
	    case KEY_ESC:
		dialog.ModalResult = mrQuit;
		break;
	    default:
		cDialog_proc(&dialog, cybikoMessage);
		break;
	    }
	}
	else if (!_dlog_Handler(cybikoMessage))
	{
	    cDialog_proc(&dialog, cybikoMessage);
	}
	Message_delete(cybikoMessage);
    }
    cDialog_Hide(&dialog);

    cDialog_GetEditText (&dialog, buffer); 
    cDialog_dtor( &dialog, LEAVE_MEMORY );
    return (xtoi(buffer));
}

char*  Get_Str_Dialog(char *msg ,int size)
{
    struct Message *cybikoMessage;
    struct cDialog dialog;

    char *buffer;
    buffer=(char *)malloc(size);
    cDialog_ctor( &dialog, "", msg ,mbEdit | mbOk, size,_dlog_main->m_process);

    cDialog_Show( &dialog );
    dialog.ModalResult = mrNone;
    
    while (dialog.ModalResult == mrNone)
    {
      cybikoMessage = Default_Message_Checker();
	if (!cybikoMessage)
	    continue;
	
	if (cybikoMessage->msgid == MSG_KEYDOWN)
	{
	    switch (Message_get_key_param(cybikoMessage)->scancode)
	    {
	    case KEY_ENTER:
		cDialog_proc(&dialog, cybikoMessage);
		dialog.ModalResult = KEY_ENTER;
		break;
	    case KEY_ESC:
		dialog.ModalResult = mrQuit;
		break;
	    default:
		cDialog_proc(&dialog, cybikoMessage);
		break;
	    }
	}
	else if (!_dlog_Handler(cybikoMessage))
	{
	    cDialog_proc(&dialog, cybikoMessage);   
	}
	Message_delete(cybikoMessage);
    }
    cDialog_Hide(&dialog);

  cDialog_GetEditText (&dialog,  buffer); 
  cDialog_dtor( &dialog, LEAVE_MEMORY );
  return buffer;
}