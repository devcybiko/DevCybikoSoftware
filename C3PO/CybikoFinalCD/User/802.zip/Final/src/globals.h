//=========================================================================
// Global Variables
//
// Brad Richards, 10/2002
//=========================================================================

#ifndef _GLOBALS_H_
#define _GLOBALS_H_

//#include "utilities.h"
#include "mac.h"

#define BCAST_ID	0xFFFFFFFF
#define DEBUG	
#define NUM_BUF		4
#define MAX_HOSTS	10
#define MAX_RETRANS	10
#define HDRSIZE 	(sizeof(MACaddr)+sizeof(CNTL_t)+sizeof(CRC_t))
//#define SNOOP

// Global types

typedef enum {
	NEW, 		// Brand new.  Haven't checked channel yet
	FIRST_WAIT,	// Channel was clear -- waiting DIFS to be safe
	RETRY_PENDING,	// Collision, or channel busy during first wait
	RETRY_DIFS,	// Waiting for DIFS, will then count down slots
	RETRY_CW,	// Survived DIFS, now counting down slots
	AWAITING_ACK 	// Data sent, waiting for the ACK
} FrameState;

typedef enum {DATA=0, ACK=1, CTS=2, RTS=3, BEACON=4} FrameType;


typedef struct
{
	MACaddr	dest;
	short control;
	long crc;	
	char data[MAX_DATA_SIZE];
	
	// The following fields aren't transmitted as part of the MAC
	// frame, but they help the MAC layer keep track of this frame
	// while it's sitting in a send or receive buffer.

	int dataSize;		// Number of data bytes in this frame
	
	// Fields used for outgoing data
	
	FrameState state;	// Frame's transmission state
	int numTries;		// How many times has it been sent?
	clock_t	ackDue;		// Expected arrival time of ACK
	int window;		// Size of exponential window
	int slotsLeft;		// Remaining slot times to wait
	clock_t waitEnds;	// Use depends on state
	
	// Used for incoming data
	
	MACaddr	src;		// Used when buffering incoming data
} MAC_data_t;


// Global variables

EXTERN char *process;		// Pointer to argv[0]
EXTERN clock_t MAC_lastUse;	// Last time the channel was in use
EXTERN MAC_data_t tmpBeacon;	// Keep around for beacon-sending purposes
EXTERN MAC_data_t inFrame;	// Temporary frame used to hold incoming
EXTERN bool beeping;		// Used to test clock synch
EXTERN bool sendingBeacon;	// Has a beacon frame taken precedence?
EXTERN bool jamming;		// Are we jamming transmissions?
EXTERN bool maxCW;		// Using max CW, or random?
EXTERN bool SNOOP;		// Are we participating, or just snooping?

EXTERN MACaddr assoc[MAX_HOSTS];
EXTERN int outSeq[MAX_HOSTS];
EXTERN int inSeq[MAX_HOSTS];

EXTERN clock_t clockOffset;
EXTERN clock_t nextBeaconTime;

// TX of 2200 and RX of 300 worked beautifully until I quit doing as
// much tracing.  Now it seems that the total amount is too large so
// I'm cutting back.

#define BEACON_INTERVAL	60000
#define LocalTime	(clock() + clockOffset)
#define TX_DELAY 1950	/* 1950 was working well for a bit... */
#define RX_DELAY 250

#define SIFS	300
#define SLOT	500
#define DIFS	(SIFS+SLOT+SLOT)
// The original formula was based on the time required to send a 
// beacon.  An ACK should be at least as fast...  In practice, the
// following ACK_DELAY is marginal -- it takes just about exactly
// this long for the ACK to get back, and that's throwing in an
// extra 600 ms!  Maybe I should bump it up to 4 slots of slop...
#define ACK_DELAY	(RX_DELAY+SIFS+TX_DELAY+RX_DELAY+2*SLOT)
//#define ACK_DELAY	(RX_DELAY+SIFS+TX_DELAY+RX_DELAY+4*SLOT)


#define CWmin	2
#define CWmax	64


// There are two fixed-length buffers for frames.  One holds incoming
// frames, in the order of arrival.  If the buffer is full, additional
// incoming frames are discarded.  The buffer for outgoing frames must
// hold them until an ACK has been received.

EXTERN MAC_data_t inFrames[NUM_BUF];
EXTERN MAC_data_t outFrames[NUM_BUF];
EXTERN int inFirst;
EXTERN int outFirst;
EXTERN int inNumBufd;
EXTERN int outNumBufd;

#define MOD(big,small)	(big - (big / small)*small)

#endif