//=========================================================================
// Broadcast package
//
// Brad Richards, 10/2002
//=========================================================================

#define EXTERN	extern
#include "globals.h"
#include "utilities.h"
#include "console.h"
#include "dialog.h"



// Global variables


//=========================================================================
// Initialize our internal variables, and record the module and app name.
//=========================================================================
	
void MAC_Init(struct module_t *main, char *name)
{
	RF_Init(main, name);
	process = name;
	beeping = FALSE;
	sendingBeacon = FALSE;
	jamming = FALSE;
	maxCW = FALSE;
	SNOOP = FALSE;
	InitStructures();
	InitClock();

	// This line is unnecessary if we send a beacon initially

	nextBeaconTime = LocalTime + BEACON_INTERVAL;
}


//=========================================================================
// Take care of routine chores.  This includes refreshing the RF layer.
//=========================================================================

void MAC_Service()
{  
    clock_t offset;
    static bool jammed = FALSE;

	RF_Service();	// Make sure the RF layer gets some time

	// Jamming test mechanism.  If jamming is turned on, the
	// channel is in use, and we haven't jammed it yet, then
	// do an immediate send.  We won't jam again until the 
	// channel is idle and "jammed" is reset.
 
	if (jamming && RF_InUse() && (!jammed))
	{
	    WriteStatus("Jamming");
	    Immediate_Send("Jamming Message", 16);
	    WriteStatus("Idle");
	    jammed = TRUE;
	}
	if (jammed && !RF_InUse())
	    jammed = FALSE;
	    
	
	// See if we should beep to indicate synchronization

	offset = LocalTime % 2000;
	if (beeping)
	    if ((offset < 100) && (offset > -100))
	    {
	    	beep(BEEP_OK);
	    	TRACE("beep offset was %d", offset);
	    }
	    
	// See if it's time to send a beacon frame
	    
	if ((LocalTime > nextBeaconTime) && !SNOOP)
	{
	    sendingBeacon = TRUE;
	}

	// See what needs to be done with frames in outgoing queue

	ProcessOutgoing();
}


//=========================================================================
// Return the contents of a frame to the layer above, if one is ready.
//=========================================================================

int MAC_Recv(MACaddr *source, MACaddr *dest, char *data, int bufSize)
{
    int numBytes = 0;
    MAC_data_t *frame;
    
    	if (inNumBufd == 0)
    	    return 0;

	// There was at least one frame waiting.  First, update
	// the buffer of incoming frames.
    	    
	frame = &(inFrames[inFirst]);
	inFirst = (inFirst+1) % NUM_BUF;
	inNumBufd--;

	// Now copy out the info to return to user

	*source = frame->src;		// Get data out to caller
	*dest = frame->dest;	
	numBytes = (bufSize < frame->dataSize) ? bufSize : frame->dataSize;
	memcpy(data, frame->data, numBytes);

	TraceFrame(frame, "MAC_Recv pulled buffer: ");
	
	return numBytes;
}


//=========================================================================
// This routine takes data from the layer above and sends it to the 
// specified destination.  The data is placed into a properly-formatted
// MAC frame, and the CSMA/CA rules are followed in its delivery.
//=========================================================================

int MAC_Send(MACaddr dest, char *data, int bufSize)
{
    int i, size, hostIdx;
    MAC_data_t *entry;
    CNTL_t tmpCntl;
    
    	if ((entry = GetOutEntry()) == (MAC_data_t *)NULL)
    	    return 0;
    
    	if (bufSize > MAX_DATA_SIZE)	// Take as much as we can
    	    bufSize = MAX_DATA_SIZE;
    
    	size = bufSize + HDRSIZE;	// Size of entire frame

    	// Fill in the frame fields.  Start by figuring out which
    	// outgoing sequence number is appropriate.
    	
    	hostIdx = IdxOf(dest);   	// Look up destination    	 	    	
    	SetSeqNum(&tmpCntl, outSeq[hostIdx]++);
    	SetFrameType(&tmpCntl, DATA);
    	SetRetrans(&tmpCntl, FALSE);
    	entry->control = tmpCntl;	// Copy in control field
    	entry->dest = dest;    		// Set destination address
    	entry->crc = 0;			// CRC is zero for now
    	
     	// Copy data into frame
    	  
   	memcpy(&(entry->data), data, bufSize);    	
   	
   	// Fill in fields that won't be transmitted, but that are necessary
   	// for bookkeeping purposes
   	
   	entry->dataSize = bufSize;
   	entry->state = NEW;		// Signals that it needs sending
   	entry->numTries = 0;
	entry->slotsLeft = 0;
   	entry->window = CWmin;
    	
    	// We've now created a properly-formatted MAC frame, which is
    	// sitting in the output buffer structure.  Instead of trying
    	// to send it now, we'll let the MAC_Service mechanism deal
    	// with it the next time it runs.

	TRACE("Left outgoing data in buffer.");
    	
	return bufSize;
}



//=========================================================================
// Unfortunately, we need to have the user pass events to our handler so
// we can watch for incoming data.  cWinApp_get_message doesn't work as
// advertised, and won't restrict itself to msgids within the range
// specified by the last two parameters.  Thus, the user's code would
// inadvertently grab our messages and discard them.
//
// The only message we anticipate is MSG_RF_ARRIVAL, which signals that
// data has arrived from the RF layer.  The attached buffer contains the
// data.
//=========================================================================

bool MAC_Handler(struct Message *ptr_message)
{
    int size, dataOffset;
    struct Buffer *bufPtr;
    struct Message *newMsg;
    MAC_data_t *entry;
    MACaddr dest;
    CNTL_t cntl;
    char name[10];
    char destName[10];

    
	if (RF_Handler(ptr_message))	// See if RF needs this message
	    return TRUE; 

	if (ptr_message->msgid == MSG_KEYDOWN)
	{
	    switch (Message_get_key_param(ptr_message)->scancode) 
	    {
/*
	    case KEY_SPACE:
    		TRACE("Sending super beacon");
    		clockOffset = clockOffset + 10000;
    		sendingBeacon = TRUE;   
    		return TRUE;
*/

	    case KEY_DEL:
    		TRACE("Sending Beacon");
    		sendingBeacon = TRUE;
    		return TRUE;

	    case KEY_INS:
    		beeping = !beeping;
    		return TRUE;
    		
    	    case KEY_SELECT:
    	    	maxCW = !maxCW;
    	    	if (maxCW)
    	    	    WriteText("Will use max CW, not random.\n");
    	    	else
    	    	    WriteText("Will use random CW, not max.\n");
    	    	return TRUE;

	    case KEY_BACKSPACE:		// Toggle jamming
		jamming = !jamming;
    	    	if (jamming)
    	    	    WriteText("Automatic Jamming ON.\n");
    	    	else
    	    	    WriteText("Automatic Jamming OFF.\n");
		return TRUE;

	    case KEY_ENTER:		// Send without CSMA/CA
		WriteStatus("Manual Jam");
		Immediate_Send(
		  "This is a very very long jamming message of length 54",
		  54);
		WriteStatus("Idle");
		return TRUE;

    	    case KEY_SPACE:
    	    	SNOOP = !SNOOP;
    	    	if (SNOOP) {
		    WriteStatus("Snooping");
    	    	    WriteText("Snooping only.\n");
		}
    	    	else
		{
		    WriteStatus("Idle");
    	    	    WriteText("Participating again.\n");
		}
    	    	return TRUE;
		
	    default:
		return FALSE;	// Not interested in other keys
	    }
	}
 					// Only interested in MSG_RF_ARRIVAL
	if (ptr_message->msgid != MSG_RF_ARRIVAL) 
	    return FALSE;
	    
	// First, copy the data into a frame structure to make it easier
	// to inspect.  Then see if it's for us or not.  If it's not, we 
	// still need to return TRUE, as we dealt with the message and know
	// that it's appropriate to let the main loop delete it.
	
	if (!Message_has_buffer(ptr_message))
	{
	    Error_Dialog("No buffer on arriving RF data!");
	    return TRUE;
        }	
	bufPtr = Message_get_buffer(ptr_message);        
        Buffer_load(bufPtr, &inFrame, 0, Buffer_get_size(bufPtr));

if (!SNOOP) {
        if ((inFrame.dest != get_own_id()) &&
	    (inFrame.dest != BCAST_ID))
	{
	    TRACE("Frame arrived, but not for us.");
	    return TRUE;	    
	}
}
	    
	// Now we know it's something we need to process.  See what sort
	// of frame it is and pass control off to the appropriate 
	// routine.
	
	inFrame.src = Message_get_sender_id(ptr_message);	
	inFrame.dataSize = Buffer_get_size(bufPtr) - HDRSIZE;

	HostName(inFrame.src, name);
	TRACE("Frame from %s arrived: ", name);
	TraceFrame(&inFrame, "");
if (SNOOP) {
	HostName(inFrame.dest, destName);
	WriteText("From %s-->%s: ", name, destName);
} else {
	WriteText("From %s: ", name);
}
	PrintFrame(&inFrame);
	WriteText("\n");

if (SNOOP) {
	return TRUE;
}

	switch (GetFrameType(inFrame.control))
	{
	    case ACK:
	  	ProcessACK(&inFrame);
	  	break;	  	

	    case DATA:
	    	ProcessDATA(&inFrame);
	    	break;

	    case BEACON:
		ProcessBEACON(&inFrame);
		break;

	    default:
		TRACE("Unknown frame type (%d)", 
			GetFrameType(inFrame.control));
	}	
	return TRUE;
}
