#define EXTERN
#include "globals.h"
#include "utilities.h"
#include "console.h"
#include "dialog.h"


// My own name is finder.mf.f_nick;

// Takes a MACaddr and a string.  Copies the destination name into the
// string.

bool HostName(MACaddr id, char *name)
{
    int i;
    
	Mutex_lock(&finder.finder_mutex, 0);		// lock the finder
	for (i = 0; i < finder.howmany_around; i++)	// loop through neighbors
	    if (finder.cf[i].cf_id == id)
	    {
		strcpy(name, finder.cf[i].cf_fk.f_nick);
		Mutex_unlock(&finder.finder_mutex);	// unlock the finder
		return TRUE;
	    }
	Mutex_unlock(&finder.finder_mutex);		// unlock the finder
	
	if (id == BCAST_ID)
	    strcpy(name, "All");
	else if (id == get_own_id())
	    strcpy(name, "me");
	else
	    strcpy(name, "ERR");
	return FALSE;
}




void PrintFrame(MAC_data_t *frame)
{
    clock_t *timePtr;

	if (frame == (MAC_data_t *)NULL)
	    return;

	switch (GetFrameType(frame->control))
	{
	case DATA:
	    WriteText("<Data %d [%d]>",
		GetSeqNum(frame->control),
		frame->dataSize);
	    break;

	case ACK:
	    WriteText("<Ack %d>", GetSeqNum(frame->control));
	    break;

	case BEACON:
	    timePtr = &(frame->data[0]);
	    WriteText("<Beacon %u>", *timePtr);
	    break;

	default:
	    TRACE("Unknown frame type (%d)", GetFrameType(frame->control));
	}
}


void TraceFrame(MAC_data_t *frame, char *str)
{
    clock_t *timePtr;

	if (frame == (MAC_data_t *)NULL)
	    return;

	switch (GetFrameType(frame->control))
	{
	case DATA:
	    TRACE("%s <Data %u %d [%d]>",
		str,
		frame->dest, 
		GetSeqNum(frame->control),
		frame->dataSize);
	    break;

	case ACK:
	    TRACE("%s <Ack %u %d>", str, frame->dest, 
		GetSeqNum(frame->control));
	    break;

	case BEACON:
	    timePtr = &(frame->data[0]);
	    TRACE("%s <Beacon %u>", str, *timePtr);
	    break;	    

	default:
	    TRACE("Unknown frame type (%d)", GetFrameType(frame->control));
	}
}


void InitStructures()
{
    int i;
    
    	for(i=0; i<MAX_HOSTS; i++)
    	{
    	    assoc[i] = 0;
    	    outSeq[i] = 0;
    	    inSeq[i] = 0;
    	}
    	
    	inFirst = 0; 
    	inNumBufd = 0;
    	outFirst = 0;
    	outNumBufd = 0;    
    	
    	// Set up our recyclable beacon frame
    	 	 	    	
    	SetSeqNum(&(tmpBeacon.control), 0);
    	SetFrameType(&(tmpBeacon.control), BEACON);
    	SetRetrans(&(tmpBeacon.control), FALSE);
    	tmpBeacon.dest = BCAST_ID;    	
    	tmpBeacon.crc = 0;			 	
   	
   	// Fill in fields that won't be transmitted, but that are necessary
   	// for bookkeeping purposes
   	
   	tmpBeacon.dataSize = sizeof(clock_t);
   	tmpBeacon.state = NEW;		// Signals that it needs sending
   	tmpBeacon.numTries = 0;
	tmpBeacon.slotsLeft = 0;
   	tmpBeacon.window = CWmin;
}


//=========================================================================
// Returns a pointer to the next open location in the array of output 
// frame buffers.  If none are available, it returns NULL.
//=========================================================================

MAC_data_t *GetOutEntry()
{
    int idx;
    
	if (outNumBufd == NUM_BUF)
	    return NULL;
	    
	idx = (outNumBufd + outFirst) % NUM_BUF;
	outNumBufd++;		// I don't trust compiler with increments

	return &(outFrames[idx]);
}


MAC_data_t *GetInEntry()
{
    int idx;
    
	if (inNumBufd == NUM_BUF)
	    return NULL;
	    
	idx = (inNumBufd + inFirst) % NUM_BUF;
	inNumBufd++;		// I don't trust compiler with increments
	
	return &(inFrames[idx]);
}


void RemoveFirstEntry()
{
	outFirst = (outFirst+1) % NUM_BUF;
	outNumBufd--;
}


//=========================================================================
// Maps a MAC address to a local zero-based index.  If the address was
// previously unknown, enter it into the table and return the new index.
//=========================================================================

int IdxOf(MACaddr id)
{
    static int numEntries = 0;
    int i;

	for(i=0; i<numEntries; i++)
	    if (assoc[i] == id)
	        return i;
	        
	assoc[numEntries] = id;
	numEntries++;
//	TRACE("Mapped %u to %d", id, numEntries - 1);
	return numEntries - 1;
}

// Takes the control bytes and returns the sequence # portion.
// (The lower 12 bits.)

short GetSeqNum(short control)
{
    return (control & 0x0FFF);
}

bool GetRetrans(CNTL_t control)
{
    return (control & 0x1000);
}

FrameType GetFrameType(CNTL_t control)
{
    return (FrameType)((control & 0xE000) >> 13);
}

void SetSeqNum(CNTL_t *control, short seq)
{
    seq = seq & 0x0FFF;			// Only use 12 bits
    *control = (*control) & 0xF000;	// Clear out lowest 12 bits
    *control = (*control) | seq;	// Paste in seq
}

void SetRetrans(CNTL_t *control, bool flag)
{
    if (flag)
    	*control = (*control) | 0x1000;
    else
    	*control = (*control) & 0xEFFF;
}

void SetFrameType(CNTL_t *control, FrameType ft)
{
    *control = (*control) & 0x1FFF;	// Clear out highest 3 bits
    *control = (*control) | (ft << 13);	// Shift up ft bits, paste in
}

void ShowBits(CNTL_t control)
{
    int i;
    int mask = 0x8000;

	for(i=0; i<16; i++)
	{
	    if (mask & control)
	        WriteText("1");
	    else
		WriteText("0");
	    mask = mask >> 1;
	}
	WriteText("\n");
}



//=========================================================================
// Go through the array of buffered outgoing frames and process them as
// necessary.  This routine also handles beacon frames, as they may take
// precedence over the data frames in the queue.
//=========================================================================

void ProcessOutgoing()
{
    int i;
    MAC_data_t *frame;
    static bool doingBeacon = FALSE;
    
    	// There's something to do if outNumBufd is greater than zero,
    	// or there's a beacon to be sent.  Need to decide if we should
    	// process a beacon, normal frame, or nothing.
    	
    	if (doingBeacon)		// In the middle of beacon send
    	{
    	    frame = &tmpBeacon;
    	    *((clock_t *)&(frame->data)) = LocalTime + TX_DELAY;
    	}
    	else if (sendingBeacon && 
    		((outNumBufd < 1) || (outFrames[outFirst].state == NEW)))
    	{
    	    doingBeacon = TRUE;		// Start doing a beacon send
    	    frame = &tmpBeacon;
	    frame->window = CWmin;  
	    frame->state = NEW;
    	    sendingBeacon = FALSE;
    	    nextBeaconTime = LocalTime + BEACON_INTERVAL;
    	}
    	else if (outNumBufd > 0)	// Not doing beacon
	    frame = &(outFrames[outFirst]);
    	else
    	    frame = NULL;
    	    
    	    
    	// We've now figured out what we need to do, and frame is either
    	// pointing to our beacon, the first outgoing data frame, or is
    	// NULL.  If it's not NULL, then proceed.
       
	if (frame != NULL)
	{  	    
    	    switch (frame->state)
    	    {
    	    
    	    // Frame has never been considered.  If the channel is in use
    	    // at this point, we treat it like a collision even though we
    	    // haven't actually sent the frame.  If the channel is idle,
    	    // we mark it as waiting for DIFS (unless it's time to send a
    	    // beacon, in which case it gets priority).
    	    
    	    case NEW:
    	    	if (RF_InUse())	// channel was busy -- treat like collision
    	    	{
    	    	    frame->state = RETRY_PENDING;
    	    	    if (maxCW)
    	    	    	frame->slotsLeft = frame->window - 1;
    	    	    else
    	    	    	frame->slotsLeft = random(frame->window);
    	    	    WriteStatus("RETRY_PENDING %d/%d", 
			frame->slotsLeft, frame->window);
    	    	}
    	    	else		// Channel was free -- wait for DIFS
    	    	{
		    frame->state = FIRST_WAIT;
		    frame->waitEnds = LocalTime + DIFS;
		    WriteStatus("FIRST_WAIT");
    	    	}
    	    	break;
    	    	
    	    // Still waiting for our initial DIFS before sending for the
    	    // first time.  If the channel becomes busy, we treat it like
    	    // a collision.  If DIFS elapses without contention, send the
    	    // frame.
    	    	
    	    case FIRST_WAIT:
    	    	if (RF_InUse())
    	    	{
    	    	    frame->state = RETRY_PENDING;
    	    	    if (maxCW)
    	    	    	frame->slotsLeft = frame->window - 1;
    	    	    else
    	    	    	frame->slotsLeft = random(frame->window);
    	    	    WriteStatus("RETRY_PENDING %d/%d", 
			frame->slotsLeft, frame->window);
    	    	}
    	    	else if (LocalTime > frame->waitEnds)
    	    	{
		    TraceFrame(frame, "Transmitting: ");
		    WriteStatus("Transmitting");
		    if (doingBeacon)
		    {
			*((clock_t *)&(frame->data)) = LocalTime + TX_DELAY;
			RF_Tx(frame, HDRSIZE + frame->dataSize);
			doingBeacon = FALSE;
			WriteStatus("Idle");
		    }
		    else
		    {
			RF_Tx(frame, HDRSIZE + frame->dataSize);
			if (frame->dest != BCAST_ID)
			{
			    frame->state = AWAITING_ACK;
			    frame->ackDue = LocalTime + ACK_DELAY;
			    WriteStatus("AWAITING_ACK");
			}
			else
			{
			    WriteStatus("Idle");
			    RemoveFirstEntry();
			}
		    }
    	    	}
    	    	break;
    	    	
    	    // A frame has this state once a contention window has been set.
    	    // This could be because there was traffic before or during 
    	    // our first DIFS wait, or because there was an actual collision.
    	    // We stay in this state until the channel becomes idle.
    	    	    	    	
    	    case RETRY_PENDING:
    	    	if (!RF_InUse())
    	    	{
		    frame->state = RETRY_DIFS;
//		    frame->waitEnds = LocalTime + DIFS;
		    frame->waitEnds = DIFS +
			(LocalTime + SLOT - MOD(LocalTime, SLOT));
TRACE("Waiting until %lu (vs %lu)", frame->waitEnds, LocalTime+DIFS);
    	    	    WriteStatus("RETRY_DIFS %d/%d", 
			frame->slotsLeft, frame->window);
		}
		break;    
		
	    // In this state we wait for DIFS to elapse, then move to state
	    // RETRY_CW.  If the channel becomes busy before DIFS has elapsed, 
	    // we need to start over again in state RETRY_PENDING, but leave 
	    // the contention window unchanged.
		
    	    case RETRY_DIFS:
    	    	if (RF_InUse())
    	    	{
    	    	    frame->state = RETRY_PENDING;
    	    	    WriteStatus("RETRY_PENDING");
    	    	}
    	    	else if (LocalTime > frame->waitEnds)
    	    	{
    		    frame->state = RETRY_CW;
    		    frame->waitEnds = frame->waitEnds + frame->slotsLeft*SLOT;
    		    WriteStatus("RETRY_CW %d/%d", 
			frame->slotsLeft, frame->window);
    	    	}
    	    	break;
    	    	
    	    // We've survived the DIFS wait, and are now counting down our
    	    // slot times.  If the channel becomes busy, record how many
    	    // slots are left and go back to RETRY_PENDING.  If we reach
    	    // the end of our delay, transmit the frame.
    	    
    	    case RETRY_CW:
    	    	if (RF_InUse())
    	    	{
    	    	    frame->state = RETRY_PENDING;
		    frame->slotsLeft = (frame->waitEnds-LocalTime) / SLOT;
    	    	    WriteStatus("RETRY_PENDING %d/%d", 
			frame->slotsLeft, frame->window);
    	    	}
    	    	else if (LocalTime > frame->waitEnds)
    	    	{
		    TraceFrame(frame, "Transmitting: ");
		    WriteStatus("Transmitting");
		    if (doingBeacon)
		    {
			*((clock_t *)&(frame->data)) = LocalTime + TX_DELAY;
			RF_Tx(frame, HDRSIZE + frame->dataSize);
			doingBeacon = FALSE;
			WriteStatus("Idle");
		    }
		    else
		    {
			RF_Tx(frame, HDRSIZE + frame->dataSize);
			if (frame->dest != BCAST_ID)
			{
			    frame->state = AWAITING_ACK;
			    frame->ackDue = LocalTime + ACK_DELAY;
			    WriteStatus("AWAITING_ACK");
			}
			else
			{
			    WriteStatus("Idle");
			    RemoveFirstEntry();
			}
		    }
    	    	}
		break;   
		
	    case AWAITING_ACK:
	    	if (LocalTime > frame->ackDue)
	    	{
		    TraceFrame(frame, "ACK overdue: ");
		    beep(BEEP_ERROR);
		    WriteText("Lost: ");
		    PrintFrame(frame);
		    WriteText("\n");
		    
		    frame->numTries++;
		    if (frame->numTries > MAX_RETRANS)
		    {
		    	WriteText("Giving up on ");
		    	PrintFrame(frame);
		    	WriteText("\n");
		    	RemoveFirstEntry();
		    }
		    else
		    {
			SetRetrans(&(frame->control), TRUE);	    	    
			frame->window = frame->window * 2;
			if (frame->window > CWmax)
			    frame->window = CWmax;
			if (maxCW)
			    frame->slotsLeft = frame->window - 1;
			else
			    frame->slotsLeft = random(frame->window);	    	 

			frame->state = RETRY_PENDING;
			WriteStatus("RETRY_PENDING %d/%d", 
			    frame->slotsLeft, frame->window);
		    }

	    	}
		break;
		    	
    	    default:
    	    	TRACE("Unexpected outgoing frame state: %d", 
    	    	    frame->state);
    	    }
    	}
}


//=========================================================================
// For this checkpoint, there's nothing to do.  Just ignore the ACK.
//=========================================================================

void ProcessACK(MAC_data_t *frame)
{
    MAC_data_t *front;
    
	// See if there's even a data frame awaiting an ACK

	if (outNumBufd < 1)
	{
	    TraceFrame(frame, "No corresponding frame: ");
	    TRACE("ACK arrived, but no frame in out queue");
	    return;
	}
	
	// Need to make sure it matches the first in the queue
	
	front = &(outFrames[outFirst]);
	if ((frame->src == front->dest) && 
	    (GetSeqNum(frame->control) == GetSeqNum(front->control)))
	{
	    TraceFrame(frame, "Got proper ack: ");
	    RemoveFirstEntry();
	}
	else
	{
	    TRACE("ACK wasn't for first frame in queue!");
	    TRACE("ACK was from %u", frame->src);
	    TRACE("DATA was to %u", front->dest);
	    TRACE("Seq's were %d vs %d", GetSeqNum(frame->control),
		GetSeqNum(front->control));
	}
	WriteStatus("Idle");
}


//=========================================================================
// Process incoming data frames. 
//=========================================================================

void ProcessDATA(MAC_data_t *frame)
{
    MAC_data_t *entry;
    struct Message *newMsg;
    int seq, idx;
    MACaddr src;

	// Regardless of sequence number, needs to be ACK'd (unless
	// it was broadcast data).
	
	if (frame->dest == BCAST_ID)
	{
	    TRACE("Got Bcast data -- no ACK sent");
	}
	else
	{
	    TRACE("Sending an ACK");
	    Acknowledge(frame);				// Send an ACK
	}

	// See if it's the expected sequence number

	seq = GetSeqNum(frame->control);
	idx = IdxOf(frame->src);

	if (seq < inSeq[idx])
	{
	    TRACE("Duplicate data frame ignored");
	    return;
	}

	if (seq > inSeq[idx])
	{
	    TRACE("Expected %d, got %d", inSeq[idx], seq);
	}

	// Find a spot in the input buffer	
	if ((entry = GetInEntry()) == (MAC_data_t *)NULL)
	{
	    TRACE("Discarded %d", GetSeqNum(frame->control));
	    return;	
	}    	

	inSeq[idx] = seq+1;
	TRACE("Buffering incoming data.");
	memcpy(entry, frame, sizeof(MAC_data_t));	// Copy it in
	newMsg = Message_new(sizeof(struct Message));   
	if (!newMsg)
	{
	    TRACE("Out of memory -- Quitting");
	    exit(-1);
	}
	
	// Notify user of newly-arrived data
	
	newMsg->cyid_from = entry->src;
	newMsg->msgid = MSG_MAC_ARRIVAL;
	Message_post(newMsg, process, get_own_id());
}

int Acknowledge(MAC_data_t *frame)
{
    char *tmp;
    int i, size;
    CNTL_t tmpCntl;
    MAC_data_t ack;
    
    	size = HDRSIZE;
    	
    	ack.dest = frame->src;
    	
    	// Fill in the control info
    	
    	SetFrameType(&tmpCntl, ACK);
    	SetRetrans(&tmpCntl, FALSE);
    	SetSeqNum(&tmpCntl, GetSeqNum(frame->control));
    	ack.control = tmpCntl;
    	
    	// Fill in CRC
    	
    	ack.crc = 0;
    	   	
    	// Now pass it off to the physical layer
    	
sleep(SIFS);
    	
	TraceFrame(&ack, "Transmitting: ");
    	RF_Tx(&ack, size);
    	
	return size;
}


//==
// Clock Code
//==

/*
clock_t LocalTime()
{
	return (clock() + clockOffset);
}
*/

void InitClock()
{
    clock_t tmp;
    struct Time fullTime;
    
// This may not work, as the returned fields are "char", not int

    	Time_decode(&fullTime, get_trusted_time());

	TRACE("seconds: %d, hundreds: %d", fullTime.second,
		fullTime.hundreds);
    	
    	tmp = 10*fullTime.hundreds + 1000*fullTime.second;
	srand(tmp);

//	tmp = 100 * get_trusted_time();
	TRACE("Local time is %u", tmp);
	TRACE("Clock is %u", clock());
	clockOffset = tmp - clock();
	TRACE("Clock offset is %u", clockOffset);
	TRACE("LocalTime is therefore %u", LocalTime);
}

void TransmitBeacon()
{
    MAC_data_t frame;
    CNTL_t tmpCntl;
clock_t start;

    	SetSeqNum(&tmpCntl, 0);
    	SetFrameType(&tmpCntl, BEACON);
    	SetRetrans(&tmpCntl, FALSE);
    	frame.control = tmpCntl;	// Copy in control field
    	frame.dest = BCAST_ID;    	// Set destination address
    	frame.crc = 0;			// CRC is zero for now
   	
   	// Fill in fields that won't be transmitted, but that are necessary
   	// for bookkeeping purposes
   	
   	frame.dataSize = sizeof(clock_t);
   	frame.state = NEW;	// Signals that it needs sending
   	frame.numTries = 0;
   	frame.window = CWmin;

	TraceFrame(&frame, "Transmitting: ");
    	
     	// Copy data into frame
    	  
	*((clock_t *)&(frame.data)) = LocalTime + TX_DELAY;	
start = clock();
	RF_Tx(&frame, HDRSIZE + frame.dataSize);
TRACE("Beacon took %d to send", clock()-start);
	sendingBeacon = FALSE;
	nextBeaconTime = LocalTime + BEACON_INTERVAL;
}



void ProcessBEACON(MAC_data_t *frame)
{
    MAC_data_t *entry;
    struct Message *newMsg;
    char name[9];
static int count = 0;
static int deltas = 0;

    clock_t local, tmp, *tPtr;

	tPtr = (clock_t *)&(frame->data);
	tmp = *tPtr + RX_DELAY;
	local = LocalTime;
	
	TRACE("Arrived %d ms ago", clock() - last_rf_clock());
	TRACE("new = %lu, old = %lu, delta = %d",
		tmp, local, local-tmp);

if (local > tmp)
{
    count = count+1;
    deltas = deltas+local-tmp;
    TRACE("Delta average: %d / %d (%d)", deltas, count, deltas/count);
}

	if (tmp > local)
	{
	    clockOffset = clockOffset+(tmp-local);
	    HostName(frame->src, name);
	    TRACE("Accepting timestamp from %s", name);
	    WriteText("Adjusted by %d due to beacon\n", tmp-local);
	}
	else
	    TRACE("Kept current timestamp");
}



void Immediate_Send(char *data, int bufSize)
{
    int i, size, hostIdx;
    MAC_data_t *entry;
    CNTL_t tmpCntl;
    
    	if (bufSize > MAX_DATA_SIZE)	// Take as much as we can
    	    bufSize = MAX_DATA_SIZE;
    
    	size = bufSize + HDRSIZE;	// Size of entire frame

    	// Fill in the frame fields.  Start by figuring out which
    	// outgoing sequence number is appropriate.
    	
    	hostIdx = IdxOf(0xFFFFFFFF);   	// Look up destination    	 	    	
    	SetSeqNum(&tmpCntl, outSeq[hostIdx]++);
    	SetFrameType(&tmpCntl, DATA);
    	SetRetrans(&tmpCntl, FALSE);
    	entry->control = tmpCntl;	// Copy in control field
    	entry->dest = 0xFFFFFFFF;    	// Set destination address
    	entry->crc = 0;			// CRC is zero for now
    	
    	// We've now created a properly-formatted MAC frame, which is
    	// sitting in the output buffer structure.  Instead of trying
    	// to send it now, we'll let the MAC_Service mechanism deal
    	// with it the next time it runs.

	RF_Tx(entry, size);

	TRACE("Finished immediate send.");
}
