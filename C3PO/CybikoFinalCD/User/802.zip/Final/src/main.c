//=========================================================================
// Exercises the MAC layer.
//
// Brad Richards, 10/2002
//=========================================================================

#include "cywin.h"		// For all of the yummy Cybiko stuff
#include "dialog.h"		// For dialogs and WriteText
#include "console.h"
#include "mac.h"		// For MAC-layer services


#define MSG_MAX		MSG_MAC_MAX

// Global variables

struct module_t main_module;	// Structure representing our process
bool exit_application = FALSE;	// Time to quit?
char *appName;			// Pointer to argv[0]
char *myName;			// The name of this cybiko
MACaddr myMACaddr;		// The address of this cybiko

// Added after given to students

typedef char Name_t[9];		// Type for nicknames
MACaddr NbrAddr[MAX_HOSTS];	// Keep track of neighbors' addresses
Name_t  NbrName[MAX_HOSTS];	// Capture addresses as well
int numNeighbors;	


// Prototypes for all of my functions

bool Message_Handler(struct Message *cybikoMessage);

void MapNeighbors()
{
    int i;
    
    	NbrAddr[0] = 0xFFFFFFFF;		// Fill in bcast entry
    	strcpy(&(NbrName[0]), "All");
    	
    	Mutex_lock(&finder.finder_mutex, 0);	// lock the finder
	numNeighbors = finder.howmany_around;
	for (i = 0; i < numNeighbors; i++){	// loop through neighbors
	    NbrAddr[i+1] = finder.cf[i].cf_id;
	    strcpy(&(NbrName[i+1]), finder.cf[i].cf_fk.f_nick);
	}
	Mutex_unlock(&finder.finder_mutex);	// unlock the finder
	for (i=0; i<=numNeighbors; i++)
	    WriteText("Key %d: %s (%u)\n", i, NbrName[i], NbrAddr[i]);
}


void DisplayHelp()
{
	WriteText("Press 1-9 to send a message to the corresponding");
	WriteText(" Cybiko, 0 to broadcast to all hosts, or Esc to");
	WriteText(" quit.  The following hosts are known:\n");
	MapNeighbors();
}


//=========================================================================
// Main does all required initialization, then repeats a simple loop until
// it's time to quit.  The loop watches for messages and passes them to
// our message handler as required.  
//=========================================================================

long main(int argc, char* argv[], bool start)
{
    struct Message* ptr_message;	// Pointer used to inspect messages
    char tmpStr[80];
	
	// The "main_module" is a big ugly structure that the CyOS uses
	// to represent our application as it runs.  You can call it
	// whatever you want, but every program needs one, and you must
	// initialize it before doing anything else.
	
	init_module(&main_module);	

	// Never know when our name might come in handy...
	
	appName = argv[0];
	myMACaddr = get_own_id();
	myName = finder.mf.f_nick;
	
	// This call initializes the dialog package.  It takes our main
	// module (NOT a pointer), a message-handling function, and a
	// string to use as the screen's title.
	
	sprintf(tmpStr, "%s: %s [%u]", appName, myName, myMACaddr);
	Console_Init(&main_module, tmpStr);
	Dialogs_Init(&main_module, Message_Handler);	
	
	// We also need to initialize the MAC layer.  It needs a
	// pointer to our main module and the application's name.
	
	MAC_Init(&main_module, appName);
	
	// Now we're ready to go...
	
	TRACE("Cybiko %s (%u) is running", myName, myMACaddr);
	WriteText("Cybiko %s (%u) is running\n", myName, myMACaddr);
	DisplayHelp();
	WriteStatus("Idle");
	
	while(!exit_application)
	{
	    // Look for an event and handle it as necessary.  (Cybiko
	    // terminology refers to all events as "messages", even if they're
	    // not actually data from another machine.)
	    
	    ptr_message = cWinApp_get_message(main_module.m_process,1,1,MSG_MAX);
	    if(ptr_message)
	    {
		Message_Handler(ptr_message);	// Pass msg off to our handler
		Message_delete(ptr_message);	// Delete it when we're done
	    }	
	    	
	    // We need to make frequent calls to the MAC package so it
	    // can take care of housekeeping chores.

	    MAC_Service();
	}

	// Free up memory here before exiting.

	RF_GetStats(tmpStr);
	TRACE("%s", tmpStr);

	Dialogs_Dest();		// Free up memory used in WriteText
	Console_Dest();

	return 0; 
}


// My own name is finder.mf.f_nick;

bool AddrToName(cyid_t id, char *name)
{
    int i;
    
	Mutex_lock(&finder.finder_mutex, 0);		// lock the finder
	for (i = 0; i < finder.howmany_around; i++)	// loop through neighbors
	    if (finder.cf[i].cf_id == id)
	    {
		strcpy(name, finder.cf[i].cf_fk.f_nick);
		Mutex_unlock(&finder.finder_mutex);	// unlock the finder
		return TRUE;
	    }

	name = NULL;
	Mutex_unlock(&finder.finder_mutex);		// unlock the finder
	
	return FALSE;
}



//=========================================================================
// Message_Handler is passed a pointer to a message, and takes the
// appropriate action.  Some messages need to be handled by the dialog and
// MAC packages, so we give them first shot.  If they don't handle the
// messages, we use the switch statement to inspect the msgid and take the
// appropriate action.  If it's nothing we're interested in, pass it to
// cWinApp_defproc in case it's of interest to the OS.
//=========================================================================

bool Message_Handler(struct Message *ptr_message)
{
    bool handled=TRUE;
    char data[80];		
    int i, idx;			
    MACaddr src, dest;
    char *tmpStr;
    char destName[10];

        // See if the WriteText box wants to deal with this message.
        // If it does, we can return without handling it.
        if (Console_Scroll(ptr_message))
	    return TRUE;

	if (MAC_Handler(ptr_message))
	    return TRUE;
    
	switch(ptr_message->msgid)
	{
	  case MSG_SHUTUP:	// Time to quit
	  case MSG_QUIT:
	      exit_application = TRUE;
	      break;

	      
	  case MSG_KEYDOWN:	// A key was pressed.  See p.26
				// for full list of key codes.
	      switch (Message_get_key_param(ptr_message)->scancode)
	      {
		case KEY_ESC:	// Set the exit flag
		    exit_application = TRUE;
		    break;
	      
	  	case KEY_HELP:
	      	    DisplayHelp();
	      	    break;

  		case KEY_0:
		case KEY_1:
		case KEY_2:
		case KEY_3:
		case KEY_4:
		case KEY_5:
		case KEY_6:
		case KEY_7:
		case KEY_8:
		case KEY_9:
		    idx = Message_get_key_param(ptr_message)->scancode - KEY_0;
		    if (idx > numNeighbors)
		    {
			Error_Dialog("%d: Invalid Destination!", idx);
			break;
		    }
		    if (Message_get_key_param(ptr_message)->mask == 
			KEYMASK_SHIFT)
		    {
			tmpStr = Get_Str_Dialog("Enter string to send", 80);
			TRACE("LLC: %d bytes to %s (%u).", 
			    strlen(tmpStr)+1, NbrName[idx], NbrAddr[idx]);
			WriteText("LLC: %d bytes to %s (%u).\n", 
			    strlen(tmpStr)+1, NbrName[idx], NbrAddr[idx]);		
			i = MAC_Send(dest, tmpStr, strlen(tmpStr)+1);
			if (i != strlen(tmpStr)+1)
			    Error_Dialog("MAC_Send didn't send correct amount");
		    }
		    else
		    {		    
			free(tmpStr);		        
			TRACE("LLC: 22 bytes to %s (%u).", 
			    NbrName[idx], NbrAddr[idx]);
			WriteText("LLC: 22 bytes to %s (%u).\n", 
			    NbrName[idx], NbrAddr[idx]);
			i = MAC_Send(NbrAddr[idx], "Hello Wireless World!", 22);
			if (i != 22)
			    Error_Dialog("MAC_Send didn't send correct amount");		    
		    }		    
		    break;		    
  
		case KEY_TAB:	// Print neighbor info
		    MapNeighbors();
		    break;
	      }
	      break;
  
	  case MSG_MAC_ARRIVAL:	// MAC says data has arrived
	  
	      i = MAC_Recv(&src, &dest, data, 64);	      
	      WriteText("LLC: %d bytes from %u.", i, src);
		  
	      if (strlen(data)+1 == i)	// Make sure it's a valid string
		  WriteText(" (\"%s\")\n", data);
	      else
		  WriteText("\n");
	      
	      if (Message_has_buffer(ptr_message))
	      {
		  Alert_Dialog("Arriving data had unexpected buffer.");
		  TRACE("Arriving data had unexpected buffer.");
	      }
	      break;
	    
	  default:		//  Processes all unprocessed messages.
	      handled = cWinApp_defproc(main_module.m_process, ptr_message);
	}
	return handled;		// Report whether message was handled
}
	
