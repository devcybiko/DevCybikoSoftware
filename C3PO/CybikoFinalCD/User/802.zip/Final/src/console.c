//==========================================================================
// Implementation of the console package.  See console.h for details.  In
// this version, the "rightText" field is unused, and the left status field
// has taken over the entire line.
//
// Brad Richards, Nate Waisbrot, 11/2002
//==========================================================================
#include "console.h"

#define LEFT_TEXT_POS	18		// Pixels from left margin
#define	RIGHT_TEXT_POS	66		// Pixels from left margin
#define	STATUS_BOX	13		// Height of status box
#define _WT_MAX_CHARS	2048		// Total chars in text field
#define _WT_MAX_CONTRIB	128		// Maximum # added in one WriteText call

struct module_t *_wind_main;		
static char gDialogMsg[1023];
static char *gWriteTextBuffer;
struct Bitmap onbmp,offbmp;


//--------------------------------------------------------------------------
// Group the form-related data structures together
//--------------------------------------------------------------------------
struct Dialogs
{
	struct cFrameForm* ptrFrameForm;	    
	struct cEdit* ptrMessagesEdit;	
	struct cClip* ptrMessagesClip;	
#ifdef STATUS
	struct cClip* ptrStatusClip;	 
	struct cBevel* ptrStatusBevel;
	struct cBitmap* busy_on;
	struct cBitmap* busy_off;
	struct cText* leftText;
//	struct cText* rightText;
#endif
};


struct Dialogs *mainForm;

//--------------------------------------------------------------------------
// Allocate all memory for all of the structures, construct our custom font,
// and lay out the screen.  Gets a little ugly with all of the conditional
// code...
//--------------------------------------------------------------------------
void Console_Init(struct module_t *main, char * title)
{
    struct Font* mixedminiFont;
    
	_wind_main = main;
	mixedminiFont = malloc(sizeof(struct Font));
	Font_ctor_Ex(mixedminiFont, "mixedmini.fnt", FALSE,0);
	
	mainForm=malloc(sizeof(struct Dialogs));
	mainForm->ptrFrameForm = malloc(sizeof(struct cFrameForm));
	mainForm->ptrMessagesEdit = malloc(sizeof(struct cEdit));
	mainForm->ptrMessagesClip = malloc(sizeof(struct cClip));
#ifdef STATUS
	mainForm->ptrStatusClip   = malloc(sizeof(struct cClip));
	mainForm->ptrStatusBevel  = malloc(sizeof(struct cBevel));
	mainForm->busy_on  = malloc(sizeof(struct cBitmap));
	mainForm->busy_off = malloc(sizeof(struct cBitmap));
	mainForm->leftText = malloc(sizeof(struct cText));
//	mainForm->rightText = malloc(sizeof(struct cText));
#endif
  
	cFrameForm_ctor(mainForm->ptrFrameForm, title, _wind_main->m_process);
	mainForm->ptrFrameForm->HelpContext = 0;
	cEdit_ctor(mainForm->ptrMessagesEdit,
	     mixedminiFont,
	     _WT_MAX_CHARS,
	     es_readonly,
	     CLR_BLACK,
	     150);
	cClip_ctor(mainForm->ptrMessagesClip, 151, 93-STATUS_BOX);
#ifdef STATUS
	cClip_ctor(mainForm->ptrStatusClip, 151, STATUS_BOX);
	cBevel_ctor(mainForm->ptrStatusBevel,156,STATUS_BOX,CLR_BLACK, All);
#endif
	cClip_AddObj(mainForm->ptrMessagesClip, 
	       mainForm->ptrMessagesEdit, 0, 0);
  
#ifdef STATUS
	Bitmap_ctor_Ex1( &onbmp, "on.pic" );
	Bitmap_ctor_Ex1( &offbmp, "off.pic");
	cBitmap_ctor( mainForm->busy_on, &onbmp );
	cBitmap_ctor( mainForm->busy_off, &offbmp );
	cText_ctor(mainForm->leftText,"",mixedminiFont , CLR_BLACK );
//	cText_ctor(mainForm->rightText,"",mixedminiFont , CLR_BLACK );
	cClip_AddObj(mainForm->ptrStatusClip,mainForm->busy_off,1,1);
	cClip_AddObj(mainForm->ptrStatusClip,mainForm->busy_on,1,1);
	cBitmap_Hide(mainForm->busy_on);  
	cClip_AddObj(mainForm->ptrStatusClip,mainForm->leftText,LEFT_TEXT_POS,2);
//	cClip_AddObj(mainForm->ptrStatusClip,mainForm->rightText,RIGHT_TEXT_POS,2);
#endif
	
	// The text field must be added FIRST, or it doesn't scroll to the
	// bottom when the cursor's moved to the end of the text.
	
	cFrameForm_AddObj(mainForm->ptrFrameForm,
		mainForm->ptrMessagesClip,
		0, STATUS_BOX+1);
#ifdef STATUS
	cFrameForm_AddObj(mainForm->ptrFrameForm,mainForm->ptrStatusClip,1,1);
	cFrameForm_AddObj(mainForm->ptrFrameForm,mainForm->ptrStatusBevel,0,1);
#endif
	gWriteTextBuffer = malloc(1024);	
	cCustomForm_Show(mainForm->ptrFrameForm);
}


//--------------------------------------------------------------------------
// Free up all the memory in preparation for quitting the application.
//--------------------------------------------------------------------------
void Console_Dest()
{
	cCustomForm_Hide(mainForm->ptrFrameForm);
	cEdit_dtor(mainForm->ptrMessagesEdit, FREE_MEMORY);
	cClip_dtor(mainForm->ptrMessagesClip, FREE_MEMORY);
#ifdef STATUS
	cBitmap_dtor(mainForm->busy_on, FREE_MEMORY);       
	cBitmap_dtor(mainForm->busy_off, FREE_MEMORY);
	cText_dtor(mainForm->leftText,FREE_MEMORY);
//	cText_dtor(mainForm->rightText,FREE_MEMORY);
	cClip_dtor(mainForm->ptrStatusClip, FREE_MEMORY);
	cBevel_dtor(mainForm->ptrStatusBevel, FREE_MEMORY);	
#endif
	cFrameForm_dtor(mainForm->ptrFrameForm, FREE_MEMORY);
	free(gWriteTextBuffer);
	free(mainForm);
}


//--------------------------------------------------------------------------
// Format a string and append it to the text form.  Chop off 1024 characters
// if necessary to make it fit.
//--------------------------------------------------------------------------
void WriteText(char *format, ...)
{
    char *extraBuffer, *editBuffer;
    int numAdded, newLen, textLen;
    va_list parameters;

	// Generate the string to be added
	
	va_start( parameters, format );
	numAdded = vsprintf(gWriteTextBuffer, format, parameters);
	va_end( parameters );
	
	// If the new contribution would overflow the buffer, throw away
	// all but 1024 characters, then add.
	
	textLen = cEdit_GetTextLength(mainForm->ptrMessagesEdit);
	newLen = textLen + numAdded;
	if (newLen > _WT_MAX_CHARS)
	{
	    textLen = textLen - 1024;
	    editBuffer = cEdit_GetBufferPtr(mainForm->ptrMessagesEdit);
	    extraBuffer = malloc(1024);
	    memcpy(extraBuffer, editBuffer + textLen, 1024);
	    cEdit_SetText(mainForm->ptrMessagesEdit, extraBuffer);
	    free(extraBuffer);
	}	
	cEdit_AppendText(mainForm->ptrMessagesEdit, gWriteTextBuffer);
	cEdit_SetCursorPos(mainForm->ptrMessagesEdit, newLen);	
	return;
}


//--------------------------------------------------------------------------
// Pass the message to the system to see if it's in our clipping region.
// If so, and the system scrolls, return TRUE.
//--------------------------------------------------------------------------
bool Console_Scroll(struct Message* ptr_message)
{
    bool res;
    
	res = cClip_proc(mainForm->ptrMessagesClip, ptr_message);
	cClip_update(mainForm->ptrMessagesClip);
	return res;
}


#ifdef STATUS
//--------------------------------------------------------------------------
// Set the status of the bitmap indicator.
//--------------------------------------------------------------------------
void Busy_On()
{
	cBitmap_Hide(mainForm->busy_off);
	cBitmap_Show(mainForm->busy_on);	
}

void Busy_Off()
{
	cBitmap_Hide(mainForm->busy_on);
	cBitmap_Show(mainForm->busy_off);
}


//--------------------------------------------------------------------------
// Write text to the status fields.  Much simpler, as there's no scrolling
// and the new text just overwrites the old.
//--------------------------------------------------------------------------
void WriteStatus(char* format, ...)
{
    char temp_text[30];
    int len;
    va_list parameters;

	va_start( parameters, format );
	len = vsprintf(gWriteTextBuffer, format, parameters);
	va_end( parameters );

	if (len > 25)
	    gWriteTextBuffer[25] = '\0';
	sprintf(temp_text,"[%s]",gWriteTextBuffer);
TRACE("Status: %s", temp_text);

	cText_SetText(mainForm->leftText,temp_text);
}

#endif
