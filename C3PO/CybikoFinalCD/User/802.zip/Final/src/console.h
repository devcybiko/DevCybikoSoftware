//==========================================================================
// This package provides a scrolling console window with printf-like output
// function.  If STATUS is defined, an additional, non-scrolling field is
// addded at the top of the screen for status information, along with a
// bitmap on/off status indicator.
//
// Brad Richards, Nate Waisbrot, 11/2002
//==========================================================================
#ifndef _CONSOLE_H_
#define _CONSOLE_H_

#include "cywin.h"

#define STATUS

//--------------------------------------------------------------------------
// Must be called before any other routines are used.  It's passed a pointer
// to the application's main module and a string for use as a title.
//--------------------------------------------------------------------------
void Console_Init(struct module_t *main, char *title);

//--------------------------------------------------------------------------
// Destructor for the console package.  Call before quitting application.
//--------------------------------------------------------------------------
void Console_Dest();

//--------------------------------------------------------------------------
// Messages should be passed to this function so it has a chance to catch
// KEY_UP and KEY_DOWN for scrolling purposes.  Returns TRUE if it processed
// the message.
//--------------------------------------------------------------------------
bool Console_Scroll(struct Message *msg);

//--------------------------------------------------------------------------
// Writes text to the console window.  Takes the same args as printf.
//--------------------------------------------------------------------------
void WriteText(char *format, ...);

#ifdef STATUS
//--------------------------------------------------------------------------
// Turn the status indicator on and off.  Default is off.
//--------------------------------------------------------------------------
void Busy_On();
void Busy_Off();

//--------------------------------------------------------------------------
// Writes text into the left and right halves of the status line.  The left
// field truncates after eight characters, the right after 16.
//--------------------------------------------------------------------------
void WriteStatus(char *format, ...);
#endif

#endif
