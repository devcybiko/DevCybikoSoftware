//
//  Cyborn OS - Copyright (C) 2004 Steve Gotthardt - Gotthardt Designs
//
//  This file is part of the Cyborn distribution.
//
//  Cyborn is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  Cyborn is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with Cyborn; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//  A special exception to the GPL can be applied should you wish to distribute
//  a combined work that includes Cyborn, without being obliged to provide
//  the source code for any proprietary components.
//

#include "gfx.h"
#include "lowlevel.h"
#include "lcd.h"



#define DELAY_COUNT 0x18000


void
delay(unsigned long delay)
{
    volatile unsigned long counter = delay;

    while (counter--);
}



typedef enum
{
    SEG_A = 0x01,
    SEG_B = 0x02,
    SEG_C = 0x04,
    SEG_D = 0x08,
    SEG_E = 0x10,
    SEG_F = 0x20,
    SEG_G = 0x40,
} SegT;


// these represent a seven segment display - see:
// http://www.play-hookey.com/digital/experiments/seven_seg_led.html
const static char segments[] =
{
    SEG_A | SEG_B | SEG_C | SEG_D | SEG_E | SEG_F, // zero
    SEG_B | SEG_C , // one
    SEG_A | SEG_B | SEG_D | SEG_E | SEG_G, // two
    SEG_A | SEG_B | SEG_C | SEG_D | SEG_G, // three
    SEG_B | SEG_C | SEG_F | SEG_G, // four
    SEG_A | SEG_C | SEG_D | SEG_F | SEG_G, // five
    SEG_A | SEG_C | SEG_D | SEG_E | SEG_F | SEG_G,  // six
    SEG_A | SEG_B | SEG_C, // seven
    SEG_A | SEG_B | SEG_C | SEG_D | SEG_E | SEG_F | SEG_G, // eight
    SEG_A | SEG_B | SEG_C | SEG_D | SEG_F | SEG_G  // nine
};


//    aaa
//   f   b
//   f   b
//    ggg
//   e   c
//   e   c
//    ddd



// brute force
void
DigitDisplay(int digit, int col, int row)
{
    LcdAreaT area;


    if (segments[digit] & SEG_A)
    {
        area.row = row;
        area.col = col+1;
        area.width = 3;
        area.height = 2;
        LcdArea(&area, GFX_COLOR_BLK);
    }

    if (segments[digit] & SEG_B)
    {
        area.row = row+2;
        area.col = col+4;
        area.width = 1;
        area.height = 8;
        LcdArea(&area, 0xF0);
    }

    if (segments[digit] & SEG_C)
    {
        area.row = row+12;
        area.col = col+4;
        area.width = 1;
        area.height = 8;
        LcdArea(&area, 0xF0);
    }

    if (segments[digit] & SEG_D)
    {
        area.row = row+20;
        area.col = col+1;
        area.width = 3;
        area.height = 2;
        LcdArea(&area, GFX_COLOR_BLK);
    }

    if (segments[digit] & SEG_E)
    {
        area.row = row+12;
        area.col = col;
        area.width = 1;
        area.height = 8;
        LcdArea(&area, 0x0F);
    }

    if (segments[digit] & SEG_F)
    {
        area.row = row+2;
        area.col = col;
        area.width = 1;
        area.height = 8;
        LcdArea(&area, 0x0F);
    }

    if (segments[digit] & SEG_G)
    {
        area.row = row+10;
        area.col = col+1;
        area.width = 3;
        area.height = 2;
        LcdArea(&area, GFX_COLOR_BLK);
    }

}


#define CLOCK_ROW 10
// what about 24 hour and am/pm
void
ClockDisplay(RtcT *rtc)
{
    static int colon;

    // the entries in the rtc are BCD
    DigitDisplay(rtc->hours>>4,         0, CLOCK_ROW);
    DigitDisplay(rtc->hours & 0x0F,     5, CLOCK_ROW);
    DigitDisplay(rtc->minutes>>4,       12, CLOCK_ROW);
    DigitDisplay(rtc->minutes & 0x0F,   17, CLOCK_ROW);

    // do colon
    if (colon ^= 1)
    {
        LcdAreaT area;

        area.col = 11;
        area.row = 7 + CLOCK_ROW;
        area.width = 1;
        area.height = 2;
        LcdArea(&area, 0xF0);

        area.col = 11;
        area.row = 14 + CLOCK_ROW;
        area.width = 1;
        area.height = 2;
        LcdArea(&area, 0xF0);
    }


}





int
main(int argc, char *argv[])
{
    RtcT rtime;

//    _rtcinit(); // init the real time clock - need this?


    for (;;)
    {
        // wipe the LCD display memory clear
        LcdClear(GFX_COLOR_WHT);

        _rtcget(&rtime);

        // could optimize this so that is only called when the time changes
        ClockDisplay(&rtime);


        delay(DELAY_COUNT);  // OS will use sleep for half second or so

    }

    return 0;
}



