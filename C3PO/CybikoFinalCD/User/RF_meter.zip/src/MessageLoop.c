/*
 * FILE: MessageLoop.c
 *
 * DESCRIPTION: Implements the message processing function
 *
 * HISTORY:
 *   Original:   Sep 6, 2000 Created by Aleksey Slesarev
 *
 *   Modified to include RF Signal Meter code:
 *		 Aug 28, 2005 by David Harte
 *   1.1.2  Implements a simple demonstrator for the
 *          RSSI (received signal strength indication) function.
 *
 *   1.1.3  TRACEs message IDs to console.
 *          Level Bar changed from rect to solid bar. 
 *
 *   1.1.4  Added bounce-back feature 
 *	    (press any key on Own Cy to ping other Cy running same app.
 *          Other Cy will auto-respond, RSSI of reply will display on own Cy.)
 *
 *   1.1.5  Final cosmetic changes
 *
 */
#include <cywin.h>

// 14 lines added by DH
#define VERSION      	   " 1.1.5"
#define MSG_OUTBOUND_PING   ( MSG_USER + 3 )
#define MSG_PING_RESPONSE   ( MSG_USER + 5 )
#define All_Cy_IDs	0xFFFFFFFF
__cyos 1357 int get_device_level( cyid_t ); //prototype for the Rx Sig Str function
char* version_str;  // program version
char* app_name;
char sz_caption[8] [ NICKNAMESIZE + 15 ]; 	// Screen output buffer
char data[ NICKNAMESIZE + 1 ];
size_t size;
long param0, param1;
bool update_screen;
bool remote_status;
bool success;
	
/*
 * FUNCTION: ping_partner
 *
 * DESCRIPTION: Ping any neighbouring Cy device to establish a connection
 *
 * PARAMETERS: none
 *
 * RETURNS: remote delivery status (True = delivered)
 */
bool ping_partner( void )
{
  struct Message* ptr_ping_message;

  strcpy( data, finder.mf.f_nick );
  remote_status = FALSE;

  size = strlen( data ) + 1;

  ptr_ping_message = Message_new( sizeof( *ptr_ping_message ) );
  ptr_ping_message->msgid = MSG_OUTBOUND_PING;

  //filling parameters
  param0 = 35;
  param1 = 123;
  
  remote_status = send_remote_msg( 	All_Cy_IDs, 
					app_name, 
					MSG_OUTBOUND_PING, 
					param0, 
					param1, 
					data, 
					size );

   return remote_status;
}


/*
 * FUNCTION: respond_to_ext_ping
 *
 * DESCRIPTION: Respond to a partner's ping
 *
 * PARAMETERS: ping-source partner's cyid
 *
 * RETURNS: remote delivery status (True = delivered)
 */
bool respond_to_ext_ping( cyid_t pinger_id )
{
  struct Message* ptr_resp_message;

  strcpy( data, finder.mf.f_nick );
  size = strlen( data ) + 1;

  remote_status = FALSE;

  param0 = 321;
  param1 = 53;
  
  remote_status = send_remote_msg( 	pinger_id,
					app_name,
					MSG_PING_RESPONSE,
					param0,
					param1,
					data,
					size );
   return remote_status;

}


/*
 * FUNCTION: message_loop
 *
 * DESCRIPTION: Processes messages for the application
 *
 * PARAMETERS:
 *   ptr_main_module -
 *
 * RETURNS: nothing
 */
void message_loop( struct module_t* ptr_main_module )
{

  bool exit_application = FALSE;

// 10 lines added by DH
  int val_rssi;		// Rx Sig Strength Indicator (0 - 100)
  cyid_t own_id;	// Cyber ID of this device
  cyid_t sender_id; 	// Cyber ID of the chat partner's device
  char sy_sender_nickname[ NICKNAMESIZE + 2 ];  // Message sender's nickname
  long n;

  own_id =  get_own_id();
  TRACE( "Own_ID: %x", own_id );

  app_name = cWinApp_get_name( ptr_main_module->m_process );
  version_str = VERSION;
  strcpy ( sz_caption[0], app_name );
  strcat ( sz_caption[0], version_str );

  while( !exit_application )
  {
   struct Message* ptr_message = 
      cWinApp_get_message( ptr_main_module->m_process, 0, 1, MSG_USER );

// 2 If statement blocks added by DH
    if(ptr_message)
       {
	sender_id = ptr_message->cyid_from;
        cyid2str( sy_sender_nickname, sender_id);
       }
    TRACE( "Sender_ID: %x", sender_id );

    if(sender_id != own_id)
       {
	TRACE( "Incoming message, MSG_ID: %x", ptr_message->msgid );
       }

    switch( ptr_message->msgid )
    {
      case MSG_SHUTUP: // Processes the system exit signal
      case MSG_QUIT:

        exit_application = TRUE;

        break;

      case MSG_GOTFOCUS: // Redraws the screen

        DisplayGraphics_fill_screen( ptr_main_module->m_gfx, CLR_WHITE );

        DisplayGraphics_set_color( ptr_main_module->m_gfx, CLR_BLACK );

        DisplayGraphics_set_font( ptr_main_module->m_gfx, cool_normal_font );

// Next line suppressed by DH
//        DisplayGraphics_draw_text( ptr_main_module->m_gfx,
//          "Hello world !", 50, 35 );

// Next 3 'lines' inserted by DH
	DisplayGraphics_draw_text( ptr_main_module->m_gfx,
	      sz_caption[0], 15, 1 );
	DisplayGraphics_draw_text( ptr_main_module->m_gfx,
	      "Press any key ", 10, 25 );
	DisplayGraphics_draw_text( ptr_main_module->m_gfx,
	      "to interrogate remote Cybiko", 10, 37 );
// end of inserted lines
		
        DisplayGraphics_show( ptr_main_module->m_gfx );

        break;

      case MSG_KEYDOWN: // Processes keyboard messages

        if( Message_get_key_param( ptr_message )->scancode == KEY_ESC )
        {
          exit_application = TRUE;
        }
	else
	{
	  success = ping_partner();
	  TRACE( "Random Ping success = %d", success );

	}

        break;

// 2 New cases inserted by DH
      case MSG_PING_RESPONSE: // Handles pings returned from other
	//			Cy device running this same application
	// [This should be altered to detect a message_id for any ping 
	//  but I don't know how to detect them]

	// detect messages only from another device
	if( sender_id != own_id )
	{
	  beep( 0 );
	  // capture the signal strength for this message
	  val_rssi = get_device_level( sender_id );
	  TRACE( "Ping message received (sig strength %d ).",
				val_rssi);
	  strcpy ( sz_caption[1], "" );
          sprintf( sz_caption[2], "Rx from : %s    ",
					  sy_sender_nickname );
          sprintf( sz_caption[3], "Sig Str : %d    ",
					  val_rssi );

	  // flag the program to refresh the display
	  update_screen = TRUE;
	}
	
   	break;

      case MSG_OUTBOUND_PING: // Handles incoming pings that were initiated by 
			      // interrogating Cy device (auto-responding back)
	if( sender_id != own_id )
	   {
		beep( 1 );
		// capture the signal strength for this message
		val_rssi = get_device_level( sender_id );

	 	sprintf ( sz_caption[1], "Responding to %s    ",
					  sy_sender_nickname );
	 	for(n = 2; n<7 ;n++)
	 	   {
	 	     strcpy ( sz_caption[n], "" );
	 	   }
	
		TRACE( "Responding to %s", sy_sender_nickname );
	
	 	respond_to_ext_ping( sender_id );
	
		update_screen = TRUE;
	      }
	
	   break;
	
	
// end of new inserted cases

      default: // Processes all unprocessed messages

        cWinApp_defproc( ptr_main_module->m_process, ptr_message );
    }
 
    Message_delete( ptr_message );

// Extra if statement block added by DH
    if( update_screen )
    {	
 	DisplayGraphics_fill_screen( ptr_main_module->m_gfx, CLR_WHITE );

	// This line constructs a signal bar up the left side of the screen
	draw_bar( 5, 100-val_rssi, 5, val_rssi, CLR_DKGRAY, FALSE );

 	DisplayGraphics_set_color( ptr_main_module->m_gfx, CLR_BLACK );

	 for(n = 0; n<8 ;n++)
	 {
	  DisplayGraphics_draw_text( ptr_main_module->m_gfx,
        	 sz_caption[n], 15, n*12 );
	 }

         DisplayGraphics_show( ptr_main_module->m_gfx );

	 update_screen = FALSE;
    }
// end of extra if statement block

  }
}
