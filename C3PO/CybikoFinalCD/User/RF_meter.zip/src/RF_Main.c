/*
 * FILE: RF_Main.c
 *
 * DESCRIPTION: Interface to message-handler
 *
 * HISTORY:
 *   Based on Step1.c - Sep 6, 2000 Created by Aleksey Slesarev
 *   Migrated and identity altered Aug 28, 2005 by D Harte
 */
#include <cywin.h>

void message_loop( struct module_t* ptr_main_module );

/*
 * FUNCTION: main
 *
 * DESCRIPTION: program entry point
 *
 * PARAMETERS:
 *   argc - number of arguments
 *   argv - array of 'argc' arguments passed to the application
 *   start - TRUE if the application is being initialized, FALSE otherwise
 *
 * RETURNS: 0L
 */
long main( int argc, char* argv[], bool start )
{
  struct module_t main_module;

  init_module( &main_module );

  TRACE( "Main launching Message_Loop process" );

  message_loop( &main_module );

  return 0L;
}
