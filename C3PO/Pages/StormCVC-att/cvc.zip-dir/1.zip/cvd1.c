/*

Cybiko Video 1
Encoder and Decoder
by ssjx 
2003

*/

#include <cybiko.h>

void dec_enc_cv1(char *in,char *out,int size)
{
char col,no;
int c,i;

for(i=0;i<size;i=i+2)
	{
	no=in[i];
	col=in[i+1];

	memset(out,col,no);
	out=out+no;
	}

}


/*
Delta 1 decoder
*/

void dec1_cv1(char *in,char *out,int size)
{
char no;
int c=0,px=0;

	while(c<size)
	{
	no=in[c++];
	
	if (no>=0)
	{
		memset((out+px),in[c++],no);
		px=px+no;
	}
	else
	{
		px=px-no;
	}	

	}

}


//
// Decodes delta2 frames
//

void dec2_cv1(char *in,char *out,int size)
{
char no;
int cnt=0;

while(cnt<size)
	{
	no=in[cnt++];

	if (no>=0)
	{
		memcpy(out,(in+cnt),no);
		out=out+no;
		cnt=cnt+no;
	}
	else
	{
		out=out-no;
	}

	}

}
