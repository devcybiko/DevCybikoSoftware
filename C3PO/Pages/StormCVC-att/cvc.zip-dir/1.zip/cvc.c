
/******** CYBIKO CVC STRUCTS *******/

#include <cybiko.h>
#include "cvc.h"

void dec_enc_cv1(char *,char *,int);
void dec1_cv1(char *,char *,int);
void dec2_cv1(char *,char *,int);

struct FileInput cvc_file_input;

struct cvc_header cy_main_hdr;
struct cvc_video cy_vid_hdr;
struct cvc_audio cy_aud_hdr;
struct cvc_frame cy_vid_frame;

void cvc(char *myfile,struct module_t *ptr_main_module)
{
int c;
char *frm,*cyf;

frm=(char *)malloc(4100);
cyf=(char *)malloc(4100);

memset(frm,0,4000);
memset(cyf,0,4000);

FileInput_ctor(&cvc_file_input);

if( FileInput_open( &cvc_file_input, myfile ))
{
TRACE("Load Main Header...");
Input_read( &cvc_file_input, &cy_main_hdr,12);

TRACE("Load Video Header...");
Input_read( &cvc_file_input, &cy_vid_hdr,18);

TRACE("File : %s",myfile);
TRACE("Size : %d x %d",cy_vid_hdr.x,cy_vid_hdr.y);
TRACE("Rate : %d x %d",cy_vid_hdr.frames,cy_vid_hdr.fps);

for(c=0;c<cy_vid_hdr.frames;c++)
{
Input_read( &cvc_file_input, &cy_vid_frame,6);

TRACE("%d. Size:%ld Subtype:%ld",(c+1),cy_vid_frame.size,cy_vid_frame.subtype);

Input_read( &cvc_file_input,frm,cy_vid_frame.size);

switch(cy_vid_frame.subtype)
{
case 0:
memcpy(cyf,frm,4000);
break;

case 1:
dec_enc_cv1(frm,cyf,cy_vid_frame.size);
break;

case 2:
dec1_cv1(frm,cyf,cy_vid_frame.size);
break;

case 3:
dec2_cv1(frm,cyf,cy_vid_frame.size);
break;
}

/* display frame*/

memcpy(DisplayGraphics_get_page_ptr(ptr_main_module->m_gfx, 0), cyf,4000);
DisplayGraphics_show(ptr_main_module->m_gfx );
}

FileInput_dtor( &cvc_file_input, LEAVE_MEMORY );
}

free(frm);
free(cyf);
}

