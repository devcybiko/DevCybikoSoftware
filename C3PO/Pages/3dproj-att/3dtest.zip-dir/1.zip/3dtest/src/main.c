//
// Simple 3d projection by ssjx
//
// This needs the cy3d.dll for the sin/cos function. This can
// be found in the sdk libs folder. 
//

#include "cybiko.h"

struct module_t main_module;

// fixed_t (short) to int
// It returns a number that should be divided by 256
// to get the actual value. Compensates for the
// lack of float and a real cos/sin function . 

int fx(fixed_t in)
{
int p1,p2,out;
p1=(in & 0xff00)>>8;
p2=(in & 0x00ff);

if (p1<0){p1=p1+256;}
if (p2<0){p2=p2+256;}

out=(p1*256)+p2;
return out;
}


// Converts 3d -> 2d (returns 2d co-ord in rx,ry)
// 5 is the scaling factor, change this to alter
// the perspective.

void conv(int *rx,int *ry,int x,int y,int z)
{
	if (z<0)
	{
		z=-z;
		*rx=x/(z/5);
		*ry=y/(z/5);
	}
	else
	{
		if (z>0)
		{
			*rx=x*(z/5);
			*ry=y*(z/5);
		}
		else
		{	
			*rx=x;
			*ry=y;
		}
	}
}

// Rotate around the Z-axis, ang is the angle in degrees 

void rotz(int *x,int *y,int ang)
{
fixed_t sd,cd;
int tx,ty;

tx=*x;
ty=*y;

sd=fx(cy3d_sin(ang));
cd=fx(cy3d_cos(ang));

*x=((tx*cd)-(ty*sd))/256;
*y=((tx*sd)+(ty*cd))/256;
}

long main(int argc, char *argv[],bool start)
{
int j,x,y,z,ox,oy,rx,ry;

// The following are two objects, the first is a cube
// the second in a pyramid. Comment out the object not
// used and change the for() value below.  

// The objects are made of lines, hence a pair of co-ordinates.
// The co-ords are in the format x,y,z and are relative to a
// center point 0,0,0.

char object[]={-10,10,10, 10,10,10,
10,10,10, 10,-10,10,
10,-10,10, -10,-10,10,
-10,-10,10, -10,10,10,

-10,10,-10, 10,10,-10,
10,10,-10, 10,-10,-10,
10,-10,-10, -10,-10,-10,
-10,-10,-10, -10,10,-10,

-10,10,-10,-10,10,10,  
10,10,-10,10,10,10, 
10,-10,-10,10,-10,10,
-10,-10,-10,-10,-10,10
};

/*
char object[]={-10,-10,-10, 10,-10,-10,
10,-10,-10, 10,-10,10,
10,-10,10, -10,-10,10,
-10,-10,10, -10,-10,-10,

-10,-10,-10, 0,10,0,
10,-10,-10, 0,10,0,
-10,-10,10, 0,10,0,
10,-10,10, 0,10,0,

0,-10,0, 0,10,0
};
*/

init_module( &main_module );
DisplayGraphics_fill_screen(main_module.m_gfx, CLR_WHITE);
TGraph_set_color( main_module.m_gfx, CLR_BLACK );

// j<number of lines in the object. 12 for the cube,9 for the pyramid. 

for(j=0;j<12;j++)
{
	x=object[(6*j)];
	y=object[(6*j)+1];
	z=object[(6*j)+2];

rotz(&x,&y,45);

conv(&rx,&ry,x,y,z);

	x=object[(6*j)+3];
	y=object[(6*j)+4];
	z=object[(6*j)+5];

rotz(&x,&y,45);

conv(&ox,&oy,x,y,z);

TGraph_draw_line( main_module.m_gfx,(80+rx), (50-ry),(80+ox), (50-oy));

}

DisplayGraphics_show(main_module.m_gfx );

sleep(5000);
return 0l;
}