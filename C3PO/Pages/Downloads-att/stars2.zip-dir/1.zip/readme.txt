Stars2
Written by Tim Parkin

Parallax scrolling starfield.