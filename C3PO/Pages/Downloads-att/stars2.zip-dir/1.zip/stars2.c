//stars.c
//written by tim parkin
//6/03/2003
#include <cybiko.h>

#define NUM_STARS 100

struct module_t main_module;
struct DirectKeyboard *ptr_keybd;

struct tPoint
{
  int x, y;
  int color;
};

int starx[ NUM_STARS ];
int stary[ NUM_STARS ];
int starz[ NUM_STARS ];
int starv[ NUM_STARS ];

int x, y;

int done = 0;

void main()
{
  init_module( &main_module );

  ptr_keybd = DirectKeyboard_get_instance();

  srand( (int)clock() );

  for( x = 0; x < NUM_STARS; x++ )
  {
    starx[ x ] = random( 160 );
    stary[ x ] = random( 100 );
    starz[ x ] = random( 2 );
    starv[ x ] = random( 9 ) + 1;
  }

  while( !done )
  {
    DirectKeyboard_scan( ptr_keybd );

    if( DirectKeyboard_is_key_pressed( ptr_keybd, KEY_DEL ) )
      done++;

    TGraph_fill_screen( main_module.m_gfx, CLR_BLACK );

    for( x = 0; x < NUM_STARS; x++ )
    {
      if( starv[ x ] > 6 )
        TGraph_set_color( main_module.m_gfx, CLR_WHITE );
      else if( starv[ x ] > 3 )
        TGraph_set_color( main_module.m_gfx, CLR_LTGRAY );
      else
        TGraph_set_color( main_module.m_gfx, CLR_DKGRAY );

      TGraph_draw_line( main_module.m_gfx, starx[ x ], stary[ x ], starx[ x ], stary[ x ] );

      starx[ x ] -= starv[ x ];

      if( starx[ x ] < 0 )
      {
        starx[ x ] = 160 + random( 160 );
        stary[ x ] = random( 100 );
        starz[ x ] = random( 2 );
        starv[ x ] = random( 5 ) + 1;
      }
    }

    DisplayGraphics_show( main_module.m_gfx );

    sleep( 20 );
  }

  DirectKeyboard_dtor( &ptr_keybd, LEAVE_MEMORY );
}