#include "cybiko.h"
#include "cywin.h"

struct module_t main_module;
struct Message* ptr_message;
struct Bitmap ice;
struct Bitmap blank;
struct Bitmap player;
struct Bitmap heart;
struct Bitmap title;
struct Bitmap win;
struct Bitmap lose;
struct Bitmap cover;

struct Time begin;
struct Time current;

bool exit_game,got_cover, paused;
int i,player_x,player_y,ice_x[10],ice_y[10],ice_v[10],lives,speed,level,max,cover_x,hits, diff, d;

main()
{

  //initialize module
  init_module( &main_module );

  //Create bitmap
  Bitmap_ctor_Ex1( &ice, "ice.pic" );
  Bitmap_ctor_Ex1( &blank, "blank.pic" );
  Bitmap_ctor_Ex1( &player, "player.pic" );
  Bitmap_ctor_Ex1( &heart, "heart.pic" );
  Bitmap_ctor_Ex1( &title, "title.pic" );
  Bitmap_ctor_Ex1( &win, "win.pic" );
  Bitmap_ctor_Ex1( &lose, "lose.pic" );
  Bitmap_ctor_Ex1( &cover, "cover.pic" );

  //Set up variables
  exit_game = FALSE;
  player_x = 80;
  player_y = 90;
  lives = 3;
  level = 1;
  speed = 6;
  max = 5;
  cover_x = 160;
  got_cover = FALSE;
  hits = 0;
  paused = FALSE;

  //Fill the arrays
  for(i = 1; i < 10; i += 1 )
  {
    ice_x[ i ] = (int)random( 151 );
    ice_y[ i ] = 0;
    ice_v[ i ] = (int)random( 5 ) + speed;
  }

//  enable_vibration( TRUE );

  Graphics_draw_bitmap( main_module.m_gfx, &title, 0, 0, BM_NORMAL );
  DisplayGraphics_show( main_module.m_gfx );
  cWinApp_pause(main_module.m_process, 1800 );

  //Fill the screen with dark grey
  TGraph_fill_screen( main_module.m_gfx, CLR_DKGRAY );

  //Difficulty Settings
  textC( 10, 8, cool_bold_font, "Difficulty     Settings", 23, CLR_BLACK, CLR_DKGRAY );
  textC( 20, 50, mini_normal_font, "Easy", 4, CLR_BLACK, CLR_DKGRAY );        
  textC( 56, 50, mini_normal_font, "Challenging", 11, CLR_BLACK, CLR_DKGRAY );  
  textC( 120, 50, mini_normal_font, "Unfair", 6, CLR_BLACK, CLR_DKGRAY );
  DisplayGraphics_show( main_module.m_gfx );
  //38
  i = 25;
  Graphics_draw_bitmap( main_module.m_gfx, &ice, i, 38, BM_NORMAL );
  DisplayGraphics_show( main_module.m_gfx );
  while( diff == 0 )
  {
    getkey();
  }

  TGraph_fill_screen( main_module.m_gfx, CLR_DKGRAY );

  //Draw the player
  Graphics_draw_bitmap( main_module.m_gfx, &player, player_x, player_y, BM_NORMAL );
  DisplayGraphics_show( main_module.m_gfx );

  while( !exit_game )
  {

    vibrate( 0 );

if( !paused )
{
    vibrate( 0 );

    //15% chance of cover appearing and only appear if the player doesn't have it
//    if( (int)random( 101 ) > 85 && cover_x > 150 && !got_cover )
//    {
//      cover_x = (int)random( 151 );
//      Graphics_draw_bitmap( main_module.m_gfx, &cover, cover_x, 90, BM_NORMAL );
//      DisplayGraphics_show( main_module.m_gfx );
//    }

    //Check for new level
    Time_get_RTC( &current );
    if( current.second == 30 || ( current.second == 30 && diff == 3 ) )
    {
      if( current.second == 30 ) { level++; }
      d = diff;
      if( d > 2 ) { d -= 1; }
      switch( level )
      {
        case 2:max = max + d;
          break;
        case 3:max = max + d;
          break;
        case 4:max = max + d;
          break;
        case 5:speed += d;
          break;
        case 6:speed += d;
          break;
        case 7:speed += d;
          break;
        case 8:speed += d;
          break;
        case 9:speed += d;
          break;
        case 10:speed += d;
          break;
        case 11:Graphics_draw_bitmap( main_module.m_gfx, &win, 0, 0, BM_NORMAL );
          DisplayGraphics_show( main_module.m_gfx );
          cWinApp_pause( main_module.m_process, 5000 );
          exit_game = TRUE;
          break;
      }
    }


    //Erase the ice
    for(i = 1; i < max; i++ )
    {
      Graphics_draw_bitmap( main_module.m_gfx, &blank, ice_x[ i ], ice_y[ i ], BM_NORMAL );
      if( ice_y[ i ] > 80 )
      {
        Graphics_draw_bitmap( main_module.m_gfx, &cover, cover_x, 90, BM_NORMAL );
      }

      ice_y[ i ] += ice_v[ i ];

      if( ice_y[ i ] > 81 )
      {
        if( ( ice_x[ i ] > player_x && ice_x[ i ] < player_x + 9 ) || ( player_x > ice_x[ i ] && player_x < ice_x[ i ] + 9) )
        {
          Graphics_draw_bitmap( main_module.m_gfx, &player, player_x, player_y, BM_NORMAL );
          DisplayGraphics_show( main_module.m_gfx );

          ice_y[ i ] = 100;

          if( !got_cover )
          {
            vibrate( 50 );
            if( lives > 0 )
            {
              lives -= 1;
            }

            if( lives < 3 )
            {
              Graphics_draw_bitmap( main_module.m_gfx, &blank, 18, 0, BM_NORMAL );

              if( lives < 2 )
              {
                Graphics_draw_bitmap( main_module.m_gfx, &blank, 9, 0, BM_NORMAL );

                if( lives < 1 )
                {
                  Graphics_draw_bitmap( main_module.m_gfx, &lose, 0, 0, BM_NORMAL );
                  DisplayGraphics_show( main_module.m_gfx );
                  cWinApp_pause( main_module.m_process, 2800 );
                  exit_game = TRUE;
                  //END GAME
                }
              }
              DisplayGraphics_show( main_module.m_gfx );
            }// if( lives < 2 )

          }// if( !got_cover )
          else
          {
            vibrate( 25 );
            hits += 1;
            if( hits > 3 )
            {
              got_cover = FALSE;
              hits = 0;
            }
          }// else if( !got_cover )


        }

      }

      if( ice_y[ i ] > 99 )
      {
        ice_y[ i ] = 0;
        ice_x[ i ] = (int)random( 151 );
        ice_v[ i ] = (int)random( 5 ) + speed;
      }


      Graphics_draw_bitmap( main_module.m_gfx, &ice, ice_x[ i ], ice_y[ i ], BM_NORMAL );
      DisplayGraphics_show( main_module.m_gfx );
    }

}//while( !paused )

    ptr_message = cWinApp_get_message( main_module.m_process, 1, 1, MSG_USER );
    switch( ptr_message->msgid )
    {
      case MSG_SHUTUP: // Processes system exit signals
      case MSG_QUIT:
        exit_game = TRUE;
      case MSG_KEYDOWN: // Processes keyboard input
        if( Message_get_key_param( ptr_message )->scancode == KEY_ESC )
        {
          exit_game = TRUE;
          break;
        }

if( !paused )
{

        if( Message_get_key_param( ptr_message )->scancode == KEY_LEFT )
        {
          Graphics_draw_bitmap( main_module.m_gfx, &blank, player_x, player_y, BM_NORMAL );

          if( player_x > 0 )
          {
            player_x -= 10;
          }
        
          Graphics_draw_bitmap( main_module.m_gfx, &player, player_x, player_y, BM_NORMAL );
          DisplayGraphics_show( main_module.m_gfx );
          break;
        }

        if( Message_get_key_param( ptr_message )->scancode == KEY_RIGHT )
        {
          Graphics_draw_bitmap( main_module.m_gfx, &blank, player_x, player_y, BM_NORMAL );

          if( player_x < 150 )
          {
            player_x += 10;
          } 
        
          Graphics_draw_bitmap( main_module.m_gfx, &player, player_x, player_y, BM_NORMAL );
          DisplayGraphics_show( main_module.m_gfx );
          break;
        }

}//if( !paused )

        if( Message_get_key_param( ptr_message )->scancode == KEY_SELECT )
        {
          if( paused == TRUE ) { paused = FALSE; }
          else { paused = TRUE; };
          break;
        }
      cWinApp_defproc( main_module.m_process, ptr_message );
    }
      cWinApp_defproc( main_module.m_process, ptr_message );
    Message_delete( ptr_message );


    //Check to see if player ran into cover
//    if( ( cover_x > player_x && cover_x < player_x + 9 ) || ( player_x > cover_x && player_x < cover_x + 9) )
//    {
//      got_cover = TRUE;
//      Graphics_draw_bitmap( main_module.m_gfx, &blank, cover_x, 90, BM_NORMAL );
//      Graphics_draw_bitmap( main_module.m_gfx, &player_x, player_x, 90, BM_NORMAL );
//      DisplayGraphics_show( main_module.m_gfx );
//      cover_x = 160;
//    }

    if( lives > 0 )
    {
      Graphics_draw_bitmap( main_module.m_gfx, &heart, 0, 0, BM_NORMAL );
      
      if( lives > 1 )
      {
        Graphics_draw_bitmap( main_module.m_gfx, &heart, 9, 0, BM_NORMAL );

        if( lives > 2 )
        {
          Graphics_draw_bitmap( main_module.m_gfx, &heart, 18, 0, BM_NORMAL );
        }
      }
      DisplayGraphics_show( main_module.m_gfx );
    }// if( lives > 0 )


  }//while( !exit_game )

  //Release the memory used by the bitmaps
  Bitmap_dtor( &ice, FREE_MEMORY );
  Bitmap_dtor( &blank, LEAVE_MEMORY );
  Bitmap_dtor( &player, LEAVE_MEMORY );
  Bitmap_dtor( &heart, LEAVE_MEMORY );
  Bitmap_dtor( &title, LEAVE_MEMORY );
  Bitmap_dtor( &win, LEAVE_MEMORY );
  Bitmap_dtor( &lose, LEAVE_MEMORY );
  Bitmap_dtor( &cover, LEAVE_MEMORY );

  
  return 0;
}

getkey()
{
     ptr_message = cWinApp_get_message( main_module.m_process, 1, 1, MSG_USER );
     if( ptr_message->msgid == MSG_KEYDOWN )
     {
       Graphics_draw_bitmap( main_module.m_gfx, &blank, i, 38, BM_NORMAL );

        if( Message_get_key_param( ptr_message )->mask & KEYMASK_AUTOREPEAT )
        {
        }
        else
        {
          switch( Message_get_key_param( ptr_message )->scancode )
          {
            case KEY_LEFT:
              switch( i )
              {
                case 25:
                  i = 129;
                  break;
                case 75:
                  i = 25;
                  break;
                case 129:
                  i = 75;
                  break;
              }
              break;

            case KEY_RIGHT:
              switch( i )
              {
                case 25:
                  i = 75;
                  break;
                case 75:
                  i = 129;
                  break;
                case 129:
                  i = 25;
                  break;
              }
              break;

            case KEY_ENTER:
              switch( i )
              {
                case 25:
                  diff = 1;
                  break;
                case 75:
                  diff = 2;
                  break;
                case 129:
                  diff = 3;
                  break;
              }
              break;
            case KEY_ESC:
              exit_game = TRUE;
          }

        }

      Graphics_draw_bitmap( main_module.m_gfx, &ice, i, 38, BM_NORMAL );
      DisplayGraphics_show( main_module.m_gfx );

    }
    Message_delete( ptr_message );

}