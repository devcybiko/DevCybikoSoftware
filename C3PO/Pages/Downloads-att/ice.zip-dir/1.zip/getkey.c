#include <cywin.h>

struct module_t main_module;
struct Message* ptr_message;

bool exit_game;

main()
{
  init_module( &main_module );
  exit_game = FALSE;

  while( !exit_game )
  {
    getkey();
  }

  return 0;
}

getkey()
{
     ptr_message = cWinApp_get_message( main_module.m_process, 1, 1, MSG_USER );
     if( ptr_message->msgid == MSG_KEYDOWN )
     {
        if( Message_get_key_param( ptr_message )->mask & KEYMASK_AUTOREPEAT )
        {
        }
        else
        {
          switch( Message_get_key_param( ptr_message )->scancode )
          {
            case KEY_ENTER:
              break;
            case KEY_ESC:
              exit_game = TRUE;
          }

        }
    }
    Message_delete( ptr_message );

}