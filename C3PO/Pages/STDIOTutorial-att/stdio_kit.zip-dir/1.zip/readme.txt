/*
 * STDIO Command List
 *
 *   printf("text\n");  -  displays text onscreen, then goes down a line.
 *   printf(" ");       -  waits for the user to input something.
 *   gets( varname );   -  gets input from the user and assigns it to varname.
 *   getchar();         -  waits for a single key to be pressed.
 *
 *
 * Notes
 *
 *   STDIO adds roughly 2 KB to your .app file.
 *   STDIO stands for Standard Input/Output.
 *   When you print using STDIO, it prints from the bottom to the top.
 *
 */