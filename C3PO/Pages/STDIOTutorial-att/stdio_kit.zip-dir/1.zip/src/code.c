#include <CyWin.h>
#include "stdio.h"

struct module_t main_module;

int process_message(struct Message *message);

long main(int argc, char* argv[], bool start)
{
  init_module(&main_module);
  init_putc();

  // Coding Here

  return 0;
}

int process_message(struct Message *message)
{

}
#include "stdio.c"