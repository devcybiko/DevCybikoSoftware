// Step 3
// Created by Tom Reece
//
// http://www.cydevr.net

#include <CyWin.h>
#include "stdio.h"

int process_message(struct Message *message);

struct module_t main_module;

long main(int argc, char* argv[], bool start)
{
  char name[32];

  init_module(&main_module);
  init_putc();

  printf("Please enter your name: ");
  gets ( name );
  printf("Welcome to Cybiko C, %s", name);
  printf("\n");
  printf("Press and key to exit...");

  getchar();

  return 0;
}

int process_message(struct Message *message)
{

}
#include "stdio.c"
