// stdio.h
// (C) The Alcor Group, Inc
// Copyright Jan 2001

#ifndef _STDIO_H_
#define _STDIO_H_

#define MALLOC(n,type) (type *)malloc(n * sizeof(type))
#define CALLOC(n,type) (type *)calloc(n, sizeof(type))
#define rindex(s,c) strrchr(s,c)
#define SAME(a,b) (strcmp(a,b) == 0)

struct _file {
	long type;
	void *cybio;
    struct Archive *archive;
};

#ifndef EOF
#define EOF (-1)
#endif

#define FILE struct _file
#define stdout ((FILE *)-1)
#define stdin ((FILE *)-2)
#define stderr ((FILE *)-3)

FILE *fopen(char *name, char *mode);
void fclose(FILE *);
char *ltoa(long a, char *buf, int buflen);
int printf(char *fmt, ...);
long ftell(FILE *file);
int fgets(char *buf, int buflen, FILE *file);
int fprintf(FILE *file, char *fmt, ...);
int fputc(int c, FILE *file);
void putc(int c);
int fgetc(FILE *file);
long fseek(FILE *file, long n, int whence);
char *gets(char *inrec);
long fread(void *ptr, size_t size, size_t nitems, FILE *file);
long fwrite(void *ptr, size_t size, size_t nitems, FILE *file);
int sscanf(char *s, char *fmt, ...);
int tolower(int c);
long rand(void);
void init_putc();
#endif //_STDIO_H_
