<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<!-- saved from url=(0062)http://www.cs.uoregon.edu/research/wearables/software/assert.h -->
<HTML><HEAD>
<META http-equiv=Content-Type content="text/html; charset=windows-1252">
<META content="MSHTML 6.00.2722.900" name=GENERATOR></HEAD>
<BODY><PRE>/****************************************
/*  assert.h							*
/*  Dustin Preuitt 2001					*
/*	v 1.0								*
/* An attempt to bring Cybiko C closer  *
/* ANSI C (after all, isn't that why we *
/* have standards?)						*
/***************************************/

#ifndef __CY_ASSERT_H__
#define __CY_ASSERT_H__

#include "CyWin.h"

#define assert(n)  if(!(n)){cprintf("Assertion failed: %s  in File %s Line %d\n","n", __FILE__,__LINE__ -1);exit(0);}






#endif</PRE></BODY></HTML>
