<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<!-- saved from url=(0061)http://www.cs.uoregon.edu/research/wearables/software/ctype.c -->
<HTML><HEAD>
<META http-equiv=Content-Type content="text/html; charset=windows-1252">
<META content="MSHTML 6.00.2722.900" name=GENERATOR></HEAD>
<BODY><PRE>/****************************************
/*  ctype.c								*
/*  Dustin Preuitt 2001					*
/*	version 1.0							*
/* An attempt to bring Cybiko C closer  *
/* ANSI C (after all, isn't that why we *
/* have standards?)						*
/***************************************/


#include "ctype.h"


int isalnum(int c)
{
	if ((isalpha(c)) || (isdigit(c)))
		return 1;
	return 0;
}

int isalpha(int c)
{
	if ((isupper(c)) || (islower(c)))
	  return 1;
	return 0;
}

/* Not sure which characters are actually control characters in Cybikoland */
int iscntrl(int c)
{
	if ((c &gt;= 0) &amp;&amp; (c &lt;= 31))
		return 1;
	return 0;
}

int isdigit(int c)
{
	if ((c &gt;= 48) &amp;&amp; (c &lt;= 57))
		return 1;
	return 0;
}

/*  Not quite sure this one is correct either */
int isgraph(int c)
{
	if ((c &gt;= 33) &amp;&amp; (c &lt;= 255))
	  return 1;
	return 0;
}


int islower(int c)
{
	if ((c &gt;= 97) &amp;&amp; (c &lt;= 122))
		return 1;
	return 0;
}

/*  Not quite sure this one is correct either */
int isprint(int c)
{
	if ((c &gt;= 32) &amp;&amp; (c &lt;= 255))
	  return 1;
	return 0;
}


int ispunct(int c)
{
	if ((!isalnum(c)) &amp;&amp; (!isspace(c)) &amp;&amp; (isprint(c)))
		return 1;
	return 0;
}

int isspace(int c)
{
	if (c == 32)
		return 1;
	return 0;
}

int isupper(int c)
{
	if ((c &gt;= 65) &amp;&amp; (c &lt;= 90))
		return 1;
	return 0;
}

/* Returns a nonzero value if c is a hex digit (0-9,a-f,A-F), zero otherwise */
int isxdigit(int c)
{
	if (((c &gt;= 48) &amp;&amp; (c&lt;=57)) || ((c &gt;= 65) &amp;&amp; (c &lt;= 70)) || ((c &gt;= 97) &amp;&amp; (c &lt;= 102)))
		return 1;
	return 0;
}
</PRE></BODY></HTML>
