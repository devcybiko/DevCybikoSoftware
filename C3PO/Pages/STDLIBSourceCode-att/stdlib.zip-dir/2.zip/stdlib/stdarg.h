/****************************************
/*  stdarg.h							*
/*  Dustin Preuitt 2001					*
/*	v1.0								*
/* An attempt to bring Cybiko C closer  *
/* ANSI C (after all, isn't that why we *
/* have standards?)						*
/***************************************/

#ifndef __CY_STDARG_H__
#define __CY_STDARG_H__

typedef void *va_list;


/*  void va_start(va_list ap, parmN)  */
#define va_start(ap, parmN)		(void)(ap = (void *)(&parmN + sizeof(parmN)))

/*  type va_arg(va_list ap, type	 */
#define va_arg(ap, type)  	*(type *)((type *)(ap = (void*)((type *)ap + sizeof(type)))- sizeof(type))

/*  void va_end(va_list ap);   		 */
#define va_end(ap)		(void)0


#endif
