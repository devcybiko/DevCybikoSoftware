/****************************************
/*  string.c							*
/*  Dustin Preuitt 2001					*
/*	version 1.0							*
/* An attempt to bring Cybiko C closer  *
/* ANSI C (after all, isn't that why we *
/* have standards?)						*
/***************************************/


void *memchr(const void *s, int c, size_t n)
{
	int index;
	int tmpval;

	for (index = 0; index < n; index++)
	{
		tmpval = (char)((char *)s)[index];
	  	if ( tmpval == (char)c)
	    	return ((char *)s +index);
  	}
  return NULL;
}

/*  Local only to the US.  Just does normal strcmp */
int strcoll(const char *s1, const char *s2)
{

	return strcmp(s1,s2);

}

/*  Get the length of the longest span in s1 that doesn't contain any characters from s2.  Tested */
size_t strcspn(const char *s1, const char *s2)
{
	int max_length = 0;
	int i, j;
	int curr_length = 0;

	for (i = 0; i < strlen(s1); i++)
	  {
		  for (j = 0; j < strlen(s2); j++)
		  {
			  if (s1[i] == s2[j])
			  	break;
			//  else curr_length++;
	      }
	    if (s1[i] != s2[j])
			{
	   		   curr_length++;
	   		   if (curr_length > max_length)
	   		    	max_length = curr_length;
			}
		else curr_length = 0;
      }

    return (size_t)max_length;

}

/* Copies first n characters, from s2 to s1, unless null is encountered. */
char *strncat(char *s1, const char *s2, size_t n)
{
//	char *tempstr;
	int index;
	int s1len = strlen(s1);

//	strcpy(tempstr, s1);
//	tempstr = malloc(strlen(s1) + n +1);
	for (index = 0; index < n; index++)
	  {
		  if (s2[index] == '\0')
			break;
		  s1[s1len + index] = s2[index];
	  }
	s1[s1len+index] = '\0';

//	*s1 = *tempstr;
	return s1;
}

/* finds the firstmost position that a character in s2 is in s1 */
char *strpbrk(const char *s1, const char *s2)
{
	int index1, index2;


	for (index1 = 0; index1 < strlen(s1); index1++)
	  for (index2 = 0; index2 < strlen(s2); index2++)
	  	if (s1[index1] == s2[index2])
	  		return (char *)(s1+index1);

	return NULL;
}


/* Length of longest INITIAL segment span in s1 that consists of characters entirely from s2 */
size_t strspn(const char *s1, const char *s2)
{
	int max_count = 0;
	int tmp_count;
	int index1;
	int index2;
	int spnflag = 0;   /* decide if in a span or not */

	for (index1 = 0; index1 < strlen(s1); index1++)
	  {
		  tmp_count = max_count;  /* Check after loop to see if the next letter was in s2 */
		  for (index2 = 0; index2 < strlen(s2); index2++)
			{
				if (s1[index1] == s2[index2])
					{
						spnflag = 1;
						max_count++;
						break;
					}

		    }  //end for index2
		   if (spnflag)
		   		if (tmp_count == max_count)  /*The count hasn't changed. No more letters in span */
		   		   return max_count;
	  }  //end for index1

}

/*  Removes the next token from s1  and returns it.  Delimiters can be any character in s2 */
char *strtok(char *s1, const char *s2)
{
	int ix1;
	int ix2;
	int len1 = strlen(s1);
	int len2 = strlen(s2);
	int exit_flag = 0;
	char *retstr;
    static char *strtokptr;    /* a pointer used in strtok. */

	if (s1 != NULL){
		strtokptr = s1;
	}
	else len1 = strlen(strtokptr) +1;

	retstr = strtokptr;

	for (ix1 = 0; ix1 < len1; ix1++)
	  {
		  if (strtokptr[ix1] == '\0'){
			  strtokptr = strtokptr + ix1;
		      break;
		  }
		  for (ix2 = 0; ix2 < len2; ix2++)
		    {
			if (strtokptr[ix1] == s2[ix2])
			  {
				  strtokptr[ix1] = '\0';
				  strtokptr = strtokptr + strlen(retstr)+1;
				  exit_flag = 1;
				  break;
			  }
			}
		  if (exit_flag)
		    break;
	  }
	if (strlen(retstr) == 0)
		retstr = NULL;
	return retstr;
}

char *strerror(int errnum)
{
	char retstr[15];
	sprintf(retstr, "Error: %i.\n", errnum);
	return retstr;
}


/*  Contains no local info.  Same as strncpy */
size_t strxfrm(char *s1, const char *s2, size_t n)
{
	strncpy(s1,s2,n);
	return strlen(s1);
}
