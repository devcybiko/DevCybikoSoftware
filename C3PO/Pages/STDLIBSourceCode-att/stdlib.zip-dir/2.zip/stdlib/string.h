/****************************************
/*  string.h							*
/*  Dustin Preuitt 2001					*
/*	version 1.0							*
/* An attempt to bring Cybiko C closer  *
/* ANSI C (after all, isn't that why we *
/* have standards?)						*
/***************************************/

#ifndef __CY_STRING_H__
#define __CY_STRING_H__



/*  Finds character c in the first n letters of s.  Tested. */
void *memchr(const void *s, int c, size_t n);

/*  Local only to the US.  Just does normal strcmp */
int strcoll(const char *s1, const char *s2);

/*  Get the length of the longest span in s1 that doesn't contain any characters from s2.  Tested */
size_t strcspn(const char *s1, const char *s2);

/*  Not actuall implemented in this version. */
char *strerror(int errnum);

/* Concatenates first n characters, from s2 to s1, unless null is encountered.  Tested */
char *strncat(char *s1, const char *s2, size_t n);

/* finds the firstmost position that a character in s2 is in s1.  Tested*/
char *strpbrk(const char *s1, const char *s2);

/* Length of longest INITIAL segment span in s1 that consists of characters entirely from s2. Tested */
size_t strspn(const char *s1, const char *s2);

/*  Removes the next token from s1  and returns it.  Delimiters can be any character in s2.  Tested */
char *strtok(char *s1, const char *s2);

/*  Contains no local info.  Same as strncpy */
size_t strxfrm(char *s1, const char *s2, size_t n);


/**************************************************************************/
/*  String.h functions defined in cybiko.h :                              */


/* Compares two character buffers. */
/* int memcmp(const void *s1, const void *s2, size_t n); Defined in cybiko.h but without "const" */

/* Copies characters between two buffers. */
/* void *memcpy(void *s1, const void *s2, size_t n);  Defined in cybiko.h but without "const" */

/* Moves one buffer to another. */
/*void *memmove(void *s1, const void *s2, size_t n);  Defined in cybiko.h but without "const" */

/* Sets buffers to specified character */
/*void *memset(void *s, int c, size_t n);  Defined in cybiko.h */

/* Appends one string to another */
/*char *strcat(char *s1, const char *s2);  Defined in cybiko.h but without "const" */

/* Find a character in a string */
/*char *strchr(const char *s, int c);  Defined in cybiko.h but without "const" */

/* Lexigraphically compares s1 to s2 */
/*int  strcmp(const char *s1, const char *s2);   Defined in cybiko.h but without "const" */

/* Copies s2 to s1 */
/* char *strcpy(char *s1, const char *s2);  Defined in cybiko.h but without "const" */

/* Returns the length of a string*/
/* size_t strlen(const char *s);  Defined in cybiko.h but without "const" */

/*  Compares substrings of two buffers */
/* int strncmp(const char *s1, const char *s2, size_t n);  Defined in cybiko.h but without "const" */

/*  Copies a substring from s2 to s1 */
/*char *strncpy(char *s1, const char *s2, size_t n);  Defined in cybiko.h but without "const" */

/*  Searches a string for the last occurence of a character  */
/*char *strrchr(const char *s, int c);  Defined in cybiko.h but without "const" */

/* Finds a substring s2 in s1*/
/*char *strstr(const char *s1, const char *s2);  Defined in cybiko.h but without "const" */



#endif
