
/* Main header <12> */

struct cvc_header 
{
char id[4]; 		/* cyvd */
long size;
short lock;			/* encryption key */
short headers;		/* number of header to expect */
};


/* Video <18> */

struct cvc_video
{
char id[4]; 		/* "vido" */
short x;	
short y;
long frames;
short fps;
char format[4];    	/* ="cyv1";*/
};


/* Audio <14> */

struct cvc_audio
{
char id[4];				/* "auds" */
short channels;   		/* eg. 2 */
short bitrate;			/* 192
short freq;				/* 44100 */	
char format[4];			/* "cya1" */
};


/* Frame header <6> */ 

struct cvc_frame
{
short type;
short size;
short subtype;
};



/**************************/
