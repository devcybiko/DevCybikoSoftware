#include <stdio.h>

typedef struct
{
  unsigned char *p;
  unsigned long long_1;
  unsigned long long_2;
} CY_STRUCT;
  

unsigned long cy_dec2(CY_STRUCT *pstruct)
{
  unsigned long local_1;
  
  local_1 = pstruct->long_2;
  
  if ((local_1 & 0xff00) == 0)
  {
    local_1 = pstruct->p[pstruct->long_1++] | 0xff00;
  }
  
  pstruct->long_2 = local_1 >> 1;
  
  return (local_1 & 1);
}


unsigned long cy_dec3(CY_STRUCT *pstruct, unsigned long count)
{
  unsigned long local_1;
  unsigned long local_2;
  
  local_1 = pstruct->long_2;
  local_2 = 0;
  
  do
  {
    if ((local_1 & 0xff00) == 0)
    {
      local_1 = pstruct->p[pstruct->long_1++] | 0xff00;
    }
    
    local_2 <<= 1;
    local_2 |= (local_1 & 1);
    local_1 >>= 1;
  } while (--count);
  
  pstruct->long_2 = local_1;
  
  return local_2;
}


unsigned long cy_dec1(CY_STRUCT *pstruct, unsigned char *dst, unsigned long p3, unsigned long p4, unsigned long clen)
{
  unsigned long local_1;
  unsigned long local_2;
  unsigned long local_3;
  unsigned long local_4;
  
  do
  {
    if (cy_dec2(pstruct) != 0)
    {
      switch (cy_dec3(pstruct, 2))
      {
        case 0: local_1 = 2; break;
        case 1: local_1 = 3; break;
        case 2: local_1 = 4 + cy_dec2(pstruct); break;
        default:
          switch (cy_dec3(pstruct, 2))
          {
            case 0: local_1 = 6; break;
            case 1: local_1 = 8 + cy_dec2(pstruct); break;
            case 2: if (cy_dec2(pstruct) == 0)
                      local_1 = 7;
                    else
                      local_1 = 10 + cy_dec2(pstruct);
                    break;
            default:
              switch (cy_dec3(pstruct, 3))
              {
                case 0: local_1 = 12; break;
                case 1: local_1 = 13; break;
                case 2: local_1 = 20 + cy_dec3(pstruct, 2); break;
                case 3: local_1 = 16 + cy_dec2(pstruct); break;
                case 4: local_1 = 24 + cy_dec3(pstruct, 3); break;
                case 5: local_1 = 14; break;
                case 6: if (cy_dec2(pstruct) == 0)
                          local_1 = 32 + cy_dec3(pstruct, 5);
                        else
                          local_1 = 18 + cy_dec2(pstruct);
                        break;
                default:if (cy_dec2(pstruct) == 0)
                          local_1 = 15;
                        else if (cy_dec2(pstruct) == 0)
                          local_1 = 64 + cy_dec3(pstruct, 6);
                        else if (cy_dec2(pstruct) == 0)
                          local_1 = 128 + cy_dec3(pstruct, 7);
                        else
                          local_1 = 256;
              }
          }
      }
      
      switch (cy_dec3(pstruct, 3))
      {
        case 0: local_2 = 1024 + cy_dec3(pstruct, 10); break;
        case 1: local_2 = 512 + cy_dec3(pstruct, 9); break;
        case 2: local_2 = 256 + cy_dec3(pstruct, 8); break;
        case 3: local_2 = 64 + cy_dec3(pstruct, 6); break;
        case 4: local_2 = 128 + cy_dec3(pstruct, 7); break;
        case 5: if (cy_dec2(pstruct) == 0)
                  local_2 = 2048 + cy_dec3(pstruct, 11);
                else
                  local_2 = 4096 + cy_dec3(pstruct, 12);
                break;
        case 6: if (cy_dec2(pstruct) == 0)
                  local_2 = 32 + cy_dec3(pstruct, 5);
                else
                  local_2 = 16 + cy_dec3(pstruct, 4);
                break;
        default:
          switch (cy_dec3(pstruct, 2))
          {
            case 0: local_2 = cy_dec2(pstruct); break;
            case 1: local_2 = 6 + cy_dec3(pstruct, 2); break;
            case 2: if (cy_dec2(pstruct) == 0)
                      local_2 = 4 + cy_dec2(pstruct);
                    else
                      local_2 = 2;
                    break;
            default:
              switch (cy_dec3(pstruct, 2))
              {
                case 0: local_2 = 12 + cy_dec2(pstruct); break;
                case 1: local_2 = 14 + cy_dec2(pstruct); break;
                case 2: local_2 = 3; break;
                default:local_2 = 10 + cy_dec2(pstruct);
              }
          }
      }

      local_2 += local_1;
      do
      {
        dst[p3 & p4] = dst[(p3 - local_2) & p4];
        p3++;
      } while (--local_1);
    }
    else
    {
      dst[p3++ & p4] = cy_dec3(pstruct, 8);
    }
  } while (pstruct->long_1 < clen);
    
  return p3;
}


unsigned long cy_dec(unsigned char *dst, unsigned char *src, unsigned long clen)
{
  CY_STRUCT local_1;
  
  local_1.p  = src;
  local_1.long_1 = 0;
  local_1.long_2 = 0;
  
  return cy_dec1(&local_1, dst, 0, 0x7fffffff, clen);
}


#define BUF_SIZE    (64*1024UL)

int main(int argc, char **argv)
{
  unsigned char *src;
  unsigned char *dst;

  unsigned long clen;
  unsigned long plen;
  unsigned long olen;
  unsigned long counter;
  
  FILE *fin;
  FILE *fout;
  
  src = (unsigned char *) malloc(BUF_SIZE);
  dst = (unsigned char *) malloc(BUF_SIZE);

  fin = fopen(argv[1], "rb");					 /* I: compressed file */
  clen = fread(src, 1, BUF_SIZE, fin);
  fclose(fin);
  
  plen = cy_dec(dst, src, clen);

  fout = fopen(argv[2], "wb");				 /* O: plain file */
  fwrite(dst, 1, plen, fout);
  fclose(fout);

  printf("C %d\tP %d\n", clen, plen);
  
  fin = fopen(argv[3], "rb");					 /* I: original file */
  olen = fread(src, 1, BUF_SIZE, fin);
  fclose(fin);

  for (counter = 0; counter < olen; counter++)    /* simple cmp */
  {
	 if (src[counter] != dst[counter])
	 {
	   printf("%08u %02x %02x\n", counter, src[counter], dst[counter]);
	 }
  }

  free(src);
  free(dst);

  return 0;
}
