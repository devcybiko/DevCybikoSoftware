/*
Cybiko Wave Module
by ssjx

Note : This does not work yet, at the moment it just produces noise.



*/

#include <cybiko.h>

//
// Wave Structs
//

/* Chunk (8) */
struct chk
{
char id[4]; /* 'fmt ','data', */
long size;
}chunk;


/* Format (16-144) */
struct
{
short comp;
short channels;
long rate;
long byteps;
short block;
short bits;
char space[128];
}fmt;

/**************************/

//
// Byte swapping function (PC -> Amiga/Cybiko)
//

long swp(long num)
{
long a,b,c,d;
a=(num & 0xff000000)>>8;
a=(a & 0xff0000)>>16;

b=(num & 0x00ff0000)>>8;
c=(num & 0x0000ff00)<<8;
d=(num & 0x000000ff)<<24;

return (a+b+c+d);
}


int bswp(int num)
{
int a,b;
a=(num & 0xff00)>>8;
b=(num & 0x00ff)<<8;
return (a+b);
}

// Yes, i know the next function is almost a waste of space...

int comp(char *first,char *second)
{
return memcmp(first,second,4);
}

/**************************/



int getinput()
{
struct DirectKeyboard* ptr_direct_keyboard;
int mykey=0;

ptr_direct_keyboard = DirectKeyboard_get_instance();
DirectKeyboard_scan( ptr_direct_keyboard );

if ( DirectKeyboard_is_key_pressed( ptr_direct_keyboard, KEY_SPACE ) ){mykey=-1;}

DirectKeyboard_dtor( ptr_direct_keyboard, FREE_MEMORY );
return mykey;
}

/* --------------------- */


void wave(char *myfile)
{
struct FileInput file_input;
long f,wavesize,datasize,aud,rate;
int i,sec,blocksize,out=0,pcm=0,cnt=1,w,delay;
char *audioframe;

audioframe=(char *)malloc(12000);

FileInput_ctor(&file_input);

if (FileInput_open( &file_input, myfile))
{
TRACE("Loading...\n");
FileInput_seek( &file_input, 12, SEEK_SET );

//
// Only looks for 3 chunks: fmt,fact and data
//

for(i=0;i<3;i++)
{
Input_read( &file_input, &chunk,8);

if (comp(chunk.id,"fmt ")==0)
{
TRACE("Chunk: Format (%d)",swp(chunk.size));
Input_read( &file_input, &fmt,swp(chunk.size));

}

if (comp(chunk.id,"fact")==0)
{
Input_read( &file_input, &wavesize,4);
TRACE("Wave size: %ld",swp(wavesize));
}

if (comp(chunk.id,"data")==0)
{
datasize=swp(chunk.size);
TRACE("Data size: %ld",datasize);
}

}

//
// Show what compression is being used
//

switch(bswp(fmt.comp))
{
case 1:
TRACE("Compression = PCM");
break;

case 2:
TRACE("Compression = MS-ADPCM4");
break;

case 85:
TRACE("Compression = MPEG2-III");
break;

default:
TRACE("Compression = Unknown (%d)",bswp(fmt.comp));
break;
}

if (bswp(fmt.comp)==1)
{
sec=datasize/swp(fmt.rate);
}
else
{
sec=swp(wavesize)/swp(fmt.rate);
}


TRACE(" ---- Info ----");
TRACE("Compression : %d",bswp(fmt.comp));
TRACE("Channels    : %d",bswp(fmt.channels));
TRACE("Rate        : %d",swp(fmt.rate));
TRACE("Bytes       : %d",swp(fmt.byteps));
TRACE("Blocks      : %d",bswp(fmt.block));
TRACE("Quality     : %d bits",bswp(fmt.bits));
TRACE(" ---- Clip ----");
TRACE("Length      : %ld seconds",sec);


/*
Go through the frames.
At the moment it is only set up to handle 8bit 11025hz mono files. 

The loop reads in a second of the wave (which is 11025 bytes or less),
the inner loop then tries to play that sample.

We are making use of the fact that the bytes per second and the sample
rate are the same. If this was going to handle compressed audio, the
loop would be layed out differently.
*/

blocksize=bswp(fmt.block);
rate=swp(fmt.byteps);

for(f=0;f<sec;f++)
{
Input_read( &file_input, audioframe,rate);

	for(w=0;w<rate;w=w+40)
	{
	out=audioframe[w];
	if (out<0){out=out+256;}

//	play_tone(32);	
//	for (delay=0;delay<out;delay++){}
//	play_tone(-1);
	
	if (getinput()==-1){break;}

	}

if (getinput()==-1){break;}
	
//	TRACE("pos: %d/%d",f,sec);
}


}
else
{
TRACE("Could not open file");
}

if (is_tone_playing()){play_tone(-1);};
       

FileInput_dtor( &file_input, LEAVE_MEMORY );
TRACE("Finished");

free(audioframe);
}
