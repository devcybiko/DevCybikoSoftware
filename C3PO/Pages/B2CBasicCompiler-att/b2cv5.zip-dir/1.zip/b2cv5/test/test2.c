/***************************************************
/* Program translated by b2c Version 5
/* b2c (C) Copyright 2001 The Alcor Group, Inc
/* Written by Greg Smith
/*
/* Program test2.tmp converted Tue Apr 23 22:23:36 2002
/****************************************************/
#include "b2cuser.h"
int _true=1;
int _true_=1;
int _false_=0;
int _c_coords=0;
int _n_sprites=32;
int _n_3dsprites=8;
int _n_rooms=8;
int error=0;
int _show_=1;
int b2c_decimals=2;
int _escape_=1;
int _help_=1;
int _multitask_=0;
void onmessage(long cyid, int msgno, char *buffer)
{}
int  i;
int  c;
main() {
TRACE("Created by B2C Version 5");
_init_b2c();
_escape_=0;
_help_=1;
_multitask_=0;
while(_true_) {
c=_key(0);
if ((c==KEY_HELP))
{
_print("%s","HELP");
}
;
if ((c==KEY_ESC))
{
_print("%s","ESCAPE");
}
;
_print("%d",i);
i=i+1;
}
_destroy_b2c();
return 0;
}
