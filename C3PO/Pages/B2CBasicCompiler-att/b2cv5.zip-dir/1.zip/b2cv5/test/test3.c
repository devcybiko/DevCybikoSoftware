/***************************************************
/* Program translated by b2c Version 5
/* b2c (C) Copyright 2001 The Alcor Group, Inc
/* Written by Greg Smith
/*
/* Program test3.tmp converted Tue Apr 23 21:28:02 2002
/****************************************************/
#include "b2cuser.h"
int _true=1;
int _true_=1;
int _false_=0;
int _c_coords=0;
int _n_sprites=32;
int _n_3dsprites=8;
int _n_rooms=8;
int error=0;
int _show_=1;
int b2c_decimals=2;
int _escape_=1;
int _help_=1;
int _multitask_=1;
void onmessage(long cyid, int msgno, char *buffer)
{}
int  i;
extern void foo();
void foo()
{
_print("%s","hello");
return;
}
main() {
TRACE("Created by B2C Version 5");
_init_b2c();
_escape_=1;
_help_=1;
_multitask_=1;
foo();
_destroy_b2c();
return 0;
}
