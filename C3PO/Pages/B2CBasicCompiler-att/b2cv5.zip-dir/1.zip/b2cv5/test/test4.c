/***************************************************
/* Program translated by b2c Version 5
/* b2c (C) Copyright 2001 The Alcor Group, Inc
/* Written by Greg Smith
/*
/* Program test4.tmp converted Tue Apr 23 21:28:06 2002
/****************************************************/
#include "b2cuser.h"
int _true=1;
int _true_=1;
int _false_=0;
int _c_coords=0;
int _n_sprites=32;
int _n_3dsprites=8;
int _n_rooms=8;
int error=0;
int _show_=1;
int b2c_decimals=2;
int _escape_=1;
int _help_=1;
int _multitask_=1;
void onmessage(long cyid, int msgno, char *buffer)
{}
main() {
TRACE("Created by B2C Version 5");
_init_b2c();
_escape_=1;
_help_=1;
_multitask_=1;
_page(0);
_cls();
_rect(0,0,40,40);
_page(1);
_cls();
_rectfill(-40,40,40,40);
while((_key(KEY_ENTER)==0)) {
_escape(0);
_page(0);
_wait(10);
_page(1);
_wait(10);
}
_destroy_b2c();
return 0;
}
