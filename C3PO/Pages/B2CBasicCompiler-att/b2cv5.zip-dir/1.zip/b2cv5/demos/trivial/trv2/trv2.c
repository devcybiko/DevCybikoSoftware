#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

char *list[10000];
short n=0;

struct rec 
{
	long points;
	long offset;
	short used;
};
struct rec rec[10000];
long currpos;

main(int argc, char **argv)
{
	FILE *infile;
	short n;
	int i;

	infile = fopen(argv[1], "rb");
	if (infile == 0)
	{
		printf("ERROR: Could not open %s\n", argv[1]);
		exit(1);
	}

	fread(&n, 1, sizeof(n), infile);
	fread(rec, n, sizeof(struct rec), infile);

	for(i=0; i<n; i++)
	{
		int c;
		printf("Points=%ld Offset=%ld Used=%d\n", 
			rec[i].points, rec[i].offset, rec[i].used);
		fseek(infile, rec[i].offset, 0);
		while(c=fgetc(infile))
			printf("%c", c^0xAA);
		printf("\n");
	}
}
