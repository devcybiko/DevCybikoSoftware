B2Cv5b 5/22/2002
Basic-to-C README
------------------
Welcome to release 5 of the B2C compiler. This is the final release of B2C (with the exception of possible bug releases)

For a Quick Start Guide see the B2C.chm Help file.


IMPORTANT CHANGES WITH RELEASE 5
---------------------------------
YOU MUST INCLUDE DATA TYPE WITH A DIM STATEMENT
you used to be able to do this:

dim x

but now you need to do this:
dim x as int

Version 5 is completely free of passwords.  Previous releases embedded passwords into the resultant programs.  Version 5 has several new features including Fixed point math (decimal points), Help files, Word wrapping output, improved input for Xtreme, Rename, Remove, and Exists commands for Files, Len command for strings, Menu XY, Rect, Rectfill, Circle, Circfill, Page and Pagecopy for Graphics, Stringwidth and Stringheight (the width and height of a string in the current font), Font now accepts user font names, Open now allows reading from Archive files, Get/Put now allows Reading and Writing of arrays, and finally Dabs for the absolute value of Double variables.

How's that for an exit?

Greg Smith
cybiko@alcorgrp.com
www.DevCybiko.com
