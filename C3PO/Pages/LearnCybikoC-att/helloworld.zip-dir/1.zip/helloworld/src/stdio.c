// stdio.c
// (C) Jan 2001, The Alcor Group, Inc.
//
#define MAX_LINES 100
#define LINE_LENGTH 40
#define MAX_PIXELS_WIDTH 160
#define MAX_PIXELS_HEIGHT 100
struct putc {
    int x, y;
    int nlines;
    int ht;
    int topline;
    struct Font *font;
    char *lines[MAX_LINES];
} *pc;

char stdio_buffer[256];

#define DBG0 stdio_debug
#define DBG1 stdio_debug
#define DBG2 stdio_debug
void stdio_debug() {}

void init_putc()
{
    int i;
    pc = CALLOC(1, struct putc);
    for(i=0; i<MAX_LINES; i++)
    {
        pc->lines[i] = CALLOC(LINE_LENGTH, char);
    }
    pc->font = mini_normal_font;
    pc->nlines = MAX_PIXELS_HEIGHT/Font_get_char_height(pc->font);
    pc->ht = Font_get_char_height(pc->font);
    pc->topline = MAX_LINES-1;
    TGraph_fill_screen(main_module.m_gfx, CLR_WHITE);
}

int disp_line=MAX_LINES;

void redisp()
{
    int i;

    disp_line = MAX_LINES;

    TGraph_fill_screen (main_module.m_gfx, CLR_WHITE);
    Graphics_set_font(main_module.m_gfx, pc->font);
    Graphics_set_color(main_module.m_gfx, CLR_BLACK);
    pc->x = 0;
    pc->y = 0;

    for(i=MAX_LINES-pc->nlines; i<MAX_LINES; i++)
    {
        Graphics_draw_text(main_module.m_gfx, pc->lines[i], pc->x, pc->y);
        pc->y += pc->ht;
    }
    DisplayGraphics_show(main_module.m_gfx);
}

void prev_disp(int dir)
{
    int i;

    if (dir == 1)
    {
        disp_line += (pc->nlines-1);
        if (disp_line >= (MAX_LINES-pc->nlines))
            disp_line = MAX_LINES;
    }
    else
    {
        if (disp_line == MAX_LINES) disp_line = MAX_LINES - pc->nlines;
        disp_line -= (pc->nlines-1);
        if (disp_line < pc->topline)
            disp_line = pc->topline;
    }
    if (disp_line == MAX_LINES)
    {
        redisp();
        return;
    }
    TGraph_fill_screen (main_module.m_gfx, CLR_BLACK);
    Graphics_set_font(main_module.m_gfx, pc->font);
    Graphics_set_color(main_module.m_gfx, CLR_WHITE);
    pc->x = 0;
    pc->y = 0;

    for(i=disp_line; i<disp_line+pc->nlines; i++)
    {
        Graphics_draw_text(main_module.m_gfx, pc->lines[i], pc->x, pc->y);
        pc->y += pc->ht;
    }
    DisplayGraphics_show(main_module.m_gfx);
}

void scroll()
{
//    char *tmp = pc->lines[pc->topline];
    char *tmp = pc->lines[0];
    int i;
    pc->topline--;
    if (pc->topline < 0) pc->topline = 0;
    for(i=0; i<MAX_LINES-1; i++)
        pc->lines[i] = pc->lines[i+1];
    pc->lines[i] = tmp;
    tmp[0] = 0;
}

void putc(int c)
{
    char buf[2];
    int i = MAX_LINES-1;
    int len;
    char *curline;

    //cprintf("%c", c);
    if (c == 0) return;
    if (c == '\n')
    {
        scroll();
        redisp();
        return;
    }
    curline = pc->lines[i];
    len = strlen(pc->lines[i]);
    curline[len] = (char) c;
    len++;
    curline[len] = 0;
    if (Font_string_width(pc->font, curline) > MAX_PIXELS_WIDTH)
    {
        len--;
        curline[len] = 0;
        scroll();
        redisp();
        curline = pc->lines[i];
        len = strlen(pc->lines[i]);
        curline[len] = (char) c;
        len++;
        curline[len] = 0;
    }

    if (len >= LINE_LENGTH-1)
    {
        scroll();
        redisp();
        return;
    }
}

void putc_update(int c)
{
    putc(c);
    Graphics_draw_text(main_module.m_gfx, pc->lines[MAX_LINES-1], 0, (pc->nlines-1)*pc->ht);
    DisplayGraphics_show(main_module.m_gfx);
}

FILE *fopen(char *name, char *mode)
{
	struct FileInput *fi;
	struct FileOutput *fo;
	struct _file *file;
    int openned;

    DBG0(">fopen %s", __FILE__);
	file = CALLOC(1, FILE);

	if (*mode == 'r')
	{
	    DBG1("... read access %s", name);
        file->type = 0;
        file->cybio = Archive_open_Ex(main_module.m_process->module->archive, name);
        if (file->cybio)
        {
            DBG1("file->cybio = %08x", file->cybio);
            return file;
        }
        DBG1("...ARCHIVE IS BAD!");
        fclose(file);
        return NULL;
        //DBG1("... about to call FileInput_open %s", name);
        //openned = FileInput_open(file->cybio, name);
        //DBG1("... return from FileInput_open %s openned=%d", name, openned);
		//if (openned) return file;
		//fclose(file);
		//return NULL;
	}
	else
	{   DBG1("... write access %s", name);
		file->type = 1;
		file->cybio = CALLOC(1, struct FileOutput);
		FileOutput_ctor(file->cybio);
        openned = FileOutput_open(file->cybio, name, TRUE);
		if (openned) return file;
		fclose(file);
		return NULL;
    }
    DBG0("<fopen");
}

void fclose(FILE *_file)
{
	struct _file *file = _file;

	if (file->type == 0)
	{
	    if (file->cybio) Input_dtor(file->cybio, FREE_MEMORY);
    }
	else Output_dtor(file->cybio, FREE_MEMORY);
	free(file);
	return;
}

char *ltoa(long n, char *buf, int buflen)
{
	sprintf(buf, "%ld", n);
	return buf;
}

 
int printf(char *fmt, ...)
{
	long *x = (long *)&fmt;
    int i;

    vsprintf(stdio_buffer, fmt, &x[1]);
    for(i=0; stdio_buffer[i]; i++)
        putc(stdio_buffer[i]);
}

int iswhite(int c)
{
        if (c == ' ' ||
            c == '\n' ||
            c == '\r' ||
            c == '\t') return TRUE;
        return FALSE;
}

long ftell(FILE *file)
{
	return FileInput_tell(file->cybio);
}

// whence - 0=set, 1=cur 2=end
long fseek(FILE *file, long n, int whence)
{
	return Input_seekg(file->cybio, n, whence);
}

int fputc(int c, FILE *file)
{
    if (file == stdout || file == stderr) putc(c);
    else fprintf(file, "%c", c);
}

int fgetc(FILE *file)
{
    int c;

    DBG2(">fgetc %s", __FILE__);
	if (file == stdin)
    {
        DBG1("... calling getchar because reading from stdin");
		c = getchar();
    }
	else
    {
        DBG2("... calling Input_read_byte");
		c = Input_read_byte(file->cybio);
    }
    DBG2("<fgetc c=%d %02x", c, c);
    return c;
}

int fgets(char *buf, int buflen, FILE *file)
{
	int i;
	int c;
	for(i=0; i<buflen-1; i++)
	{
		c = fgetc(file);
        DBG2("... fgetc = %c %02x", c, c);
		if (c == '\n')
		{
			buf[i] = (char) c;
			i++;
            buf[i] = 0;
            DBG2("...buffer now holds %s", buf);
			break;
		}
		else if (c == EOF)
		{
            buf[i] = 0;
            if (file == stdin) return 0;
			break;
		}
        else if (c == KEY_BACKSPACE)
        {
        DBG1("key is backspace, i=%d", i);
        DBG1("buf=%s", buf);
            if (i)
            {
                i--;
                buf[i] = 0;
                i--;
            }
        DBG1("now buf=%s", buf);
        }
        else
        {
            buf[i] = (char) c;
            buf[i+1] = 0;
        }
	}
	buf[i] = 0;
    DBG1(buf);
	return i;
}

int fprintf(FILE *file, char *fmt, ...)
{
	long *x = (long *)&fmt;
    int i;

     if (file == stdout || file == stderr)
	{
        vsprintf(stdio_buffer, fmt, &x[1]);
        for(i=0; stdio_buffer[i]; i++)
            putc(stdio_buffer[i]);
	}
}

char *gets(char *inrec)
{
	char *s;

	fgets(inrec, 256, stdin);
	s = strchr(inrec, '\n');
	if (s) *s = 0;
	return inrec;
}

void getchar_del()
{
    int i = MAX_LINES-1;
    int len;
    char *curline;

    curline = pc->lines[i];
    len = strlen(curline);
    if (len)
    {
        len--;
        curline[len] = 0;
        redisp();
    }
}

int getchar()
{
  struct Message* message;
  bool got_char = FALSE;
  int return_value = 0;
  int key;

  putc_update(0);
  while(!got_char)
  {
    message = cWinApp_get_message(main_module.m_process, 0, 1, MSG_USER);

    switch(message->msgid)
    {
      case MSG_SHUTUP:
      case MSG_QUIT:
        got_char = TRUE;
        return_value = EOF;
        break;
      case MSG_GOTFOCUS:
        redisp();
        break;
      case MSG_KEYDOWN:
      {
          key = Message_get_key_param(message)->scancode;
          DBG1("key=%c %d", key, key);

          switch(key) {
          case KEY_ESC:
          {
            got_char = TRUE;
            return_value = EOF;
            exit(0); //hack
            break;
          }
          case KEY_ENTER:
          {
            key = '\n';
            return_value = key;
            got_char = TRUE;
            putc_update(key);
            break;
          }
          case KEY_BACKSPACE:
          case KEY_DEL:
          {
            return_value = KEY_BACKSPACE;
            got_char = TRUE;
            getchar_del();
            if (disp_line != MAX_LINES) redisp();
            break;
          }
          case KEY_HELP:
          {
              cWinApp_defproc(main_module.m_process, message);
              redisp();
              break;
          }
          case KEY_UP:
          {
              prev_disp(-1);
              break;
          }
          case KEY_DOWN:
          {
              prev_disp(+1);
              break;
          }
	      default:
	      {
             got_char= TRUE;
		     return_value = key;
             putc_update(key);
             if (disp_line != MAX_LINES) redisp();
             break;
	      }
          }
          break;
      }
      default:             //  Processes all unprocessed messages.
        process_message(message);
        cWinApp_defproc(main_module.m_process, message);
    }

    Message_delete(message);
  }  //  while(!exit_application)
    DBG1("<getchar %c %02x", return_value, return_value);
    return return_value;

}

long fread(void *ptr, size_t size, size_t nitems, FILE *file)
{
    return FileInput_read(file->cybio, ptr, (long)size*nitems );
}

long fwrite(void *ptr, size_t size, size_t nitems, FILE *file)
{
    return FileOutput_write(file->cybio, ptr, (long)size*nitems);
}

long atoi(char *s)
{
	return (long)atoul(s);
}

// a minimal implementation
int sscanf(char *in, char *fmt, ...)
{
        char *s, *t;
        long *x = (long *) &fmt;
        if (SAME(fmt, "%d,"))
        {
                ((int *)(x[1]))[0] = (int)atoi(in);
                return 1;
        }
        else if (SAME("%19s %19s", fmt))
        {
                strcpy((char *)x[1], "");
                strcpy((char *)x[2], "");
                strcpy(stdio_buffer, in);
                for(t=stdio_buffer; *t; t++) if (!iswhite(*t)) break;
                for(s=t; *s; s++) if (iswhite(*s)) break;
                *s = 0;
                strncpy((char *)x[1], t, 19);
                s++;
                for(t=s; *t; t++) if (!iswhite(*t)) break;
                for(s=t; *s; s++) if (iswhite(*s)) break;
                *s = 0;
                strncpy((char *)x[2], t, 19);
                return 2;
        }
        return 0;
}

int tolower(int c)
{
        if (c>='A' && c<='Z') return c+32;
	else return c;
}

long rand(void)
{
	return random(-1);
}
