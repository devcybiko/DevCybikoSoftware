//
// hello world example
//
#include "CyWin.h"
#include "stdio.h"

//
//forward references
//
int process_message(struct Message *message);

//
// global variables
//
struct module_t main_module;

long main(int argc, char* argv[], bool start)
{
  // note - limit of ~240 bytes on the stack.
  // if you need more space, declare variables
  // in the "global variables" area, above
  char name[32];

  init_module(&main_module);  // initialize the cybiko
  init_putc();                // initialize the stdio emulation
	
  printf("Hello World!\n");    // notice the newline here
  printf("Enter Your Name: "); // but not here, so it is a prompt
  gets(name);                  // get all chars up to a ENTER
  printf("Welcome to the world\nof CYBIKO, %s\n", name);
  printf("Press any key to exit...");
  getchar();                   // get a single character

  return 0;
}

//
// this is for message processing during keyboard input.
// we'll cover that later.
int process_message(struct Message *message)
{
}
#include "stdio.c"
